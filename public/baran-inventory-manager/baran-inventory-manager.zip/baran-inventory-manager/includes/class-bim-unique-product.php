<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Unique_Product {
    private static $instance = null;
    private $api;
    private $logger;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->logger = BIM_Logger::get_instance();
        
        // اضافه کردن هوک‌ها
        add_action('woocommerce_product_options_sku', array($this, 'add_unique_id_field'));
        add_action('woocommerce_process_product_meta', array($this, 'save_unique_id_field'));
        
        // هوک‌های محصولات متغیر
        add_action('woocommerce_variation_options', array($this, 'add_variation_unique_id_field'), 10, 3);
        add_action('woocommerce_save_product_variation', array($this, 'save_variation_unique_id_field'), 10, 2);
        
        // هوک‌های سفارش
        add_action('woocommerce_checkout_create_order_line_item', array($this, 'add_unique_id_to_order_item'), 10, 4);

        // هوک‌های حذف محصول
        add_action('before_delete_post', array($this, 'delete_product_unique_id'));
        add_action('woocommerce_before_delete_product_variation', array($this, 'delete_variation_unique_id'));
    }

    /**
     * اضافه کردن فیلد شناسه یکتا به محصولات ساده
     */
    public function add_unique_id_field() {
        global $post;
        
        $product_data = $this->get_product_unique_id($post->ID);
        $unique_id = $product_data ? $product_data->unique_id : '';
        
        echo '<div class="options_group">';
        echo '<p class="form-field">';
        echo '<label for="_bim_unique_id">شناسه یکتا</label>';
        echo '<input type="text" id="_bim_unique_id" name="_bim_unique_id" value="' . esc_attr($unique_id) . '" maxlength="100">';
        echo '<span class="description">شناسه یکتای محصول برای ارتباط با API</span>';
        echo '</p>';
        echo '</div>';
    }

    /**
     * ذخیره شناسه یکتای محصول ساده
     */
    public function save_unique_id_field($post_id) {
        if (isset($_POST['_bim_unique_id'])) {
            $unique_id = sanitize_text_field($_POST['_bim_unique_id']);
            $product = wc_get_product($post_id);
            $barcode = $product ? $product->get_sku() : null;
            $this->update_product_unique_id($post_id, null, $unique_id, $barcode);
        }
    }

    /**
     * اضافه کردن فیلد شناسه یکتا به محصولات متغیر
     */
    public function add_variation_unique_id_field($loop, $variation_data, $variation) {
        $variation_obj = wc_get_product($variation->ID);
        if (!$variation_obj) {
            return;
        }

        $product_id = $variation_obj->get_parent_id();
        $product_data = $this->get_product_unique_id($product_id, $variation->ID);
        $unique_id = $product_data ? $product_data->unique_id : '';
        
        echo '<div class="form-row form-row-full">';
        echo '<p class="form-field">';
        echo '<label for="_bim_unique_id_' . $variation->ID . '">شناسه یکتا</label>';
        echo '<input type="text" id="_bim_unique_id_' . $variation->ID . '" name="_bim_unique_id_' . $variation->ID . '" value="' . esc_attr($unique_id) . '" maxlength="100">';
        echo '<span class="description">شناسه یکتای محصول متغیر برای ارتباط با API</span>';
        echo '</p>';
        echo '</div>';
    }

    /**
     * ذخیره شناسه یکتای محصول متغیر
     */
    public function save_variation_unique_id_field($variation_id, $i) {
        if (isset($_POST['_bim_unique_id_' . $variation_id])) {
            $unique_id = sanitize_text_field($_POST['_bim_unique_id_' . $variation_id]);
            $variation = wc_get_product($variation_id);
            if ($variation) {
                $product_id = $variation->get_parent_id();
                $barcode = $variation->get_sku();
                $this->update_product_unique_id($product_id, $variation_id, $unique_id, $barcode);
            }
        }
    }

    /**
     * اضافه کردن شناسه یکتا به آیتم‌های سفارش
     */
    public function add_unique_id_to_order_item($item, $cart_item_key, $values, $order) {
        $product_id = $item->get_product_id();
        $variation_id = $item->get_variation_id();
        
        $unique_id = $this->get_product_unique_id($product_id, $variation_id);
        if ($unique_id) {
            $item->add_meta_data('_bim_unique_id', $unique_id);
        }
    }

    /**
     * دریافت شناسه یکتای محصول
     */
    public function get_product_unique_id($product_id, $variation_id = null) {
        global $wpdb;
        
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
        $query = $wpdb->prepare(
            "SELECT unique_id, barcode FROM $table_name WHERE product_id = %d AND (variation_id = %d OR variation_id IS NULL)",
            $product_id,
            $variation_id
        );
        
        $result = $wpdb->get_row($query);
        return $result ?: null;
    }

    /**
     * حذف کد یکتا هنگام حذف محصول
     */
    public function delete_product_unique_id($post_id) {
        // بررسی اینکه آیا پست یک محصول است
        if (get_post_type($post_id) !== 'product') {
            return;
        }

        global $wpdb;
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;

        // حذف کد یکتای محصول اصلی و تمام واریانت‌های آن
        $wpdb->delete(
            $table_name,
            array('product_id' => $post_id),
            array('%d')
        );

        $this->logger->add_log('info', sprintf('کد یکتای محصول %d و واریانت‌های آن حذف شد', $post_id));
    }

    /**
     * حذف کد یکتا هنگام حذف واریانت
     */
    public function delete_variation_unique_id($variation_id) {
        global $wpdb;
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;

        // حذف کد یکتای واریانت
        $wpdb->delete(
            $table_name,
            array('variation_id' => $variation_id),
            array('%d')
        );

        $this->logger->add_log('info', sprintf('کد یکتای واریانت %d حذف شد', $variation_id));
    }

    /**
     * بررسی تکراری بودن کد یکتا
     */
    private function is_unique_id_exists($unique_id, $current_product_id = null, $current_variation_id = null) {
        global $wpdb;
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;

        $query = $wpdb->prepare(
            "SELECT * FROM $table_name WHERE unique_id = %s AND (product_id != %d OR variation_id != %d)",
            $unique_id,
            $current_product_id,
            $current_variation_id
        );

        $result = $wpdb->get_row($query);
        return $result !== null;
    }

    /**
     * به‌روزرسانی شناسه یکتای محصول
     */
    public function update_product_unique_id($product_id, $variation_id, $unique_id, $barcode = null) {
        global $wpdb;
        
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
        
        // بررسی وجود کد یکتای قبلی
        $old_data = $this->get_product_unique_id($product_id, $variation_id);

        // اگر کد یکتا خالی است، فقط رکورد قبلی را حذف می‌کنیم
        if (empty($unique_id)) {
            $wpdb->delete(
                $table_name,
                array(
                    'product_id' => $product_id,
                    'variation_id' => $variation_id
                ),
                array('%d', '%d')
            );
            return;
        }

        // بررسی تکراری بودن کد یکتا
        if ($this->is_unique_id_exists($unique_id, $product_id, $variation_id)) {
            $this->logger->add_log('error', sprintf(
                'کد یکتای %s قبلاً برای محصول دیگری استفاده شده است',
                $unique_id
            ));
            return;
        }
        
        // حذف شناسه قبلی
        $wpdb->delete(
            $table_name,
            array(
                'product_id' => $product_id,
                'variation_id' => $variation_id
            ),
            array('%d', '%d')
        );
        
        // درج شناسه جدید
        $wpdb->insert(
            $table_name,
            array(
                'unique_id' => $unique_id,
                'product_id' => $product_id,
                'variation_id' => $variation_id,
                'barcode' => $barcode
            ),
            array('%s', '%d', '%d', '%s')
        );

        // لاگ کردن تغییر کد یکتا
        if ($old_data && ($old_data->unique_id !== $unique_id || $old_data->barcode !== $barcode)) {
            $this->logger->add_log('info', sprintf(
                'اطلاعات محصول %d %s از (کد یکتا: %s, بارکد: %s) به (کد یکتا: %s, بارکد: %s) تغییر کرد',
                $product_id,
                $variation_id ? "(واریانت $variation_id)" : '',
                $old_data->unique_id ?: 'بدون کد',
                $old_data->barcode ?: 'بدون بارکد',
                $unique_id,
                $barcode ?: 'بدون بارکد'
            ));
        }
    }

    /**
     * دریافت اطلاعات محصول از API با استفاده از شناسه یکتا یا بارکد
     */
    public function get_product_by_unique_id($unique_id) {
        global $wpdb;
        
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
        $query = $wpdb->prepare(
            "SELECT * FROM $table_name WHERE unique_id = %s OR barcode = %s",
            $unique_id,
            $unique_id
        );
        
        $result = $wpdb->get_row($query);
        
        if (!$result) {
            $this->logger->add_log('error', 'محصول با شناسه یکتا یا بارکد ' . $unique_id . ' یافت نشد');
            return false;
        }
        
        return $result;
    }

    /**
     * دریافت اطلاعات چند محصول از API با استفاده از شناسه‌های یکتا
     */
    public function get_products_by_unique_ids($unique_ids) {
        global $wpdb;
        
        if (empty($unique_ids)) {
            return array();
        }
        
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
        $placeholders = array_fill(0, count($unique_ids), '%s');
        $query = $wpdb->prepare(
            "SELECT * FROM $table_name WHERE unique_id IN (" . implode(',', $placeholders) . ")",
            $unique_ids
        );
        
        $results = $wpdb->get_results($query);
        
        if (!$results) {
            $this->logger->add_log('error', 'هیچ محصولی با شناسه‌های یکتای ارائه شده یافت نشد');
            return array();
        }
        
        return $results;
    }

    /**
     * دریافت محصول با استفاده از بارکد
     */
    public function get_product_by_barcode($barcode) {
        global $wpdb;
        
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
        $query = $wpdb->prepare(
            "SELECT * FROM $table_name WHERE barcode = %s",
            $barcode
        );
        
        $result = $wpdb->get_row($query);
        
        if (!$result) {
            $this->logger->add_log('error', 'محصول با بارکد ' . $barcode . ' یافت نشد');
            return false;
        }
        
        return $result;
    }
} 