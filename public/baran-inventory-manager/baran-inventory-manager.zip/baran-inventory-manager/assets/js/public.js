jQuery(document).ready(function($) {
    // نمایش اطلاعات محصول
    $('.bim-product-info').each(function() {
        var $container = $(this);
        var $pre = $container.find('pre');
        
        if ($pre.length) {
            var $button = $('<button type="button" class="button">نمایش جزئیات</button>');
            var $details = $('<div class="bim-details" style="display: none;"></div>').append($pre);
            
            $container.append($button);
            $container.append($details);
            
            $button.on('click', function() {
                var $this = $(this);
                var $details = $this.next('.bim-details');
                
                if ($details.is(':visible')) {
                    $details.slideUp();
                    $this.text('نمایش جزئیات');
                } else {
                    $details.slideDown();
                    $this.text('مخفی کردن جزئیات');
                }
            });
        }
    });
    
    // نمایش اطلاعات سبد خرید
    $('.bim-cart-info').each(function() {
        var $container = $(this);
        var $pre = $container.find('pre');
        
        if ($pre.length) {
            var $button = $('<button type="button" class="button">نمایش جزئیات</button>');
            var $details = $('<div class="bim-details" style="display: none;"></div>').append($pre);
            
            $container.append($button);
            $container.append($details);
            
            $button.on('click', function() {
                var $this = $(this);
                var $details = $this.next('.bim-details');
                
                if ($details.is(':visible')) {
                    $details.slideUp();
                    $this.text('نمایش جزئیات');
                } else {
                    $details.slideDown();
                    $this.text('مخفی کردن جزئیات');
                }
            });
        }
    });
    
    // نمایش وضعیت محصول
    $('.bim-status').each(function() {
        var $status = $(this);
        var status = $status.data('status');
        
        switch (status) {
            case 'success':
                $status.addClass('bim-status-success');
                break;
            case 'warning':
                $status.addClass('bim-status-warning');
                break;
            case 'error':
                $status.addClass('bim-status-error');
                break;
            case 'info':
                $status.addClass('bim-status-info');
                break;
        }
    });
    
    // نمایش نشان محصول
    $('.bim-badge').each(function() {
        var $badge = $(this);
        var type = $badge.data('type');
        
        switch (type) {
            case 'primary':
                $badge.addClass('bim-badge-primary');
                break;
            case 'success':
                $badge.addClass('bim-badge-success');
                break;
            case 'warning':
                $badge.addClass('bim-badge-warning');
                break;
            case 'danger':
                $badge.addClass('bim-badge-danger');
                break;
            case 'info':
                $badge.addClass('bim-badge-info');
                break;
        }
    });
    
    // نمایش برچسب محصول
    $('.bim-label').each(function() {
        var $label = $(this);
        var type = $label.data('type');
        
        switch (type) {
            case 'primary':
                $label.addClass('bim-label-primary');
                break;
            case 'success':
                $label.addClass('bim-label-success');
                break;
            case 'warning':
                $label.addClass('bim-label-warning');
                break;
            case 'danger':
                $label.addClass('bim-label-danger');
                break;
            case 'info':
                $label.addClass('bim-label-info');
                break;
        }
    });
    
    // نمایش هشدار محصول
    $('.bim-alert').each(function() {
        var $alert = $(this);
        var type = $alert.data('type');
        
        switch (type) {
            case 'success':
                $alert.addClass('bim-alert-success');
                break;
            case 'warning':
                $alert.addClass('bim-alert-warning');
                break;
            case 'error':
                $alert.addClass('bim-alert-error');
                break;
            case 'info':
                $alert.addClass('bim-alert-info');
                break;
        }
    });
    
    // نمایش پنل محصول
    $('.bim-panel').each(function() {
        var $panel = $(this);
        var type = $panel.data('type');
        
        switch (type) {
            case 'primary':
                $panel.addClass('bim-panel-primary');
                break;
            case 'success':
                $panel.addClass('bim-panel-success');
                break;
            case 'warning':
                $panel.addClass('bim-panel-warning');
                break;
            case 'danger':
                $panel.addClass('bim-panel-danger');
                break;
            case 'info':
                $panel.addClass('bim-panel-info');
                break;
        }
    });
}); 