<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap bim-admin">
    <h1>مدیریت موجودی باران</h1>
    
    <div class="bim-status-cards">
        <div class="bim-card">
            <h3>وضعیت اتصال</h3>
            <div class="bim-status <?php echo $connection_status['connected'] ? 'connected' : 'disconnected'; ?>">
                <?php if ($connection_status['connected']): ?>
                    <span class="dashicons dashicons-yes"></span>
                    <span>اتصال برقرار است</span>
                <?php else: ?>
                    <span class="dashicons dashicons-no"></span>
                    <span>اتصال برقرار نیست</span>
                    <?php if (isset($connection_status['error'])): ?>
                        <p class="error-message"><?php echo esc_html($connection_status['error']); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <button class="button" id="bim-test-connection">تست اتصال</button>
        </div>
        
        <div class="bim-card">
            <h3>وضعیت لایسنس</h3>
            <div class="bim-status <?php echo $license_key ? 'active' : 'inactive'; ?>">
                <?php if ($license_key): ?>
                    <div style="display: flex; flex-direction: column; width: 100%;">
                        <div style="display: flex; align-items: center;">
                            <span class="dashicons dashicons-yes"></span>
                            <span>لایسنس فعال است</span>
                        </div>
                        <div style="margin-top: 10px;">
                            <span class="bim-account-type" style="display: inline-block; padding: 3px 8px; background: #2271b1; color: white; border-radius: 3px; font-size: 12px;">
                                <?php 
                                    $account_type_labels = array(
                                        'basic' => 'پایه',
                                        'standard' => 'استاندارد',
                                        'premium' => 'حرفه‌ای',
                                        'enterprise' => 'سازمانی',
                                        'ultimate' => 'نهایی'
                                    );
                                    $account_type_label = isset($account_type_labels[$account_type]) ? $account_type_labels[$account_type] : $account_type;
                                    echo esc_html($account_type_label); 
                                ?>
                            </span>
                            <?php if ($expiry_date): ?>
                                <small style="display: block; margin-top: 5px; color: #666;">اعتبار تا: <?php echo date_i18n('Y-m-d', strtotime($expiry_date)); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <span class="dashicons dashicons-no"></span>
                    <span>لایسنس فعال نشده است</span>
                <?php endif; ?>
            </div>
            <a href="<?php echo admin_url('admin.php?page=baran-inventory-manager-settings'); ?>" class="button">فعال‌سازی لایسنس</a>
        </div>

        <div class="bim-card">
            <h3>وضعیت توکن</h3>
            <div class="bim-status <?php echo get_option('bim_api_token') ? 'active' : 'inactive'; ?>">
                <?php if (get_option('bim_api_token')): ?>
                    <span class="dashicons dashicons-yes"></span>
                    <span>توکن معتبر است</span>
                <?php else: ?>
                    <span class="dashicons dashicons-no"></span>
                    <span>توکن نامعتبر است</span>
                <?php endif; ?>
            </div>
            <button class="button" id="bim-refresh-token">بروزرسانی توکن</button>
        </div>
    </div>
    

    
    <div class="bim-quick-actions">
        <h3>عملیات سریع</h3>
        <div class="bim-actions-grid">
            <a href="<?php echo admin_url('admin.php?page=baran-inventory-manager-settings'); ?>" class="button">
                <span class="dashicons dashicons-admin-settings"></span>
                تنظیمات
            </a>
            <a href="<?php echo admin_url('admin.php?page=baran-inventory-manager-logs'); ?>" class="button">
                <span class="dashicons dashicons-list-view"></span>
                گزارش‌ها
            </a>
            <a href="<?php echo admin_url('edit.php?post_type=product'); ?>" class="button">
                <span class="dashicons dashicons-cart"></span>
                مدیریت محصولات
            </a>
        </div>
    </div>
</div>

<style>
.bim-admin {
    margin: 20px;
}

.bim-status-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.bim-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.bim-card h3 {
    margin-top: 0;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.bim-status {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
}

.bim-status.connected .dashicons,
.bim-status.active .dashicons {
    color: #46b450;
}

.bim-status.disconnected .dashicons,
.bim-status.inactive .dashicons {
    color: #dc3232;
}

.bim-status .dashicons {
    margin-right: 10px;
    font-size: 20px;
}

.error-message {
    color: #dc3232;
    margin: 10px 0 0;
    font-size: 13px;
}

.license-info {
    margin: 10px 0 0;
    font-size: 13px;
    color: #666;
}

.bim-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
}

.stat-item {
    text-align: center;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 4px;
}

.stat-value {
    display: block;
    font-size: 24px;
    font-weight: bold;
    color: #2271b1;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 13px;
    color: #666;
}

.bim-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.bim-actions-grid .button {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 40px;
}

.bim-actions-grid .dashicons {
    margin-right: 8px;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#bim-test-connection').on('click', function() {
        var $button = $(this);
        var $status = $button.closest('.bim-card').find('.bim-status');
        
        $button.prop('disabled', true).text(bimAdmin.strings.testing);
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_test_connection',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.removeClass('disconnected').addClass('connected')
                        .html('<span class="dashicons dashicons-yes"></span><span>' + bimAdmin.strings.connected + '</span>');
                } else {
                    $status.removeClass('connected').addClass('disconnected')
                        .html('<span class="dashicons dashicons-no"></span><span>' + bimAdmin.strings.disconnected + '</span>' +
                              '<p class="error-message">' + response.data.message + '</p>');
                }
            },
            error: function() {
                $status.removeClass('connected').addClass('disconnected')
                    .html('<span class="dashicons dashicons-no"></span><span>' + bimAdmin.strings.disconnected + '</span>' +
                          '<p class="error-message">خطا در ارتباط با سرور</p>');
            },
            complete: function() {
                $button.prop('disabled', false).text('تست اتصال');
            }
        });
    });

    $('#bim-refresh-token').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true);
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_refresh_token',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
});
</script>

<script>
jQuery(document).ready(function($) {
    $('#bim-clear-data').on('click', function() {
        if (!confirm('آیا از سینک مجدد داده‌ها اطمینان دارید؟')) {
            return;
        }
        
        var $button = $(this);
        $button.prop('disabled', true);
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_clear_data',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
});
</script>

<script>
jQuery(document).ready(function($) {
    // مدیریت بستن اطلاعیه‌ها
    $('.bim-notification').on('click', '.notice-dismiss', function(e) {
        e.preventDefault();
        
        var $notice = $(this).closest('.bim-notification');
        var notificationId = $notice.data('notification-id');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_dismiss_notification',
                notification_id: notificationId,
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $notice.fadeOut();
                } else {
                    alert(response.data.message || 'خطا در بستن اطلاعیه');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            }
        });
    });
});
</script> 