<?php
if (!defined('ABSPATH')) {
    exit;
}

$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
$page = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
$per_page = 20;

$logs = BIM_Logger::get_instance()->get_logs(array(
    'type' => $type,
    'date' => $date,
    'page' => $page,
    'per_page' => $per_page
));

$total_logs = BIM_Logger::get_instance()->get_total_logs(array(
    'type' => $type,
    'date' => $date
));

$total_pages = ceil($total_logs / $per_page);
?>

<div class="wrap bim-admin">
    <h1>گزارش‌های سیستم</h1>
    
    <!-- فیلترها -->
    <div class="bim-filters">
        <form method="get" id="bim-logs-filter">
            <input type="hidden" name="page" value="bim-logs">
            
            <div class="bim-filter-group">
                <label for="bim-log-type">نوع گزارش:</label>
                <select name="type" id="bim-log-type">
                    <option value="">همه انواع</option>
                    <option value="api_request_failed" <?php selected($type, 'api_request_failed'); ?>>خطای درخواست API</option>
                    <option value="settings_updated" <?php selected($type, 'settings_updated'); ?>>به‌روزرسانی تنظیمات</option>
                    <option value="settings_update_failed" <?php selected($type, 'settings_update_failed'); ?>>خطای به‌روزرسانی تنظیمات</option>
                    <option value="license_activated" <?php selected($type, 'license_activated'); ?>>فعال‌سازی لایسنس</option>
                    <option value="license_activation_failed" <?php selected($type, 'license_activation_failed'); ?>>خطای فعال‌سازی لایسنس</option>
                    <option value="license_deactivated" <?php selected($type, 'license_deactivated'); ?>>غیرفعال‌سازی لایسنس</option>
                    <option value="license_deactivation_failed" <?php selected($type, 'license_deactivation_failed'); ?>>خطای غیرفعال‌سازی لایسنس</option>
                    <option value="product_updated" <?php selected($type, 'product_updated'); ?>>به‌روزرسانی محصول</option>
                    <option value="product_update_failed" <?php selected($type, 'product_update_failed'); ?>>خطای به‌روزرسانی محصول</option>
                    <option value="variation_updated" <?php selected($type, 'variation_updated'); ?>>به‌روزرسانی متغیر</option>
                    <option value="variation_update_failed" <?php selected($type, 'variation_update_failed'); ?>>خطای به‌روزرسانی متغیر</option>
                    <option value="invoice_created" <?php selected($type, 'invoice_created'); ?>>ایجاد فاکتور</option>
                    <option value="invoice_creation_failed" <?php selected($type, 'invoice_creation_failed'); ?>>خطای ایجاد فاکتور</option>
                    <option value="cart_synced" <?php selected($type, 'cart_synced'); ?>>همگام‌سازی سبد خرید</option>
                    <option value="cart_sync_failed" <?php selected($type, 'cart_sync_failed'); ?>>خطای همگام‌سازی سبد خرید</option>
                </select>
            </div>
            
            <div class="bim-filter-group">
                <label for="bim-log-date">تاریخ:</label>
                <input type="date" 
                       name="date" 
                       id="bim-log-date" 
                       value="<?php echo esc_attr($date); ?>">
            </div>
            
            <div class="bim-filter-actions">
                <button type="submit" class="button button-primary">
                    فیلتر
                    <span class="spinner"></span>
                </button>
                <button type="button" id="bim-clear-filters" class="button">پاک کردن فیلترها</button>
            </div>
        </form>
    </div>
    
    <!-- دکمه‌های عملیات -->
    <div class="bim-actions">
        <button type="button" id="bim-export-logs" class="button">
            خروجی CSV
            <span class="spinner"></span>
        </button>
        <button type="button" id="bim-clear-logs" class="button button-link-delete">
            پاک کردن همه گزارش‌ها
            <span class="spinner"></span>
        </button>
    </div>
    
    <!-- جدول گزارش‌ها -->
    <div class="bim-table-container">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>نوع</th>
                    <th>پیام</th>
                    <th>تاریخ</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            
            <tbody>
                <?php if ($logs): ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->id); ?></td>
                            <td>
                                <span class="bim-log-type <?php echo esc_attr($log->type); ?>">
                                    <?php echo esc_html($log->type); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($log->message); ?></td>
                            <td><?php echo esc_html($log->created_at); ?></td>
                            <td>
                                <button type="button" 
                                        class="bim-view-details button" 
                                        data-details='<?php echo esc_attr(json_encode($log->data)); ?>'>
                                    مشاهده جزئیات
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="bim-no-logs">
                            هیچ گزارشی یافت نشد.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- صفحه‌بندی -->
    <?php if ($total_pages > 1): ?>
        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $total_pages,
                    'current' => $page
                ));
                ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- مودال جزئیات -->
<div id="bim-details-modal" class="bim-modal">
    <div class="bim-modal-content">
        <div class="bim-modal-header">
            <h2>جزئیات گزارش</h2>
            <span class="bim-modal-close">&times;</span>
        </div>
        <div class="bim-modal-body">
            <pre id="bim-details-content"></pre>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // پاک کردن فیلترها
    $('#bim-clear-filters').on('click', function() {
        $('#bim-log-type').val('');
        $('#bim-log-date').val('');
        $('#bim-logs-filter').submit();
    });
    
    // خروجی CSV
    $('#bim-export-logs').on('click', function() {
        var $button = $(this);
        var $spinner = $button.find('.spinner');
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_export_logs',
                nonce: '<?php echo wp_create_nonce("bim_export_logs"); ?>',
                type: $('#bim-log-type').val(),
                date: $('#bim-log-date').val()
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = response.data.url;
                } else {
                    alert('خطا در خروجی گرفتن: ' + response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $button.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
    
    // پاک کردن همه گزارش‌ها
    $('#bim-clear-logs').on('click', function() {
        if (!confirm('آیا از پاک کردن همه گزارش‌ها اطمینان دارید؟')) {
            return;
        }
        
        var $button = $(this);
        var $spinner = $button.find('.spinner');
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_clear_logs',
                nonce: '<?php echo wp_create_nonce("bim_clear_logs"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('خطا در پاک کردن گزارش‌ها: ' + response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $button.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
    
    // نمایش جزئیات
    $('.bim-view-details').on('click', function() {
        var details = $(this).data('details');
        $('#bim-details-content').text(JSON.stringify(details, null, 2));
        $('#bim-details-modal').show();
    });
    
    // بستن مودال
    $('.bim-modal-close').on('click', function() {
        $('#bim-details-modal').hide();
    });
    
    $(window).on('click', function(e) {
        if ($(e.target).is('#bim-details-modal')) {
            $('#bim-details-modal').hide();
        }
    });
});
</script> 