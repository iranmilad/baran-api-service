<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Order_Columns {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // هوک‌های ووکامرس برای صفحه جدید
        add_filter('woocommerce_admin_order_columns', array($this, 'add_order_columns'));
        add_action('woocommerce_admin_order_data_after_order_details', array($this, 'render_order_columns'));
        add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'add_order_columns'));
        add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'render_order_columns'), 10, 2);
        
        // هوک‌های ووکامرس برای صفحه قدیمی
        add_filter('manage_edit-shop_order_columns', array($this, 'add_order_columns'));
        add_action('manage_shop_order_posts_custom_column', array($this, 'render_order_columns'), 10, 2);
        
        // هوک‌های مرتب‌سازی
        add_filter('manage_woocommerce_page_wc-orders_sortable_columns', array($this, 'make_columns_sortable'));
        add_filter('manage_edit-shop_order_sortable_columns', array($this, 'make_columns_sortable'));
        
        add_action('admin_footer', array($this, 'add_resend_button_script'));
    }
    
    public function add_order_columns($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            
            if ($key === 'order_status') {
                $new_columns['bim_web_service_status'] = 'وضعیت ارسال به وبسرویس';
                $new_columns['bim_invoice_status'] = 'عملیات فاکتور';
            }
        }
        
        return $new_columns;
    }
    
    public function render_order_columns($column, $order_id = null) {
        // اگر order_id یک آبجکت است (در ووکامرس جدید)
        if (is_object($order_id)) {
            $order_id = $order_id->get_id();
        }
        
        if ($column === 'bim_web_service_status') {
            $status = get_post_meta($order_id, '_bim_web_service_status', true);
            $message = get_post_meta($order_id, '_bim_web_service_message', true);
            
            echo '<div class="bim-status-container">';
            
            // نمایش وضعیت
            if ($status === 'true') {
                echo '<span class="bim-web-service-status success">ارسال شده</span>';
            } elseif ($status === 'false') {
                echo '<span class="bim-web-service-status error">خطا در ارسال</span>';
            } else {
                echo '<span class="bim-web-service-status pending">ارسال نشده</span>';
            }
            
            // نمایش پیام
            if ($message) {
                $message_class = $status === 'true' ? 'bim-success-message' : 'bim-error-message';
                echo '<div class="bim-status-message ' . esc_attr($message_class) . '">' . esc_html($message) . '</div>';
            }
            

            
            echo '</div>';
        }
        
        if ($column === 'bim_invoice_status') {
            $web_service_status = get_post_meta($order_id, '_bim_web_service_status', true);
            $web_service_message = get_post_meta($order_id, '_bim_web_service_message', true);
            
            // بررسی تنظیمات فاکتور
            $settings = get_option('bim_settings', array());
            if (is_string($settings)) {
                $settings = json_decode($settings, true);
                if (isset($settings['settings'])) {
                    $settings = $settings['settings'];
                }
            }
            
            $invoice_settings = isset($settings['invoice_settings']) ? $settings['invoice_settings'] : array();
            $order = wc_get_order($order_id);
            $order_status = $order ? $order->get_status() : '';
            
            // بررسی فعال بودن ارسال فاکتور برای وضعیت فعلی سفارش
            $should_show_button = false;
            switch ($order_status) {
                case 'pending':
                    $should_show_button = isset($invoice_settings['invoice_pending_type']) && $invoice_settings['invoice_pending_type'] === 'invoice';
                    break;
                case 'on-hold':
                    $should_show_button = isset($invoice_settings['invoice_on_hold_type']) && $invoice_settings['invoice_on_hold_type'] === 'invoice';
                    break;
                case 'processing':
                    $should_show_button = isset($invoice_settings['invoice_processing_type']) && $invoice_settings['invoice_processing_type'] === 'invoice';
                    break;
                case 'completed':
                    $should_show_button = isset($invoice_settings['invoice_complete_type']) && $invoice_settings['invoice_complete_type'] === 'invoice';
                    break;
                case 'cancelled':
                    $should_show_button = isset($invoice_settings['invoice_cancelled_type']) && $invoice_settings['invoice_cancelled_type'] === 'invoice';
                    break;
                case 'refunded':
                    $should_show_button = isset($invoice_settings['invoice_refunded_type']) && $invoice_settings['invoice_refunded_type'] === 'invoice';
                    break;
                case 'failed':
                    $should_show_button = isset($invoice_settings['invoice_failed_type']) && $invoice_settings['invoice_failed_type'] === 'invoice';
                    break;
            }
            
            echo '<div class="bim-status-container">';

            // نمایش دکمه ارسال مجدد فقط اگر در تنظیمات فعال باشد
            if ($should_show_button && $web_service_status !== 'true') {
                echo '<button type="button" class="button resend-invoice" data-order-id="' . esc_attr($order_id) . '" data-type="invoice">ارسال مجدد</button>';
            }
            echo '</div>';
        }
    }
    
    public function make_columns_sortable($columns) {
        $columns['bim_web_service_status'] = 'bim_web_service_status';
        $columns['bim_invoice_status'] = 'bim_invoice_status';
        return $columns;
    }
    
    public function add_resend_button_script() {
        ?>
        <style>
            .bim-status-container {
                display: flex;
                flex-direction: column;
                gap: 5px;
            }
            .bim-status-message {
                font-size: 12px;
                margin-top: 5px;
            }
            .bim-success-message {
                color: #46b450;
            }
            .bim-error-message {
                color: #dc3232;
            }
            .bim-web-service-status {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: 600;
            }
            .bim-web-service-status.success {
                background-color: #46b450;
                color: white;
            }
            .bim-web-service-status.error {
                background-color: #dc3232;
                color: white;
            }
            .bim-web-service-status.pending {
                background-color: #ffb900;
                color: white;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {
                $('.resend-invoice').on('click', function() {
                    var button = $(this);
                    var orderId = button.data('order-id');
                    var type = button.data('type');
                    
                    button.prop('disabled', true);
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'bim_resend_order',
                            order_id: orderId,
                            type: type,
                            nonce: '<?php echo wp_create_nonce("bim_resend_order"); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload();
                            } else {
                                alert(response.data.message || 'خطا در ارسال مجدد');
                            }
                        },
                        error: function() {
                            alert('خطا در ارتباط با سرور');
                        },
                        complete: function() {
                            button.prop('disabled', false);
                        }
                    });
                });
            });
        </script>
        <?php
    }
} 