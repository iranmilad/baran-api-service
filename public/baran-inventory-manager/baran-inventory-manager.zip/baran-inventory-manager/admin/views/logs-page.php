<?php
if (!defined('ABSPATH')) {
    require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
$page = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
$per_page = 20;

$logger = BIM_Logger::get_instance();
$logs = $logger->get_logs(array(
    'type' => $type,
    'date' => $date,
    'page' => $page,
    'per_page' => $per_page
));

$total_logs = $logger->get_total_logs(array(
    'type' => $type,
    'date' => $date
));

$total_pages = ceil($total_logs / $per_page);
?>

<style>
.bim-admin {
    margin: 20px;
}

.bim-filters {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.bim-filter-group {
    display: inline-block;
    margin-left: 15px;
    vertical-align: middle;
}

.bim-filter-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 600;
    color: #23282d;
}

.bim-filter-group select,
.bim-filter-group input[type="date"] {
    min-width: 200px;
    padding: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.bim-filter-actions {
    display: inline-block;
    margin-right: 15px;
    vertical-align: bottom;
}

.bim-filter-actions .button {
    margin-left: 5px;
}

.bim-actions {
    margin: 20px 0;
    text-align: left;
}

.bim-actions .button {
    margin-left: 5px;
}

.bim-table-container {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    margin-top: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.bim-log-type {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 600;
}

.bim-log-type.error {
    background: #dc3545;
    color: #fff;
}

.bim-log-type.success {
    background: #28a745;
    color: #fff;
}

.bim-log-type.warning {
    background: #ffc107;
    color: #000;
}

.bim-log-type.info {
    background: #17a2b8;
    color: #fff;
}

.bim-modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.bim-modal-content {
    background-color: #fff;
    margin: 10% auto;
    padding: 20px;
    border-radius: 4px;
    width: 50%;
    max-width: 600px;
    position: relative;
}

.bim-modal-header {
    border-bottom: 1px solid #ddd;
    padding-bottom: 10px;
    margin-bottom: 15px;
}

.bim-modal-close {
    position: absolute;
    right: 10px;
    top: 10px;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
}

#bim-details-content {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 4px;
    overflow: auto;
    max-height: 400px;
    margin-top: 15px;
}

.spinner {
    float: none;
    margin: 0 0 0 5px;
    vertical-align: middle;
}

.bim-no-logs {
    text-align: center;
    padding: 20px;
    color: #666;
}

.tablenav-pages {
    margin: 10px 0;
    text-align: center;
}

.tablenav-pages .page-numbers {
    display: inline-block;
    padding: 5px 10px;
    margin: 0 2px;
    border: 1px solid #ddd;
    border-radius: 3px;
    text-decoration: none;
}

.tablenav-pages .current {
    background: #0073aa;
    color: #fff;
    border-color: #0073aa;
}
</style>

<div class="wrap bim-admin">
    <h1>گزارش‌های سیستم</h1>
    
    <!-- فیلترها -->
    <div class="bim-filters">
        <form method="get" id="bim-logs-filter">
            <input type="hidden" name="page" value="bim-logs">
            
            <div class="bim-filter-group">
                <label for="bim-log-type">نوع گزارش:</label>
                <select name="type" id="bim-log-type">
                    <option value="">همه انواع</option>
                    <option value="api_request_failed" <?php selected($type, 'api_request_failed'); ?>>خطای درخواست API</option>
                    <option value="settings_updated" <?php selected($type, 'settings_updated'); ?>>به‌روزرسانی تنظیمات</option>
                    <option value="settings_update_failed" <?php selected($type, 'settings_update_failed'); ?>>خطای به‌روزرسانی تنظیمات</option>
                    <option value="license_activated" <?php selected($type, 'license_activated'); ?>>فعال‌سازی لایسنس</option>
                    <option value="license_activation_failed" <?php selected($type, 'license_activation_failed'); ?>>خطای فعال‌سازی لایسنس</option>
                    <option value="license_deactivated" <?php selected($type, 'license_deactivated'); ?>>غیرفعال‌سازی لایسنس</option>
                    <option value="license_deactivation_failed" <?php selected($type, 'license_deactivation_failed'); ?>>خطای غیرفعال‌سازی لایسنس</option>
                    <option value="product_updated" <?php selected($type, 'product_updated'); ?>>به‌روزرسانی محصول</option>
                    <option value="product_update_failed" <?php selected($type, 'product_update_failed'); ?>>خطای به‌روزرسانی محصول</option>
                    <option value="variation_updated" <?php selected($type, 'variation_updated'); ?>>به‌روزرسانی متغیر</option>
                    <option value="variation_update_failed" <?php selected($type, 'variation_update_failed'); ?>>خطای به‌روزرسانی متغیر</option>
                    <option value="invoice_created" <?php selected($type, 'invoice_created'); ?>>ایجاد فاکتور</option>
                    <option value="invoice_creation_failed" <?php selected($type, 'invoice_creation_failed'); ?>>خطای ایجاد فاکتور</option>
                    <option value="cart_synced" <?php selected($type, 'cart_synced'); ?>>همگام‌سازی سبد خرید</option>
                    <option value="cart_sync_failed" <?php selected($type, 'cart_sync_failed'); ?>>خطای همگام‌سازی سبد خرید</option>
                </select>
            </div>
            
            <div class="bim-filter-group">
                <label for="bim-log-date">تاریخ:</label>
                <input type="date" 
                       name="date" 
                       id="bim-log-date" 
                       value="<?php echo esc_attr($date); ?>">
            </div>
            
            <div class="bim-filter-actions">
                <button type="submit" class="button button-primary">
                    فیلتر
                    <span class="spinner"></span>
                </button>
                <button type="button" id="bim-clear-filters" class="button">پاک کردن فیلترها</button>
            </div>
        </form>
    </div>
    
    <!-- دکمه‌های عملیات -->
    <div class="bim-actions">
        <button type="button" class="button" id="bim-export-csv">خروجی CSV</button>
        <form method="post" style="display: inline;">
            <?php wp_nonce_field('bim_clear_logs_action'); ?>
            <button type="submit" name="bim_clear_logs" class="button" onclick="return confirm('آیا از حذف تمام گزارش‌ها اطمینان دارید؟');">حذف گزارش‌ها</button>
        </form>
    </div>
    
    <!-- جدول گزارش‌ها -->
    <div class="bim-table-container">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>نوع</th>
                    <th>پیام</th>
                    <th>تاریخ</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            
            <tbody>
                <?php if ($logs): ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->id); ?></td>
                            <td>
                                <span class="bim-log-type <?php echo esc_attr($log->type); ?>">
                                    <?php echo esc_html($log->type); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($log->message); ?></td>
                            <td><?php echo esc_html($log->created_at); ?></td>
                            <td>
                                <?php if (!empty($log->data)): ?>
                                    <button type="button" 
                                            class="bim-view-details button" 
                                            data-details='<?php echo esc_attr(json_encode($log->data)); ?>'>
                                        مشاهده جزئیات
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="bim-no-logs">
                            هیچ گزارشی یافت نشد.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- صفحه‌بندی -->
    <?php if ($total_pages > 1): ?>
        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $total_pages,
                    'current' => $page
                ));
                ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- مودال جزئیات -->
<div id="bim-details-modal" class="bim-modal">
    <div class="bim-modal-content">
        <div class="bim-modal-header">
            <h2>جزئیات گزارش</h2>
            <span class="bim-modal-close">&times;</span>
        </div>
        <div class="bim-modal-body">
            <pre id="bim-details-content"></pre>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // پاک کردن فیلترها
    $('#bim-clear-filters').on('click', function() {
        $('#bim-log-type').val('');
        $('#bim-log-date').val('');
        $('#bim-logs-filter').submit();
    });
    
    // خروجی CSV
    $('#bim-export-csv').on('click', function() {
        var $button = $(this);
        var $spinner = $button.next('.spinner');
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');

        var data = {
            action: 'bim_export_logs',
            nonce: '<?php echo wp_create_nonce('bim_export_logs'); ?>',
            type: $('#bim-log-type').val(),
            date: $('#bim-log-date').val()
        };

        $.post(ajaxurl, data, function(response) {
            if (response.success) {
                // ایجاد لینک دانلود
                var link = document.createElement('a');
                link.href = response.data.file_url;
                link.download = response.data.filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } else {
                alert(response.data.message || 'خطا در خروجی گرفتن گزارش‌ها');
            }
        }).fail(function() {
            alert('خطا در ارتباط با سرور');
        }).always(function() {
            $button.prop('disabled', false);
            $spinner.removeClass('is-active');
        });
    });
    
    // نمایش جزئیات در مودال
    $('.bim-view-details').on('click', function(e) {
        e.preventDefault();
        var details = $(this).data('details');
        var modal = $('#bim-details-modal');
        var content = modal.find('.bim-details-content');
        
        content.html('');
        if (typeof details === 'object') {
            for (var key in details) {
                content.append('<p><strong>' + key + ':</strong> ' + details[key] + '</p>');
            }
        } else {
            content.html('<p>' + details + '</p>');
        }
        
        modal.show();
    });
    
    // بستن مودال
    $('.bim-modal-close').on('click', function() {
        $(this).closest('.bim-modal').hide();
    });
    
    $(window).on('click', function(e) {
        if ($(e.target).is('#bim-details-modal')) {
            $('#bim-details-modal').hide();
        }
    });
});
</script> 