<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Invoice {
    private static $instance = null;
    private $api;
    private $logger;
    private $is_processing = false; // فلگ برای جلوگیری از اجرای تکراری
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->logger = BIM_Logger::get_instance();
        
        // تنظیمات پیش‌فرض برای وضعیت‌های فاکتور
        $default_invoice_settings = array(
            'invoice_pending_type' => 'off',
            'invoice_on_hold_type' => 'off',
            'invoice_processing_type' => 'invoice',
            'invoice_complete_type' => 'off',
            'invoice_cancelled_type' => 'off',
            'invoice_refunded_type' => 'off',
            'invoice_failed_type' => 'off',
            'cash_on_delivery' => 'cash',
            'credit_payment' => 'cash'
        );
        
        // حذف هوک‌های قبلی برای جلوگیری از ثبت تکراری
        remove_action('woocommerce_order_status_changed', array($this, 'handle_order_status_change'), 10);
        remove_action('woocommerce_admin_order_status_change', array($this, 'handle_order_status_change'), 10);
        
        // اضافه کردن هوک‌های جدید با اولویت بالاتر
        add_action('woocommerce_order_status_changed', array($this, 'handle_order_status_change'), 20, 3);
        add_action('woocommerce_admin_order_status_change', array($this, 'handle_order_status_change'), 20, 1);
        
        // اضافه کردن هوک برای ثبت کد یکتا در لحظه افزودن محصول به سبد خرید
        add_action('woocommerce_checkout_create_order_line_item', array($this, 'add_unique_id_to_order_item'), 10, 4);

        // اضافه کردن اکشن برای ارسال مجدد سفارش
        add_action('wp_ajax_bim_resend_order', array($this, 'handle_resend_order'));
    }
    
    /**
     * مدیریت تغییر وضعیت سفارش
     */
    public function handle_order_status_change($order_id, $old_status = null, $new_status = null) {
        try {
            // اگر در حال پردازش هستیم، از اجرای مجدد جلوگیری می‌کنیم
            if ($this->is_processing) {
                return;
            }
            
            // تنظیم فلگ پردازش
            $this->is_processing = true;
            
            // اگر فقط order_id دریافت شده باشد (از هوک admin)
            if ($old_status === null && $new_status === null) {
                $order = wc_get_order($order_id);
                if (!$order) {
                    $this->is_processing = false;
                    return;
                }
                $new_status = $order->get_status();
                $old_status = get_post_meta($order_id, '_bim_last_order_status', true);
                
                // ذخیره وضعیت فعلی برای مقایسه بعدی
                update_post_meta($order_id, '_bim_last_order_status', $new_status);
                
                // اگر وضعیت تغییر نکرده باشد، پردازش نکن
                if ($old_status === $new_status) {
                    $this->is_processing = false;
                    return;
                }
            }
            
            // ثبت لاگ فقط در صورت تغییر واقعی وضعیت
            $this->logger->add_log('info', 'تغییر وضعیت سفارش', [
                'order_id' => $order_id,
                'old_status' => $old_status,
                'new_status' => $new_status,
                'hook' => current_filter(),
                'timestamp' => current_time('mysql')
            ]);

            // خواندن تنظیمات از دیتابیس
            $settings = get_option('bim_settings', array());
            if (is_string($settings)) {
                $settings = json_decode($settings, true);
                if (isset($settings['settings'])) {
                    $settings = $settings['settings'];
                }
            }
            
            $invoice_settings = isset($settings['invoice_settings']) ? $settings['invoice_settings'] : array();
            
            // استفاده از تنظیمات پیش‌فرض برای مقادیر تعریف نشده
            $default_invoice_settings = array(
                'invoice_pending_type' => 'off',
                'invoice_on_hold_type' => 'off',
                'invoice_processing_type' => 'invoice',
                'invoice_complete_type' => 'off',
                'invoice_cancelled_type' => 'off',
                'invoice_refunded_type' => 'off',
                'invoice_failed_type' => 'off',
                'cash_on_delivery' => 'cash',
                'credit_payment' => 'cash'
            );
            
            $invoice_settings = wp_parse_args($invoice_settings, $default_invoice_settings);
            
            if (!isset($settings['enable_invoice']) || !$settings['enable_invoice']) {
                $this->logger->add_log('info', 'ارسال فاکتور غیرفعال است', [
                    'order_id' => $order_id
                ]);
                $this->is_processing = false; // بازنشانی فلگ
                return;
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                $this->logger->add_log('error', 'سفارش یافت نشد', [
                    'order_id' => $order_id
                ]);
                $this->is_processing = false; // بازنشانی فلگ
                return;
            }

            // بررسی و اضافه کردن کد یکتا برای آیتم‌های سفارش
            $this->check_and_add_unique_ids($order);

            // بررسی وضعیت فعلی ارسال به وبسرویس
            $web_service_status = get_post_meta($order_id, '_bim_web_service_status', true);
            if ($web_service_status === 'sent') {
                $this->logger->add_log('info', 'فاکتور قبلاً ارسال شده است', [
                    'order_id' => $order_id,
                    'web_service_status' => $web_service_status
                ]);
                $this->is_processing = false; // بازنشانی فلگ
                return;
            }

            // بررسی تنظیمات ارسال بر اساس وضعیت سفارش
            $should_send = false;
            switch ($new_status) {
                case 'pending':
                    $should_send = $invoice_settings['invoice_pending_type'] === 'invoice';
                    break;
                case 'on-hold':
                    $should_send = $invoice_settings['invoice_on_hold_type'] === 'invoice';
                    break;
                case 'processing':
                    $should_send = $invoice_settings['invoice_processing_type'] === 'invoice';
                    break;
                case 'completed':
                    $should_send = $invoice_settings['invoice_complete_type'] === 'invoice';
                    break;
                case 'cancelled':
                    $should_send = $invoice_settings['invoice_cancelled_type'] === 'invoice';
                    break;
                case 'refunded':
                    $should_send = $invoice_settings['invoice_refunded_type'] === 'invoice';
                    break;
                case 'failed':
                    $should_send = $invoice_settings['invoice_failed_type'] === 'invoice';
                    break;
            }

            if (!$should_send) {
                $this->logger->add_log('info', 'ارسال فاکتور برای این وضعیت سفارش فعال نیست', [
                    'order_id' => $order_id,
                    'new_status' => $new_status,
                    'settings' => $invoice_settings
                ]);
                $this->is_processing = false; // بازنشانی فلگ
                return;
            }

            $payment_method = $order->get_payment_method();
            
            // بررسی روش پرداخت
            if ($payment_method === 'cod' && $invoice_settings['cash_on_delivery'] !== 'cash') {
                $this->logger->add_log('info', 'ارسال فاکتور برای پرداخت نقدی غیرفعال است', [
                    'order_id' => $order_id,
                    'payment_method' => $payment_method,
                    'cash_on_delivery' => $invoice_settings['cash_on_delivery']
                ]);
                return;
            }
            
            if ($payment_method === 'credit_payment' && $invoice_settings['credit_payment'] !== 'cash') {
                $this->logger->add_log('info', 'ارسال فاکتور برای پرداخت اعتباری غیرفعال است', [
                    'order_id' => $order_id,
                    'payment_method' => $payment_method,
                    'credit_payment' => $invoice_settings['credit_payment']
                ]);
                return;
            }

            $items = array();
            
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                $variation_id = $item->get_variation_id();
                $unique_id = $item->get_meta('_bim_unique_id');
                
                // دریافت SKU بر اساس نوع محصول
                $sku = '';
                if ($variation_id) {
                    $variation = wc_get_product($variation_id);
                    $sku = $variation ? $variation->get_sku() : '';
                } else {
                    $product = wc_get_product($product_id);
                    $sku = $product ? $product->get_sku() : '';
                }
                
                if (!$unique_id) {
                    $this->logger->add_log('warning', 'کد یکتا برای محصول یافت نشد', [
                        'order_id' => $order_id,
                        'product_id' => $product_id,
                        'variation_id' => $variation_id
                    ]);
                    continue;
                }
                
                $items[] = array(
                    'unique_id' => $unique_id,
                    'sku' => $sku,
                    'quantity' => $item->get_quantity(),
                    'price' => $item->get_total() / $item->get_quantity(),
                    'name' => $item->get_name(),
                    'total' => $item->get_total()
                );
            }
            
            if (empty($items)) {
                $this->logger->add_log('warning', 'هیچ محصولی با کد یکتا یافت نشد', [
                    'order_id' => $order_id
                ]);
                return;
            }
            
            // آماده‌سازی داده‌های سفارش
            $order_data = array(
                'items' => $items,
                'customer' => array(
                    'first_name' => $order->get_billing_first_name(),
                    'last_name' => $order->get_billing_last_name(),
                    'email' => $order->get_billing_email(),
                    'phone' => $order->get_billing_phone(),
                    'mobile' => $order->get_billing_phone(), // برای سازگاری با API
                    'address' => array(
                        'address_1' => $order->get_billing_address_1(),
                        'address_2' => $order->get_billing_address_2(),
                        'city' => $order->get_billing_city(),
                        'state' => $order->get_billing_state(),
                        'postcode' => $order->get_billing_postcode(),
                        'country' => $order->get_billing_country()
                    )
                ),
                'payment_method' => $payment_method,
                'total' => $order->get_total(),
                'shipping_total' => $order->get_shipping_total(),
                'discount_total' => $order->get_discount_total(),
                'tax_total' => $order->get_total_tax(),
                'currency' => $order->get_currency(),
                'status' => $new_status,
                'created_at' => $order->get_date_created()->date('Y-m-d H:i:s'),
                'updated_at' => $order->get_date_modified()->date('Y-m-d H:i:s')
            );
            
            $this->logger->add_log('info', 'آماده‌سازی داده‌های فاکتور', [
                'order_id' => $order_id,
                'items_count' => count($items),
                'total' => $order->get_total()
            ]);
            
            // تنظیم وضعیت در انتظار ارسال
            update_post_meta($order_id, '_bim_web_service_status', '');
            update_post_meta($order_id, '_bim_web_service_message', '');
            
            // ارسال به وبسرویس
            $response = wp_remote_post($this->api->get_api_url() . '/api/invoices/webhook', array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $this->api->get_token()
                ),
                'body' => json_encode(array(
                    'order_id' => $order_id,
                    'customer_mobile' => $order->get_billing_phone(),
                    'order_data' => $order_data
                ))
            ));
            
            if (is_wp_error($response)) {
                // ثبت وضعیت خطا
                update_post_meta($order_id, '_bim_web_service_status', 'false');
                update_post_meta($order_id, '_bim_web_service_message', $response->get_error_message());
                
                $this->logger->add_log('error', 'خطا در ارسال فاکتور به وبسرویس', array(
                    'error' => $response->get_error_message(),
                    'order_id' => $order_id,
                    'error_code' => $response->get_error_code()
                ));
            } else {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                
                if (!$body['success']) {
                    // ثبت وضعیت خطا
                    update_post_meta($order_id, '_bim_web_service_status', 'false');
                    update_post_meta($order_id, '_bim_web_service_message', $body['message'] ?? 'خطای نامشخص');
                    
                    $this->logger->add_log('error', 'خطا در پردازش فاکتور توسط وبسرویس', array(
                        'error' => $body['message'] ?? 'خطای نامشخص',
                        'order_id' => $order_id,
                        'response' => $body
                    ));
                } else {
                    // ذخیره وضعیت ارسال موفق
                    update_post_meta($order_id, '_bim_web_service_status', 'true');
                    update_post_meta($order_id, '_bim_web_service_message', $body['message'] ?? '');
                    
                    $this->logger->add_log('info', 'فاکتور با موفقیت ارسال شد', array(
                        'order_id' => $order_id,
                        'response' => $body,
                        'web_service_status' => 'true',
                        'web_service_message' => $body['message'] ?? ''
                    ));
                }
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در پردازش سفارش', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'order_id' => $order_id ?? null
            ]);
        } finally {
            // در هر صورت فلگ را بازنشانی می‌کنیم
            $this->is_processing = false;
        }
    }
    
    /**
     * افزودن کد یکتا به آیتم سفارش در لحظه ثبت
     */
    public function add_unique_id_to_order_item($item, $cart_item_key, $values, $order) {
        try {
            $product = $values['data'];
            $product_id = $product->get_id();
            
            // دریافت کد یکتا از جدول bim_unique_products
            global $wpdb;
            $unique_id = $wpdb->get_var($wpdb->prepare(
                "SELECT unique_id FROM {$wpdb->prefix}bim_unique_products WHERE product_id = %d OR variation_id = %d",
                $product_id,
                $product_id
            ));
            
            if ($unique_id) {
                $item->add_meta_data('_bim_unique_id', $unique_id, true);
                $this->logger->add_log('info', 'کد یکتا به آیتم سفارش اضافه شد', [
                    'order_id' => $order->get_id(),
                    'product_id' => $product_id,
                    'unique_id' => $unique_id
                ]);
            } else {
                $this->logger->add_log('warning', 'کد یکتا برای محصول یافت نشد', [
                    'order_id' => $order->get_id(),
                    'product_id' => $product_id
                ]);
            }
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در افزودن کد یکتا به آیتم سفارش', [
                'error' => $e->getMessage(),
                'order_id' => $order->get_id(),
                'product_id' => $product_id ?? null
            ]);
        }
    }

    /**
     * بررسی و اضافه کردن کد یکتا برای آیتم‌های سفارش
     */
    private function check_and_add_unique_ids($order) {
        try {
            $updated = false;
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                $variation_id = $item->get_variation_id();
                $unique_id = $item->get_meta('_bim_unique_id');
                
                // دریافت SKU بر اساس نوع محصول
                $sku = '';
                if ($variation_id) {
                    $variation = wc_get_product($variation_id);
                    $sku = $variation ? $variation->get_sku() : '';
                } else {
                    $product = wc_get_product($product_id);
                    $sku = $product ? $product->get_sku() : '';
                }
                
                if (!$unique_id) {
                    // دریافت کد یکتا از جدول bim_unique_products
                    global $wpdb;
                    $unique_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT unique_id FROM {$wpdb->prefix}bim_unique_products WHERE product_id = %d OR variation_id = %d",
                        $product_id,
                        $product_id
                    ));
                    
                    if ($unique_id) {
                        $item->add_meta_data('_bim_unique_id', $unique_id, true);
                        $updated = true;
                        $this->logger->add_log('info', 'کد یکتا به آیتم سفارش اضافه شد', [
                            'order_id' => $order->get_id(),
                            'product_id' => $product_id,
                            'variation_id' => $variation_id,
                            'unique_id' => $unique_id
                        ]);
                    } else {
                        $this->logger->add_log('warning', 'کد یکتا برای محصول یافت نشد', [
                            'order_id' => $order->get_id(),
                            'product_id' => $product_id,
                            'variation_id' => $variation_id
                        ]);
                    }
                }
            }
            
            if ($updated) {
                $order->save();
            }
            
            return $updated;
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در بررسی و اضافه کردن کد یکتا', [
                'error' => $e->getMessage(),
                'order_id' => $order->get_id()
            ]);
            return false;
        }
    }
    
    public function get_invoice($invoice_id) {
        try {
            $response = $this->api->get_invoice($invoice_id);
            
            if (!$response['success']) {
                throw new Exception($response['message'] ?? 'خطا در دریافت اطلاعات فاکتور');
            }
            
            return $response['data'];
            
        } catch (Exception $e) {
            $this->logger->add_log('invoice_info_failed', 'خطا در دریافت اطلاعات فاکتور', array(
                'error' => $e->getMessage(),
                'invoice_id' => $invoice_id
            ));
            
            return false;
        }
    }

    /**
     * هندل کردن درخواست AJAX ارسال مجدد سفارش
     */
    public function handle_resend_order() {
        try {
            // بررسی nonce
            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bim_resend_order')) {
                throw new Exception('توکن امنیتی نامعتبر است');
            }

            // بررسی وجود شناسه سفارش
            if (!isset($_POST['order_id'])) {
                throw new Exception('شناسه سفارش الزامی است');
            }

            $order_id = intval($_POST['order_id']);
            
            // ارسال مجدد سفارش
            $result = $this->api->resend_order($order_id);
            
            if ($result['success']) {
                wp_send_json_success(array(
                    'message' => $result['message']
                ));
            } else {
                wp_send_json_error(array(
                    'message' => $result['message']
                ));
            }

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }
} 