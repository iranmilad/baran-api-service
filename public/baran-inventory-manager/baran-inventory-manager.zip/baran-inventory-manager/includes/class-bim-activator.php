<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Activator {
    public static function activate() {
        // ایجاد جدول لاگ‌ها
        $logger = BIM_Logger::get_instance();
        
        // تنظیم مقادیر پیش‌فرض
        $default_settings = array(
            'enable_price_update' => false,
            'enable_stock_update' => false,
            'enable_name_update' => false,
            'enable_new_product' => false,
            'enable_invoice' => false,
            'enable_cart_sync' => false,
            'rain_sale_price_unit' => 'rial',
            'woocommerce_price_unit' => 'toman',
            'invoice_settings' => array(
                'cash_on_delivery' => 'cash',
                'credit_payment' => 'cash',
                'invoice_pending_type' => 'off',
                'invoice_on_hold_type' => 'off',
                'invoice_processing_type' => 'invoice',
                'invoice_complete_type' => 'off',
                'invoice_cancelled_type' => 'off',
                'invoice_refunded_type' => 'off',
                'invoice_failed_type' => 'off'
            )
        );

        if (!get_option('bim_settings')) {
            add_option('bim_settings', $default_settings, '', 'no');
        }
        
        if (!get_option('bim_api_url')) {
            add_option('bim_api_url', BIM_DEFAULT_API_URL, '', 'no');
        }
        
        // ایجاد زمان‌بندی برای همگام‌سازی خودکار
        if (!wp_next_scheduled('bim_sync_products')) {
            wp_schedule_event(time(), 'hourly', 'bim_sync_products');
        }
        
        if (!wp_next_scheduled('bim_retry_failed_invoices')) {
            wp_schedule_event(time(), 'hourly', 'bim_retry_failed_invoices');
        }
        
        // ایجاد نقش‌های کاربری
        $capabilities = array(
            'read' => true,
            'edit_posts' => true,
            'delete_posts' => true,
            'upload_files' => true,
            'publish_posts' => true,
            'edit_published_posts' => true,
            'delete_published_posts' => true,
            'edit_others_posts' => true,
            'delete_others_posts' => true,
            'manage_categories' => true,
            'moderate_comments' => true,
            'manage_options' => true
        );
        
        add_role('bim_manager', 'مدیر موجودی', $capabilities);
        
        // ایجاد فایل‌های index.php برای امنیت
        $directories = array(
            'languages',
            'assets',
            'assets/css',
            'assets/js',
            'admin',
            'includes',
            'templates'
        );
        
        foreach ($directories as $directory) {
            $index_file = BIM_PLUGIN_DIR . '/' . $directory . '/index.php';
            
            if (!file_exists($index_file)) {
                file_put_contents($index_file, '<?php // Silence is golden.');
            }
        }
    }
} 