<?php
if (!defined('ABSPATH')) {
    exit;
}

// دریافت تنظیمات موجود
$settings = BIM_Settings::get_instance()->get();
$last_sync_error = get_option('bim_last_sync_error');

// پردازش فرم
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bim_settings_nonce'])) {
    if (wp_verify_nonce($_POST['bim_settings_nonce'], 'bim_save_settings')) {
        if (current_user_can('manage_options')) {
            $new_settings = array(
                'settings' => array(
                    'enable_price_update' => isset($_POST['enable_price_update']),
                    'enable_stock_update' => isset($_POST['enable_stock_update']),
                    'enable_name_update' => isset($_POST['enable_name_update']),
                    'enable_new_product' => isset($_POST['enable_new_product']),
                    'enable_invoice' => isset($_POST['enable_invoice']),
                    'enable_cart_sync' => isset($_POST['enable_cart_sync']),
                    'rain_sale_price_unit' => $_POST['rain_sale_price_unit'] ?? 'rial',
                    'woocommerce_price_unit' => $_POST['woocommerce_price_unit'] ?? 'toman',
                    'invoice_settings' => array(
                        'cash_on_delivery' => $_POST['invoice_settings']['cash_on_delivery'] ?? 'cash',
                        'invoice_pending_type' => $_POST['invoice_settings']['invoice_pending_type'] ?? 'off',
                        'invoice_on_hold_type' => $_POST['invoice_settings']['invoice_on_hold_type'] ?? 'off',
                        'invoice_processing_type' => $_POST['invoice_settings']['invoice_processing_type'] ?? 'invoice',
                        'invoice_complete_type' => $_POST['invoice_settings']['invoice_complete_type'] ?? 'off',
                        'invoice_cancelled_type' => $_POST['invoice_settings']['invoice_cancelled_type'] ?? 'off',
                        'invoice_refunded_type' => $_POST['invoice_settings']['invoice_refunded_type'] ?? 'off',
                        'invoice_failed_type' => $_POST['invoice_settings']['invoice_failed_type'] ?? 'off',
                        'credit_payment' => $_POST['invoice_settings']['credit_payment'] ?? 'cash'
                    )
                )
            );
            
            // تلاش برای همگام‌سازی تنظیمات با وب‌سرویس
            $sync_result = BIM_Settings::get_instance()->sync_settings();
            
            // لاگ اطلاعات همگام‌سازی
            BIM_Logger::get_instance()->add_log('info', 'تلاش برای همگام‌سازی تنظیمات', array(
                'settings' => $new_settings['settings'],
                'sync_result' => $sync_result,
                'last_sync_error' => $last_sync_error
            ));
            
            if ($sync_result === true) {
                // به‌روزرسانی تنظیمات محلی
                if (BIM_Settings::get_instance()->update($new_settings['settings'])) {
                    $message = 'تنظیمات با موفقیت ذخیره و همگام‌سازی شد';
                    $message_type = 'success';
                    $settings = $new_settings['settings'];
                    delete_option('bim_last_sync_error');
                    
                    // لاگ موفقیت
                    BIM_Logger::get_instance()->add_log('info', 'تنظیمات با موفقیت ذخیره و همگام‌سازی شد', array(
                        'settings' => $new_settings['settings']
                    ));
                } else {
                    $error_message = 'خطا در ذخیره تنظیمات محلی';
                    $message = $error_message;
                    $message_type = 'error';
                    
                    // لاگ خطای ذخیره محلی با جزئیات بیشتر
                    $error_details = array(
                        'settings' => $new_settings['settings'],
                        'error_type' => 'local_save_error',
                        'error_data' => json_decode(get_option('bim_last_sync_error'), true),
                        'sync_result' => $sync_result,
                        'last_sync_error' => $last_sync_error
                    );
                    
                    BIM_Logger::get_instance()->add_log('error', $error_message, $error_details);
                    
                    // نمایش پیام خطای دقیق‌تر به کاربر
                    if (isset($error_details['error_data']['message'])) {
                        $message .= ': ' . $error_details['error_data']['message'];
                    }
                }
            } else {
                $error_message = 'خطا در همگام‌سازی تنظیمات با وب‌سرویس';
                $message = $error_message;
                $message_type = 'error';
                
                // لاگ خطای همگام‌سازی با جزئیات بیشتر
                $error_details = array(
                    'settings' => $new_settings['settings'],
                    'error_type' => 'sync_error',
                    'sync_result' => $sync_result,
                    'sync_result_type' => gettype($sync_result),
                    'last_sync_error' => $last_sync_error,
                    'error_data' => is_string($sync_result) ? json_decode($sync_result, true) : $sync_result,
                    'request_data' => array(
                        'method' => 'POST',
                        'endpoint' => '/wp-json/wc/v3/settings/sync',
                        'settings' => $new_settings['settings']
                    )
                );
                
                BIM_Logger::get_instance()->add_log('error', $error_message, $error_details);
                
                // نمایش پیام خطای دقیق‌تر به کاربر
                if (is_array($error_details['error_data'])) {
                    if (isset($error_details['error_data']['message'])) {
                        $message .= ': ' . $error_details['error_data']['message'];
                    } elseif (isset($error_details['error_data']['error'])) {
                        $message .= ': ' . $error_details['error_data']['error'];
                    }
                } elseif (is_string($error_details['error_data'])) {
                    $message .= ': ' . $error_details['error_data'];
                }
            }
        } else {
            $error_message = 'دسترسی غیرمجاز';
            $message = $error_message;
            $message_type = 'error';
            
            // لاگ خطای دسترسی
            BIM_Logger::get_instance()->add_log('error', $error_message, array(
                'user_id' => get_current_user_id()
            ));
        }
    } else {
        $error_message = 'توکن امنیتی نامعتبر است';
        $message = $error_message;
        $message_type = 'error';
        
        // لاگ خطای توکن
        BIM_Logger::get_instance()->add_log('error', $error_message);
    }
}
?>

<div class="wrap bim-admin">
    <h1>تنظیمات دستیار فروشگاهی باران</h1>
    
    <?php if ($last_sync_error): ?>
    <div class="notice notice-warning is-dismissible">
        <p>دریافت تنظیمات از سرور با خطا مواجه شده است. تنظیمات محلی ممکن است به‌روز نباشد. برای دریافت آخرین تنظیمات، صفحه را مجدداً بارگذاری کنید.</p>
    </div>
    <?php endif; ?>
    
    <?php if ($message): ?>
    <div class="notice notice-<?php echo $message_type; ?> is-dismissible">
        <p><?php echo esc_html($message); ?></p>
    </div>
    <?php endif; ?>
    
    <form id="bim-settings-form" method="post">
        <?php wp_nonce_field('bim_save_settings', 'bim_settings_nonce'); ?>
        
            <div class="bim-card">
            <h3>تنظیمات همگام‌سازی محصولات</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                        <label for="enable_price_update">بروزرسانی قیمت</label>
                    </th>
                    <td>
                        <label class="bim-switch">
                            <input type="checkbox" id="enable_price_update" name="enable_price_update" 
                                   <?php checked($settings['enable_price_update'] ?? false); ?>>
                            <span class="slider round"></span>
                        </label>
                        <p class="description">فعال‌سازی بروزرسانی خودکار قیمت محصولات</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="enable_stock_update">بروزرسانی موجودی</label>
                    </th>
                    <td>
                        <label class="bim-switch">
                            <input type="checkbox" id="enable_stock_update" name="enable_stock_update" 
                                   <?php checked($settings['enable_stock_update'] ?? false); ?>>
                            <span class="slider round"></span>
                        </label>
                        <p class="description">فعال‌سازی بروزرسانی خودکار موجودی محصولات</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="enable_name_update">بروزرسانی نام</label>
                    </th>
                    <td>
                        <label class="bim-switch">
                            <input type="checkbox" id="enable_name_update" name="enable_name_update" 
                                   <?php checked($settings['enable_name_update'] ?? false); ?>>
                            <span class="slider round"></span>
                        </label>
                        <p class="description">فعال‌سازی بروزرسانی خودکار نام محصولات</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="enable_new_product">افزودن محصول جدید</label>
                        </th>
                        <td>
                        <label class="bim-switch">
                            <input type="checkbox" id="enable_new_product" name="enable_new_product" 
                                   <?php checked($settings['enable_new_product'] ?? false); ?>>
                            <span class="slider round"></span>
                        </label>
                        <p class="description">فعال‌سازی افزودن خودکار محصولات جدید</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="bim-card">
            <h3>تنظیمات واحد تبدیل قیمت</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                        <label for="rain_sale_price_unit">واحد قیمت در باران</label>
                        </th>
                        <td>
                        <select name="rain_sale_price_unit" id="rain_sale_price_unit" class="regular-text">
                            <option value="rial" <?php selected($settings['rain_sale_price_unit'] ?? 'rial', 'rial'); ?>>ریال</option>
                            <option value="toman" <?php selected($settings['rain_sale_price_unit'] ?? 'rial', 'toman'); ?>>تومان</option>
                        </select>
                        <p class="description">واحد قیمت در نرم‌افزار باران</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                        <label for="woocommerce_price_unit">واحد قیمت در ووکامرس</label>
                        </th>
                        <td>
                        <select name="woocommerce_price_unit" id="woocommerce_price_unit" class="regular-text">
                            <option value="rial" <?php selected($settings['woocommerce_price_unit'] ?? 'toman', 'rial'); ?>>ریال</option>
                            <option value="toman" <?php selected($settings['woocommerce_price_unit'] ?? 'toman', 'toman'); ?>>تومان</option>
                        </select>
                        <p class="description">واحد قیمت در فروشگاه ووکامرس</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="bim-card">
            <h3>تنظیمات سبد خرید</h3>
                <table class="form-table">
                    <tr>
                    <th scope="row">
                        <label for="enable_cart_sync">همگام‌سازی سبد خرید</label>
                    </th>
                    <td>
                        <label class="bim-switch">
                            <input type="checkbox" id="enable_cart_sync" name="enable_cart_sync" 
                                   <?php checked($settings['enable_cart_sync'] ?? false); ?>>
                            <span class="slider round"></span>
                            </label>
                        <p class="description">فعال‌سازی همگام‌سازی خودکار سبد خرید با نرم‌افزار فروشگاهی</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="bim-card">
                <h3>تنظیمات فاکتور</h3>
                <table class="form-table">
                    <tr>
                    <th scope="row">
                        <label for="enable_invoice">فعال‌سازی فاکتور</label>
                    </th>
                    <td>
                        <label class="bim-switch">
                            <input type="checkbox" id="enable_invoice" name="enable_invoice" 
                                   <?php checked($settings['enable_invoice'] ?? false); ?>>
                            <span class="slider round"></span>
                            </label>
                        <p class="description">فعال‌سازی ارسال خودکار فاکتور به نرم‌افزار فروشگاهی</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">نوع پرداخت</th>
                    <td>
                        <div class="payment-type-settings">
                            <div class="payment-row">
                                <label>پرداخت در محل:</label>
                                <select name="invoice_settings[cash_on_delivery]" class="regular-text">
                                    <option value="cash" <?php selected($settings['invoice_settings']['cash_on_delivery'] ?? 'cash', 'cash'); ?>>نقدی</option>
                                    <option value="credit" <?php selected($settings['invoice_settings']['cash_on_delivery'] ?? 'cash', 'credit'); ?>>نسیه</option>
                                </select>
                            </div>
                            <div class="payment-row">
                                <label>پرداخت اعتباری:</label>
                                <select name="invoice_settings[credit_payment]" class="regular-text">
                                    <option value="cash" <?php selected($settings['invoice_settings']['credit_payment'] ?? 'cash', 'cash'); ?>>نقدی</option>
                                    <option value="credit" <?php selected($settings['invoice_settings']['credit_payment'] ?? 'cash', 'credit'); ?>>نسیه</option>
                                </select>
                            </div>
                        </div>
                        <p class="description">نوع پرداخت پیش‌فرض برای هر روش پرداخت</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">وضعیت ثبت فاکتور</th>
                    <td>
                        <div class="invoice-status-settings">
                            <div class="status-row">
                                <label>در انتظار پرداخت:</label>
                                <select name="invoice_settings[invoice_pending_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_pending_type'] ?? 'off', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_pending_type'] ?? 'off', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_pending_type'] ?? 'off', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_pending_type'] ?? 'off', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                            <div class="status-row">
                                <label>در انتظار بررسی:</label>
                                <select name="invoice_settings[invoice_on_hold_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_on_hold_type'] ?? 'off', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_on_hold_type'] ?? 'off', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_on_hold_type'] ?? 'off', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_on_hold_type'] ?? 'off', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                            <div class="status-row">
                                <label>در حال پردازش:</label>
                                <select name="invoice_settings[invoice_processing_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_processing_type'] ?? 'invoice', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_processing_type'] ?? 'invoice', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_processing_type'] ?? 'invoice', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_processing_type'] ?? 'invoice', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                            <div class="status-row">
                                <label>تکمیل شده:</label>
                                <select name="invoice_settings[invoice_complete_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_complete_type'] ?? 'off', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_complete_type'] ?? 'off', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_complete_type'] ?? 'off', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_complete_type'] ?? 'off', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                            <div class="status-row">
                                <label>لغو شده:</label>
                                <select name="invoice_settings[invoice_cancelled_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_cancelled_type'] ?? 'off', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_cancelled_type'] ?? 'off', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_cancelled_type'] ?? 'off', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_cancelled_type'] ?? 'off', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                            <div class="status-row">
                                <label>مسترد شده:</label>
                                <select name="invoice_settings[invoice_refunded_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_refunded_type'] ?? 'off', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_refunded_type'] ?? 'off', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_refunded_type'] ?? 'off', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_refunded_type'] ?? 'off', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                            <div class="status-row">
                                <label>ناموفق:</label>
                                <select name="invoice_settings[invoice_failed_type]" class="regular-text">
                                    <option value="off" <?php selected($settings['invoice_settings']['invoice_failed_type'] ?? 'off', 'off'); ?>>خاموش</option>
                                    <option value="invoice" <?php selected($settings['invoice_settings']['invoice_failed_type'] ?? 'off', 'invoice'); ?>>فاکتور</option>
                                    <option value="proforma" <?php selected($settings['invoice_settings']['invoice_failed_type'] ?? 'off', 'proforma'); ?>>پیش فاکتور</option>
                                    <option value="order" <?php selected($settings['invoice_settings']['invoice_failed_type'] ?? 'off', 'order'); ?>>سفارش</option>
                                </select>
                            </div>
                        </div>
                        <p class="description">نوع ثبت فاکتور برای هر مرحله از سفارش</p>
                    </td>
                </tr>
                </table>
        </div>
        
        <p class="submit">
            <button type="submit" class="button button-primary">ذخیره تنظیمات</button>
        </p>
    </form>
</div>

<style>
.bim-admin {
    margin: 20px;
}

.bim-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    max-width: 800px;
    margin-bottom: 20px;
}

.bim-card h3 {
    margin-top: 0;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
    color: #23282d;
    font-size: 1.3em;
}

.form-table th {
    width: 200px;
    padding: 15px 10px;
    font-weight: 600;
}

.form-table td {
    padding: 15px 10px;
}

.description {
    color: #666;
    font-style: italic;
    margin: 5px 0 0;
}

.submit {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}

/* استایل کلید تغییر وضعیت */
.bim-switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 24px;
}

.bim-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
}

.slider:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
}

input:checked + .slider {
    background-color: #2271b1;
}

input:focus + .slider {
    box-shadow: 0 0 1px #2271b1;
}

input:checked + .slider:before {
    transform: translateX(26px);
}

.slider.round {
    border-radius: 24px;
}

.slider.round:before {
    border-radius: 50%;
}

/* استایل چک‌باکس */
.bim-checkbox {
    display: block;
    margin-bottom: 10px;
    font-size: 14px;
}

.bim-checkbox input[type="checkbox"] {
    margin-right: 8px;
}

/* استایل رادیو باتن */
.bim-radio {
    display: block;
    margin-bottom: 10px;
    font-size: 14px;
}

.bim-radio input[type="radio"] {
    margin-right: 8px;
}

/* استایل نوتیس */
.notice {
    margin: 15px 0;
    padding: 10px 15px;
    border-radius: 4px;
}

.notice-success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
}

.notice-error {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
}

.invoice-status-settings {
    margin: 10px 0;
}

.status-row {
    margin-bottom: 10px;
    display: flex;
    align-items: center;
}

.status-row label {
    width: 150px;
    font-weight: 600;
}

.status-row select {
    width: 200px;
}

.payment-type-settings {
    margin: 10px 0;
}

.payment-row {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

.payment-row label {
    width: 150px;
    font-weight: 600;
}

.payment-row select {
    width: 200px;
}
</style> 