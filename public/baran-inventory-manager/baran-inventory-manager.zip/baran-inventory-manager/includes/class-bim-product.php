<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Product {
    private static $instance = null;
    private $api;
    private $logger;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->logger = BIM_Logger::get_instance();
        
        // هوک برای به‌روزرسانی خودکار محصولات
        add_action('woocommerce_update_product', array($this, 'update_product'), 10, 1);
        add_action('woocommerce_update_product_variation', array($this, 'update_variation'), 10, 1);
    }
    
    public function get_product_info($isbn) {
        try {
            $response = $this->api->get_product_info($isbn);
            
            if (!$response['success']) {
                throw new Exception($response['message'] ?? 'خطا در دریافت اطلاعات محصول');
            }
            
            return $response['data'];
            
        } catch (Exception $e) {
            $this->logger->add_log('product_info_failed', 'خطا در دریافت اطلاعات محصول', array(
                'error' => $e->getMessage(),
                'isbn' => $isbn
            ));
            
            return false;
        }
    }
    
    public function update_product($product_id) {
        try {
            $settings = get_option('bim_settings', BIM_DEFAULT_SETTINGS);
            
            if (!$settings['enable_price_update'] && !$settings['enable_stock_update'] && !$settings['enable_name_update']) {
                return;
            }
            
            $isbn = get_post_meta($product_id, '_isbn', true);
            
            if (!$isbn) {
                return;
            }
            
            $product_info = $this->get_product_info($isbn);
            
            if (!$product_info) {
                return;
            }
            
            $data = array();
            
            // به‌روزرسانی قیمت
            if ($settings['enable_price_update']) {
                $data['price'] = $product_info['price'];
            }
            
            // به‌روزرسانی موجودی
            if ($settings['enable_stock_update']) {
                $data['stock'] = $product_info['stock'];
            }
            
            // به‌روزرسانی نام
            if ($settings['enable_name_update']) {
                $data['name'] = $product_info['name'];
            }
            
            if (!empty($data)) {
                $response = $this->api->update_product($product_id, $data);
                
                if (!$response['success']) {
                    throw new Exception($response['message'] ?? 'خطا در به‌روزرسانی محصول در وب‌سرویس');
                }
                
                // به‌روزرسانی محصول در ووکامرس
                if (isset($data['price'])) {
                    update_post_meta($product_id, '_regular_price', $data['price']);
                    update_post_meta($product_id, '_price', $data['price']);
                }
                
                if (isset($data['stock'])) {
                    update_post_meta($product_id, '_stock', $data['stock']);
                    update_post_meta($product_id, '_stock_status', $data['stock'] > 0 ? 'instock' : 'outofstock');
                }
                
                if (isset($data['name'])) {
                    wp_update_post(array(
                        'ID' => $product_id,
                        'post_title' => $data['name']
                    ));
                }
                
                $this->api->update_product_last_sync_time($product_id);
                
                $this->logger->add_log('product_updated', 'محصول با موفقیت به‌روزرسانی شد', array(
                    'product_id' => $product_id,
                    'isbn' => $isbn,
                    'data' => $data
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('product_update_failed', 'خطا در به‌روزرسانی محصول', array(
                'error' => $e->getMessage(),
                'product_id' => $product_id,
                'isbn' => $isbn
            ));
        }
    }
    
    public function update_variation($variation_id) {
        try {
            $settings = get_option('bim_settings', BIM_DEFAULT_SETTINGS);
            
            if (!$settings['enable_price_update'] && !$settings['enable_stock_update']) {
                return;
            }
            
            $isbn = get_post_meta($variation_id, '_isbn', true);
            
            if (!$isbn) {
                return;
            }
            
            $product_info = $this->get_product_info($isbn);
            
            if (!$product_info) {
                return;
            }
            
            $data = array();
            
            // به‌روزرسانی قیمت
            if ($settings['enable_price_update']) {
                $data['price'] = $product_info['price'];
            }
            
            // به‌روزرسانی موجودی
            if ($settings['enable_stock_update']) {
                $data['stock'] = $product_info['stock'];
            }
            
            if (!empty($data)) {
                $response = $this->api->update_variation($variation_id, $data);
                
                if (!$response['success']) {
                    throw new Exception($response['message'] ?? 'خطا در به‌روزرسانی متغیر محصول در وب‌سرویس');
                }
                
                // به‌روزرسانی متغیر محصول در ووکامرس
                if (isset($data['price'])) {
                    update_post_meta($variation_id, '_regular_price', $data['price']);
                    update_post_meta($variation_id, '_price', $data['price']);
                }
                
                if (isset($data['stock'])) {
                    update_post_meta($variation_id, '_stock', $data['stock']);
                    update_post_meta($variation_id, '_stock_status', $data['stock'] > 0 ? 'instock' : 'outofstock');
                }
                
                $this->api->update_variation_last_sync_time($variation_id);
                
                $this->logger->add_log('variation_updated', 'متغیر محصول با موفقیت به‌روزرسانی شد', array(
                    'variation_id' => $variation_id,
                    'isbn' => $isbn,
                    'data' => $data
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('variation_update_failed', 'خطا در به‌روزرسانی متغیر محصول', array(
                'error' => $e->getMessage(),
                'variation_id' => $variation_id,
                'isbn' => $isbn
            ));
        }
    }
    
    public function create_product($isbn) {
        try {
            $settings = get_option('bim_settings', BIM_DEFAULT_SETTINGS);
            
            if (!$settings['enable_new_product']) {
                return false;
            }
            
            $product_info = $this->get_product_info($isbn);
            
            if (!$product_info) {
                return false;
            }
            
            // ایجاد محصول جدید در ووکامرس
            $product = new WC_Product_Simple();
            
            $product->set_name($product_info['name']);
            $product->set_regular_price($product_info['price']);
            $product->set_stock_quantity($product_info['stock']);
            $product->set_stock_status($product_info['stock'] > 0 ? 'instock' : 'outofstock');
            
            $product_id = $product->save();
            
            if (!$product_id) {
                throw new Exception('خطا در ایجاد محصول در ووکامرس');
            }
            
            // ذخیره ISBN
            update_post_meta($product_id, '_isbn', $isbn);
            
            $this->api->update_product_last_sync_time($product_id);
            
            $this->logger->add_log('product_created', 'محصول جدید با موفقیت ایجاد شد', array(
                'product_id' => $product_id,
                'isbn' => $isbn,
                'product_info' => $product_info
            ));
            
            return $product_id;
            
        } catch (Exception $e) {
            $this->logger->add_log('product_creation_failed', 'خطا در ایجاد محصول جدید', array(
                'error' => $e->getMessage(),
                'isbn' => $isbn
            ));
            
            return false;
        }
    }
} 