<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Deactivator {
    public static function deactivate() {
        // حذف زمان‌بندی‌ها
        wp_clear_scheduled_hook('bim_sync_products');
        wp_clear_scheduled_hook('bim_retry_failed_invoices');
        
        // حذف نقش کاربری
        remove_role('bim_manager');
    }
} 