<?php
if (!defined('ABSPATH')) {
    exit;
}

$logger = BIM_Logger::get_instance();

$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 20;

$logs = $logger->get_logs($type, $per_page, ($page - 1) * $per_page);
$total_logs = $logger->get_log_count($type);
$total_pages = ceil($total_logs / $per_page);

$log_types = array(
    'product_updated' => 'به‌روزرسانی محصول',
    'variation_updated' => 'به‌روزرسانی متغیر محصول',
    'product_created' => 'ایجاد محصول',
    'invoice_created' => 'ایجاد فاکتور',
    'cart_synced' => 'همگام‌سازی سبد خرید',
    'product_info_failed' => 'خطا در دریافت اطلاعات محصول',
    'product_update_failed' => 'خطا در به‌روزرسانی محصول',
    'variation_update_failed' => 'خطا در به‌روزرسانی متغیر محصول',
    'product_creation_failed' => 'خطا در ایجاد محصول',
    'invoice_creation_failed' => 'خطا در ایجاد فاکتور',
    'cart_sync_failed' => 'خطا در همگام‌سازی سبد خرید',
    'license_verification_failed' => 'خطا در بررسی لایسنس',
    'license_activation_failed' => 'خطا در فعال‌سازی لایسنس',
    'license_deactivation_failed' => 'خطا در غیرفعال‌سازی لایسنس',
    'settings_update_failed' => 'خطا در به‌روزرسانی تنظیمات'
);
?>

<div class="wrap">
    <h1>لاگ‌های مدیریت موجودی</h1>
    
    <div class="tablenav top">
        <div class="alignleft actions">
            <form method="get">
                <input type="hidden" name="page" value="bim-logs">
                
                <select name="type">
                    <option value="">همه انواع</option>
                    <?php foreach ($log_types as $key => $label) : ?>
                        <option value="<?php echo esc_attr($key); ?>" <?php selected($type, $key); ?>>
                            <?php echo esc_html($label); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <?php submit_button('فیلتر', 'secondary', 'submit', false); ?>
            </form>
        </div>
        
        <?php if ($total_pages > 1) : ?>
            <div class="tablenav-pages">
                <span class="displaying-num">
                    <?php printf(_n('%s مورد', '%s مورد', $total_logs), number_format_i18n($total_logs)); ?>
                </span>
                
                <span class="pagination-links">
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $page
                    ));
                    ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>نوع</th>
                <th>پیام</th>
                <th>داده‌ها</th>
                <th>تاریخ</th>
            </tr>
        </thead>
        
        <tbody>
            <?php if (empty($logs)) : ?>
                <tr>
                    <td colspan="4">موردی یافت نشد.</td>
                </tr>
            <?php else : ?>
                <?php foreach ($logs as $log) : ?>
                    <tr>
                        <td><?php echo esc_html($log_types[$log->type] ?? $log->type); ?></td>
                        <td><?php echo esc_html($log->message); ?></td>
                        <td>
                            <?php if (!empty($log->data)) : ?>
                                <pre><?php echo esc_html(json_encode($log->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($log->created_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="tablenav bottom">
        <div class="alignleft actions">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="bim_clear_logs">
                <?php wp_nonce_field('bim_clear_logs'); ?>
                
                <?php if ($type) : ?>
                    <input type="hidden" name="type" value="<?php echo esc_attr($type); ?>">
                <?php endif; ?>
                
                <?php submit_button('پاک کردن لاگ‌ها', 'delete', 'submit', false); ?>
            </form>
        </div>
        
        <?php if ($total_pages > 1) : ?>
            <div class="tablenav-pages">
                <span class="displaying-num">
                    <?php printf(_n('%s مورد', '%s مورد', $total_logs), number_format_i18n($total_logs)); ?>
                </span>
                
                <span class="pagination-links">
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $page
                    ));
                    ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
</div> 