jQuery(document).ready(function($) {
    // اگر در صفحه پلاگین نیستیم، هیچ کاری انجام نده
    if (typeof bimAdmin === 'undefined' || !bimAdmin.is_plugin_page) {
        return;
    }

    // تست اتصال به سرور
    function testConnection() {
        var $button = $('#bim-test-connection');
        var $spinner = $button.find('.spinner');
        var originalText = $button.text();
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
        $button.text(bimAdmin.strings.testing);
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_test_connection',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $button.text(bimAdmin.strings.connected);
                    $button.removeClass('button-secondary').addClass('button-primary');
                } else {
                    $button.text(bimAdmin.strings.disconnected);
                    $button.removeClass('button-primary').addClass('button-secondary');
                }
            },
            error: function() {
                $button.text(bimAdmin.strings.disconnected);
                $button.removeClass('button-primary').addClass('button-secondary');
            },
            complete: function() {
                $spinner.removeClass('is-active');
                setTimeout(function() {
                    $button.text(originalText);
                    $button.prop('disabled', false);
                }, 2000);
            }
        });
    }

    // ذخیره تنظیمات
    $('#bim-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $submit = $form.find('input[type="submit"]');
        var $spinner = $submit.find('.spinner');
        var originalText = $submit.val();
        
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_save_settings',
                nonce: bimAdmin.nonce,
                settings: $form.serialize()
            },
            success: function(response) {
                if (response.success) {
                    $submit.val(bimAdmin.strings.saved);
                    $submit.removeClass('button-secondary').addClass('button-primary');
                } else {
                    $submit.val(bimAdmin.strings.error);
                    $submit.removeClass('button-primary').addClass('button-secondary');
                }
            },
            error: function() {
                $submit.val(bimAdmin.strings.error);
                $submit.removeClass('button-primary').addClass('button-secondary');
            },
            complete: function() {
                $spinner.removeClass('is-active');
                setTimeout(function() {
                    $submit.val(originalText);
                    $submit.prop('disabled', false);
                }, 2000);
            }
        });
    });

    // فعال‌سازی لایسنس
    $('#bim-activate-license').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $spinner = $button.find('.spinner');
        var originalText = $button.text();
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_activate_license',
                nonce: bimAdmin.nonce,
                license_key: $('#bim-license-key').val()
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $spinner.removeClass('is-active');
                $button.text(originalText);
                $button.prop('disabled', false);
            }
        });
    });

    // غیرفعال‌سازی لایسنس
    $('#bim-deactivate-license').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('آیا از غیرفعال‌سازی لایسنس اطمینان دارید؟')) {
            return;
        }
        
        var $button = $(this);
        var $spinner = $button.find('.spinner');
        var originalText = $button.text();
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_deactivate_license',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $spinner.removeClass('is-active');
                $button.text(originalText);
                $button.prop('disabled', false);
            }
        });
    });

    // تست کانکشن
    $('#bim-test-connection').on('click', testConnection);
    
    // فعال‌سازی لایسنس
    $('#bim-activate-license').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $message = $('#bim-activate-license-message');
        var $licenseKey = $('#bim-license-key');
        
        if (!$licenseKey.val()) {
            $message.html('لطفا لایسنس را وارد کنید.').removeClass('notice-success notice-info').addClass('notice-error');
            return;
        }
        
        $button.prop('disabled', true);
        $message.html('در حال فعال‌سازی لایسنس...').removeClass('notice-success notice-error').addClass('notice-info');
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_activate_license',
                nonce: bimAdmin.nonce,
                license_key: $licenseKey.val()
            },
            success: function(response) {
                if (response.success) {
                    $message.html('لایسنس با موفقیت فعال شد.').removeClass('notice-info notice-error').addClass('notice-success');
                    location.reload();
                } else {
                    $message.html('خطا در فعال‌سازی لایسنس: ' + response.data).removeClass('notice-info notice-success').addClass('notice-error');
                }
            },
            error: function() {
                $message.html('خطا در ارسال درخواست به سرور.').removeClass('notice-info notice-success').addClass('notice-error');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
    
    // غیرفعال‌سازی لایسنس
    $('#bim-deactivate-license').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $message = $('#bim-deactivate-license-message');
        
        if (!confirm('آیا از غیرفعال‌سازی لایسنس اطمینان دارید؟')) {
            return;
        }
        
        $button.prop('disabled', true);
        $message.html('در حال غیرفعال‌سازی لایسنس...').removeClass('notice-success notice-error').addClass('notice-info');
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_deactivate_license',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $message.html('لایسنس با موفقیت غیرفعال شد.').removeClass('notice-info notice-error').addClass('notice-success');
                    location.reload();
                } else {
                    $message.html('خطا در غیرفعال‌سازی لایسنس: ' + response.data).removeClass('notice-info notice-success').addClass('notice-error');
                }
            },
            error: function() {
                $message.html('خطا در ارسال درخواست به سرور.').removeClass('notice-info notice-success').addClass('notice-error');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
    
    // پاک کردن لاگ‌ها
    $('#bim-clear-logs').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $message = $('#bim-clear-logs-message');
        
        if (!confirm('آیا از پاک کردن لاگ‌ها اطمینان دارید؟')) {
            return;
        }
        
        $button.prop('disabled', true);
        $message.html('در حال پاک کردن لاگ‌ها...').removeClass('notice-success notice-error').addClass('notice-info');
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_clear_logs',
                nonce: bimAdmin.nonce,
                type: $('#bim-log-type').val()
            },
            success: function(response) {
                if (response.success) {
                    $message.html('لاگ‌ها با موفقیت پاک شدند.').removeClass('notice-info notice-error').addClass('notice-success');
                    location.reload();
                } else {
                    $message.html('خطا در پاک کردن لاگ‌ها: ' + response.data).removeClass('notice-info notice-success').addClass('notice-error');
                }
            },
            error: function() {
                $message.html('خطا در ارسال درخواست به سرور.').removeClass('notice-info notice-success').addClass('notice-error');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
    
    // همگام‌سازی محصولات
    $('#bim-sync-products').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $message = $('#bim-sync-products-message');
        
        $button.prop('disabled', true);
        $message.html('در حال همگام‌سازی محصولات...').removeClass('notice-success notice-error').addClass('notice-info');
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_sync_products',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $message.html('محصولات با موفقیت همگام‌سازی شدند.').removeClass('notice-info notice-error').addClass('notice-success');
                } else {
                    $message.html('خطا در همگام‌سازی محصولات: ' + response.data).removeClass('notice-info notice-success').addClass('notice-error');
                }
            },
            error: function() {
                $message.html('خطا در ارسال درخواست به سرور.').removeClass('notice-info notice-success').addClass('notice-error');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
    
    // ارسال مجدد فاکتورهای ناموفق
    $('#bim-retry-failed-invoices').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $message = $('#bim-retry-failed-invoices-message');
        
        $button.prop('disabled', true);
        $message.html('در حال ارسال مجدد فاکتورهای ناموفق...').removeClass('notice-success notice-error').addClass('notice-info');
        
        $.ajax({
            url: bimAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'bim_retry_failed_invoices',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $message.html('فاکتورهای ناموفق با موفقیت ارسال شدند.').removeClass('notice-info notice-error').addClass('notice-success');
                } else {
                    $message.html('خطا در ارسال مجدد فاکتورهای ناموفق: ' + response.data).removeClass('notice-info notice-success').addClass('notice-error');
                }
            },
            error: function() {
                $message.html('خطا در ارسال درخواست به سرور.').removeClass('notice-info notice-success').addClass('notice-error');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
    
    // نمایش جزئیات گزارش
    $('.bim-view-details').on('click', function() {
        var details = $(this).data('details');
        var $modal = $('#bim-details-modal');
        var $modalContent = $('#bim-details-content');
        
        $modalContent.text(JSON.stringify(details, null, 2));
        $modal.show();
    });
    
    // بستن مودال
    $('.bim-modal-close').on('click', function() {
        $('#bim-details-modal').hide();
    });
    
    $(window).on('click', function(e) {
        if ($(e.target).is('#bim-details-modal')) {
            $('#bim-details-modal').hide();
        }
    });
    
    // فیلتر کردن گزارش‌ها
    $('#bim-filter-logs').on('click', function() {
        var type = $('#bim-log-type').val();
        var date = $('#bim-log-date').val();
        
        window.location.href = addQueryParam(window.location.href, {
            type: type,
            date: date,
            paged: 1
        });
    });
    
    // پاک کردن فیلترها
    $('#bim-clear-filters').on('click', function() {
        window.location.href = removeQueryParams(window.location.href, ['type', 'date', 'paged']);
    });
    
    // خروجی CSV
    $('#bim-export-logs').on('click', function() {
        var type = $('#bim-log-type').val();
        var date = $('#bim-log-date').val();
        
        window.location.href = addQueryParam(bimAdmin.ajaxUrl, {
            action: 'bim_export_logs',
            nonce: bimAdmin.nonce,
            type: type,
            date: date
        });
    });
    
    // نمایش پیام
    function showMessage(type, message) {
        var $message = $('<div class="bim-message ' + type + '">' + message + '</div>');
        $('.bim-admin').prepend($message);
        
        setTimeout(function() {
            $message.fadeOut(function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    // توابع کمکی
    function addQueryParam(url, params) {
        var separator = url.indexOf('?') !== -1 ? '&' : '?';
        var query = [];
        
        for (var key in params) {
            if (params[key]) {
                query.push(key + '=' + encodeURIComponent(params[key]));
            }
        }
        
        return url + separator + query.join('&');
    }
    
    function removeQueryParams(url, params) {
        var urlObj = new URL(url);
        
        params.forEach(function(param) {
            urlObj.searchParams.delete(param);
        });
        
        return urlObj.toString();
    }
    
    // بستن اطلاعیه‌ها
    $('.bim-notification .notice-dismiss').on('click', function() {
        var $notice = $(this).closest('.bim-notification');
        var notificationId = $notice.data('notification-id');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_dismiss_notification',
                notification_id: notificationId,
                nonce: '<?php echo wp_create_nonce("bim_dismiss_notification"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $notice.fadeOut();
                } else {
                    alert('خطا در بستن اطلاعیه: ' + response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            }
        });
    });
}); 