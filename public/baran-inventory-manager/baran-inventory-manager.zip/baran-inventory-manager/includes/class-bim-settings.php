<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Settings {
    private static $instance = null;
    private $options;
    private $api;
    private $logger;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->logger = BIM_Logger::get_instance();
        
        // تنظیمات پیش‌فرض
        $default_settings = array(
            'enable_price_update' => false,
            'enable_stock_update' => false,
            'enable_name_update' => false,
            'enable_new_product' => false,
            'enable_invoice' => false,
            'enable_cart_sync' => false,
            'rain_sale_price_unit' => 'rial',
            'woocommerce_price_unit' => 'toman',
            'invoice_settings' => array(
                'cash_on_delivery' => 'cash',
                'credit_payment' => 'cash',
                'invoice_pending_type' => 'off',
                'invoice_on_hold_type' => 'off',
                'invoice_processing_type' => 'invoice',
                'invoice_complete_type' => 'off',
                'invoice_cancelled_type' => 'off',
                'invoice_refunded_type' => 'off',
                'invoice_failed_type' => 'off'
            )
        );
        
        // خواندن تنظیمات از دیتابیس
        $saved_settings = get_option('bim_settings');
        if ($saved_settings) {
            try {
                // اگر تنظیمات به صورت JSON ذخیره شده باشند
                if (is_string($saved_settings)) {
                    $decoded = json_decode($saved_settings, true);
                    if (isset($decoded['settings'])) {
                        $this->options = $decoded['settings'];
                    } else {
                        $this->options = $decoded;
                    }
                } else {
                    $this->options = $saved_settings;
                }
            } catch (Exception $e) {
                $this->logger->add_log('error', 'خطا در خواندن تنظیمات: ' . $e->getMessage());
                $this->options = $default_settings;
            }
        } else {
            $this->options = $default_settings;
        }
    }

    private function is_json($string) {
        json_decode($string);
        return json_last_error() === JSON_ERROR_NONE;
    }

    public function get($key = null, $default = null) {
        try {
            // تلاش برای دریافت تنظیمات از وب‌سرویس
            $response = $this->api->request('settings', 'GET');
            
            if ($response['success']) {
                // تنظیمات در data قرار دارند
                $settings = $response['data'];
                
                // تبدیل داده‌های دریافتی به فرمت مورد نیاز
                $formatted_settings = array(
                    'enable_price_update' => (bool)($settings['enable_price_update'] ?? false),
                    'enable_stock_update' => (bool)($settings['enable_stock_update'] ?? false),
                    'enable_name_update' => (bool)($settings['enable_name_update'] ?? false),
                    'enable_new_product' => (bool)($settings['enable_new_product'] ?? false),
                    'enable_invoice' => (bool)($settings['enable_invoice'] ?? false),
                    'enable_cart_sync' => (bool)($settings['enable_cart_sync'] ?? false),
                    'rain_sale_price_unit' => (string)($settings['rain_sale_price_unit'] ?? 'rial'),
                    'woocommerce_price_unit' => (string)($settings['woocommerce_price_unit'] ?? 'toman'),
                    'invoice_settings' => array(
                        'cash_on_delivery' => (string)($settings['invoice_settings']['cash_on_delivery'] ?? 'cash'),
                        'credit_payment' => (string)($settings['invoice_settings']['credit_payment'] ?? 'cash'),
                        'invoice_pending_type' => (string)($settings['invoice_settings']['invoice_pending_type'] ?? 'off'),
                        'invoice_on_hold_type' => (string)($settings['invoice_settings']['invoice_on_hold_type'] ?? 'off'),
                        'invoice_processing_type' => (string)($settings['invoice_settings']['invoice_processing_type'] ?? 'invoice'),
                        'invoice_complete_type' => (string)($settings['invoice_settings']['invoice_complete_type'] ?? 'off'),
                        'invoice_cancelled_type' => (string)($settings['invoice_settings']['invoice_cancelled_type'] ?? 'off'),
                        'invoice_refunded_type' => (string)($settings['invoice_settings']['invoice_refunded_type'] ?? 'off'),
                        'invoice_failed_type' => (string)($settings['invoice_settings']['invoice_failed_type'] ?? 'off')
                    )
                );
                
                // ذخیره تنظیمات در وردپرس
                $this->options = $formatted_settings;
                update_option('bim_settings', $formatted_settings);
                
                $this->logger->add_log('info', 'تنظیمات با موفقیت از وب‌سرویس دریافت و ذخیره شد', [
                    'settings' => $formatted_settings,
                    'response' => $settings,
                ]);
            } else {
                // در صورت خطا، تنظیمات را از دیتابیس محلی می‌خوانیم
                $this->options = get_option('bim_settings', $this->get_default_settings());
                $this->logger->add_log('warning', 'خطا در دریافت تنظیمات از وب‌سرویس: ' . ($response['message'] ?? 'خطای ناشناخته'));
            }
        } catch (Exception $e) {
            // در صورت خطا، تنظیمات را از دیتابیس محلی می‌خوانیم
            $this->options = get_option('bim_settings', $this->get_default_settings());
            $this->logger->add_log('error', 'خطا در دریافت تنظیمات: ' . $e->getMessage());
        }

        if ($key === null) {
            return $this->options;
        }
        return isset($this->options[$key]) ? $this->options[$key] : $default;
    }

    public function update($options) {
        try {
            // تبدیل داده‌ها به فرمت مورد نیاز
            $formatted_settings = $this->sanitize_settings($options);

            // لاگ داده‌های ورودی
            $this->logger->add_log('info', 'داده‌های ورودی برای به‌روزرسانی', [
                'raw_input' => $options,
                'formatted' => $formatted_settings
            ]);

            // تبدیل داده‌ها به فرمت مورد نیاز API
            $api_data = array(
                'settings' => $formatted_settings,
                'sync' => false
            );
            
            // لاگ داده‌های ارسالی به API
            $this->logger->add_log('info', 'داده‌های ارسالی به API', [
                'api_data' => $api_data
            ]);
            
            // ارسال تنظیمات به وب‌سرویس
            $response = $this->api->request('settings', 'POST', $api_data);
            
            if (!$response['success']) {
                $error_message = 'خطا در به‌روزرسانی تنظیمات در وب‌سرویس: ' . ($response['message'] ?? 'خطای ناشناخته');
                $this->logger->add_log('error', $error_message);
                return false;
            }

            // ذخیره تنظیمات در وردپرس
            $this->options = $formatted_settings;
            update_option('bim_settings', $formatted_settings);
            
            $this->logger->add_log('info', 'تنظیمات با موفقیت به‌روزرسانی شد', [
                'settings' => $formatted_settings
            ]);

            return true;
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در به‌روزرسانی تنظیمات: ' . $e->getMessage());
            return false;
        }
    }

    public function sanitize_settings($input) {
        $sanitized = array();
        
        // تنظیمات اصلی
        $sanitized['enable_price_update'] = !empty($input['enable_price_update']) ? 1 : 0;
        $sanitized['enable_stock_update'] = !empty($input['enable_stock_update']) ? 1 : 0;
        $sanitized['enable_name_update'] = !empty($input['enable_name_update']) ? 1 : 0;
        $sanitized['enable_new_product'] = !empty($input['enable_new_product']) ? 1 : 0;
        $sanitized['enable_invoice'] = !empty($input['enable_invoice']) ? 1 : 0;
        $sanitized['enable_cart_sync'] = !empty($input['enable_cart_sync']) ? 1 : 0;
        
        // تنظیمات واحد قیمت
        $sanitized['rain_sale_price_unit'] = (string)($input['rain_sale_price_unit'] ?? 'rial');
        $sanitized['woocommerce_price_unit'] = (string)($input['woocommerce_price_unit'] ?? 'toman');
        
        // تنظیمات فاکتور
        $sanitized['invoice_settings'] = array(
            'cash_on_delivery' => (string)($input['invoice_settings']['cash_on_delivery'] ?? 'cash'),
            'credit_payment' => (string)($input['invoice_settings']['credit_payment'] ?? 'cash'),
            'invoice_pending_type' => (string)($input['invoice_settings']['invoice_pending_type'] ?? 'off'),
            'invoice_on_hold_type' => (string)($input['invoice_settings']['invoice_on_hold_type'] ?? 'off'),
            'invoice_processing_type' => (string)($input['invoice_settings']['invoice_processing_type'] ?? 'invoice'),
            'invoice_complete_type' => (string)($input['invoice_settings']['invoice_complete_type'] ?? 'off'),
            'invoice_cancelled_type' => (string)($input['invoice_settings']['invoice_cancelled_type'] ?? 'off'),
            'invoice_refunded_type' => (string)($input['invoice_settings']['invoice_refunded_type'] ?? 'off'),
            'invoice_failed_type' => (string)($input['invoice_settings']['invoice_failed_type'] ?? 'off')
        );
        
        return $sanitized;
    }

    private function get_default_settings() {
        return array(
            'enable_price_update' => false,
            'enable_stock_update' => false,
            'enable_name_update' => false,
            'enable_new_product' => false,
            'enable_invoice' => false,
            'enable_cart_sync' => false,
            'rain_sale_price_unit' => 'rial',
            'woocommerce_price_unit' => 'toman',
            'invoice_settings' => array(
                'cash_on_delivery' => 'cash',
                'credit_payment' => 'cash',
                'invoice_pending_type' => 'off',
                'invoice_on_hold_type' => 'off',
                'invoice_processing_type' => 'invoice',
                'invoice_complete_type' => 'off',
                'invoice_cancelled_type' => 'off',
                'invoice_refunded_type' => 'off',
                'invoice_failed_type' => 'off'
            )
        );
    }

    public function sync_settings() {
        try {
            // لاگ شروع همگام‌سازی
            $this->logger->add_log('info', 'شروع همگام‌سازی تنظیمات با وب‌سرویس', array(
                'current_settings' => $this->options,
                'api_endpoint' => 'settings',
                'method' => 'GET'
            ));
            
            // دریافت تنظیمات از وب‌سرویس
            $response = $this->api->request('settings', 'GET');
            
            // لاگ پاسخ دریافتی
            $this->logger->add_log('info', 'پاسخ دریافتی از وب‌سرویس', array(
                'response' => $response,
                'response_type' => gettype($response),
                'success' => $response['success'] ?? false
            ));
            
            if (!$response['success']) {
                $error_details = array(
                    'error_type' => 'api_error',
                    'response' => $response,
                    'message' => $response['message'] ?? 'خطای ناشناخته',
                    'code' => $response['code'] ?? null,
                    'data' => $response['data'] ?? null,
                    'current_settings' => $this->options
                );
                
                $this->logger->add_log('error', 'خطا در دریافت تنظیمات از وب‌سرویس', $error_details);
                return $response;
            }
            
            // بررسی اعتبار داده‌های دریافتی
            if (!isset($response['data']) || !is_array($response['data'])) {
                $error_details = array(
                    'error_type' => 'invalid_data',
                    'response' => $response,
                    'expected_data_type' => 'array',
                    'received_data_type' => isset($response['data']) ? gettype($response['data']) : 'undefined'
                );
                
                $this->logger->add_log('error', 'داده‌های دریافتی از وب‌سرویس نامعتبر است', $error_details);
                return $error_details;
            }

            // تبدیل داده‌های دریافتی به فرمت مورد نیاز
            $formatted_settings = array(
                'enable_price_update' => (bool)($response['data']['enable_price_update'] ?? false),
                'enable_stock_update' => (bool)($response['data']['enable_stock_update'] ?? false),
                'enable_name_update' => (bool)($response['data']['enable_name_update'] ?? false),
                'enable_new_product' => (bool)($response['data']['enable_new_product'] ?? false),
                'enable_invoice' => (bool)($response['data']['enable_invoice'] ?? false),
                'enable_cart_sync' => (bool)($response['data']['enable_cart_sync'] ?? false),
                'rain_sale_price_unit' => (string)($response['data']['rain_sale_price_unit'] ?? 'rial'),
                'woocommerce_price_unit' => (string)($response['data']['woocommerce_price_unit'] ?? 'toman'),
                'invoice_settings' => array(
                    'cash_on_delivery' => (string)($response['data']['invoice_settings']['cash_on_delivery'] ?? 'cash'),
                    'invoice_pending_type' => (string)($response['data']['invoice_settings']['invoice_pending_type'] ?? 'off'),
                    'invoice_on_hold_type' => (string)($response['data']['invoice_settings']['invoice_on_hold_type'] ?? 'off'),
                    'invoice_processing_type' => (string)($response['data']['invoice_settings']['invoice_processing_type'] ?? 'invoice'),
                    'invoice_complete_type' => (string)($response['data']['invoice_settings']['invoice_complete_type'] ?? 'off')
                )
            );

            // لاگ داده‌های فرمت شده
            $this->logger->add_log('info', 'داده‌های فرمت شده برای ذخیره', array(
                'formatted_settings' => $formatted_settings,
                'original_data' => $response['data']
            ));
            
            // به‌روزرسانی تنظیمات محلی
            $this->options = $formatted_settings;
            
            // بررسی وجود خطا در دیتابیس قبل از ذخیره
            global $wpdb;
            $wpdb->show_errors();
            $wpdb->suppress_errors(false);
            
            // تبدیل تنظیمات به JSON برای ذخیره در دیتابیس
            $settings_json = wp_json_encode($formatted_settings, JSON_UNESCAPED_UNICODE);
            
            // ذخیره تنظیمات در دیتابیس
            $result = update_option('bim_settings', $settings_json);
            
            if ($result) {
                $this->logger->add_log('info', 'تنظیمات با موفقیت از وب‌سرویس همگام‌سازی شد', array(
                    'new_settings' => $formatted_settings,
                    'old_settings' => get_option('bim_settings')
                ));
                return true;
            } else {
                $error_details = array(
                    'error_type' => 'database_error',
                    'new_settings' => $formatted_settings,
                    'old_settings' => get_option('bim_settings'),
                    'wp_error' => $wpdb->last_error ?? null,
                    'wp_error_no' => $wpdb->last_error_no ?? null,
                    'wpdb_last_query' => $wpdb->last_query ?? null,
                    'settings_json' => $settings_json
                );
                
                $this->logger->add_log('error', 'خطا در ذخیره تنظیمات همگام‌سازی شده در دیتابیس محلی', $error_details);
                return $error_details;
            }
            
        } catch (Exception $e) {
            $error_details = array(
                'error_type' => 'exception',
                'exception_class' => get_class($e),
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'current_settings' => $this->options
            );
            
            $this->logger->add_log('error', 'خطا در همگام‌سازی تنظیمات', $error_details);
            return $error_details;
        }
    }

    public function get_license_info() {
        return array(
            'license_key' => get_option('bim_license_key', ''),
            'expiry_date' => get_option('bim_expiry_date', ''),
            'account_type' => get_option('bim_account_type', 'basic')
        );
    }

    public function get_all() {
        return $this->options;
    }

    public function get_defaults() {
        return BIM_DEFAULT_SETTINGS;
    }

    /**
     * دریافت تنظیمات واحد قیمت از وب‌سرویس
     */
    public function get_price_unit_settings() {
        try {
            $response = $this->api->request('settings/price-unit', 'GET');
            
            if (!$response['success']) {
            return false;
        }

            return $response['data'];
            
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در دریافت تنظیمات واحد قیمت: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * به‌روزرسانی تنظیمات واحد قیمت در وب‌سرویس
     */
    public function update_price_unit_settings($rain_sale_unit, $woocommerce_unit) {
        try {
            $response = $this->api->request('settings/price-unit', 'POST', [
                'rain_sale_price_unit' => $rain_sale_unit,
                'woocommerce_price_unit' => $woocommerce_unit
            ]);
            
            if (!$response['success']) {
                $this->logger->add_log('error', 'خطا در به‌روزرسانی تنظیمات واحد قیمت: ' . ($response['message'] ?? 'خطای ناشناخته'));
                return false;
            }
            
            return true;
            
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در به‌روزرسانی تنظیمات واحد قیمت: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * نمایش فرم تنظیمات واحد قیمت
     */
    public function render_price_unit_settings() {
        $settings = $this->get_price_unit_settings();
        ?>
        <div class="wrap">
            <h2>تنظیمات واحد قیمت</h2>
            <form method="post" action="options.php">
                <?php settings_fields('bim_price_unit_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">واحد قیمت در RainSale</th>
                        <td>
                            <select name="bim_settings[rain_sale_price_unit]">
                                <option value="toman" <?php selected($settings['rain_sale_price_unit'] ?? 'toman', 'toman'); ?>>تومان</option>
                                <option value="rial" <?php selected($settings['rain_sale_price_unit'] ?? 'toman', 'rial'); ?>>ریال</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">واحد قیمت در ووکامرس</th>
                        <td>
                            <select name="bim_settings[woocommerce_price_unit]">
                                <option value="toman" <?php selected($settings['woocommerce_price_unit'] ?? 'toman', 'toman'); ?>>تومان</option>
                                <option value="rial" <?php selected($settings['woocommerce_price_unit'] ?? 'toman', 'rial'); ?>>ریال</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button('ذخیره تنظیمات'); ?>
            </form>
        </div>
        <?php
    }

    /**
     * ذخیره تنظیمات واحد قیمت
     */
    public function save_price_unit_settings($input) {
        if (isset($input['rain_sale_price_unit']) && isset($input['woocommerce_price_unit'])) {
            $this->update_price_unit_settings(
                $input['rain_sale_price_unit'],
                $input['woocommerce_price_unit']
            );
        }
        return $input;
    }

    /**
     * نمایش صفحه تنظیمات
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get();
        ?>
        <div class="wrap">
            <h2>تنظیمات دستیار فروشگاهی باران</h2>
            <form method="post" action="options.php">
                <?php settings_fields('bim_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">به‌روزرسانی قیمت</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bim_settings[enable_price_update]" value="1" <?php checked(isset($settings['enable_price_update']) ? $settings['enable_price_update'] : false); ?>>
                                فعال‌سازی به‌روزرسانی خودکار قیمت‌ها
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">به‌روزرسانی موجودی</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bim_settings[enable_stock_update]" value="1" <?php checked(isset($settings['enable_stock_update']) ? $settings['enable_stock_update'] : false); ?>>
                                فعال‌سازی به‌روزرسانی خودکار موجودی
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">به‌روزرسانی نام</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bim_settings[enable_name_update]" value="1" <?php checked(isset($settings['enable_name_update']) ? $settings['enable_name_update'] : false); ?>>
                                فعال‌سازی به‌روزرسانی خودکار نام محصولات
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">افزودن محصول جدید</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bim_settings[enable_new_product]" value="1" <?php checked(isset($settings['enable_new_product']) ? $settings['enable_new_product'] : false); ?>>
                                فعال‌سازی افزودن خودکار محصولات جدید
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">فاکتور</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bim_settings[enable_invoice]" value="1" <?php checked(isset($settings['enable_invoice']) ? $settings['enable_invoice'] : false); ?>>
                                فعال‌سازی ارسال خودکار فاکتور
                            </label>
                            <br><br>
                            <fieldset>
                                <legend>تنظیمات فاکتور</legend>
                                <div class="payment-type-settings">
                                    <div class="payment-row">
                                        <label>پرداخت در محل:</label>
                                        <select name="bim_settings[invoice_settings][cash_on_delivery]">
                                            <option value="cash" <?php selected($settings['invoice_settings']['cash_on_delivery'] ?? 'cash', 'cash'); ?>>نقدی</option>
                                            <option value="credit" <?php selected($settings['invoice_settings']['cash_on_delivery'] ?? 'cash', 'credit'); ?>>نسیه</option>
                                        </select>
                                    </div>
                                    <div class="payment-row">
                                        <label>پرداخت اعتباری:</label>
                                        <select name="bim_settings[invoice_settings][credit_payment]">
                                            <option value="cash" <?php selected($settings['invoice_settings']['credit_payment'] ?? 'cash', 'cash'); ?>>نقدی</option>
                                            <option value="credit" <?php selected($settings['invoice_settings']['credit_payment'] ?? 'cash', 'credit'); ?>>نسیه</option>
                                        </select>
                                    </div>
                                </div>
                            </fieldset>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">همگام‌سازی سبد خرید</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bim_settings[enable_cart_sync]" value="1" <?php checked(isset($settings['enable_cart_sync']) ? $settings['enable_cart_sync'] : false); ?>>
                                فعال‌سازی همگام‌سازی خودکار سبد خرید
                            </label>
                        </td>
                    </tr>
                </table>
                <?php submit_button('ذخیره تنظیمات'); ?>
            </form>
        </div>
        <?php
    }
} 