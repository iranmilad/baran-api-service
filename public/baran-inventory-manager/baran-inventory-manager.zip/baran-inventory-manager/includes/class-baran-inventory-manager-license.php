<?php
/**
 * کلاس مدیریت لایسنس پلاگین
 *
 * @package Baran_Inventory_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

class Baran_Inventory_Manager_License {
    private $api_url;
    private $item_id;
    private $license_key;
    private $license_status;

    public function __construct($api_url, $item_id) {
        $this->api_url = $api_url;
        $this->item_id = $item_id;
        $this->license_key = get_option('baran_inventory_manager_license_key');
        $this->license_status = get_option('baran_inventory_manager_license_status');

        add_action('admin_init', array($this, 'check_license'));
    }

    public function activate_license($license_key) {
        $api_params = array(
            'edd_action' => 'activate_license',
            'license'    => $license_key,
            'item_id'    => $this->item_id,
            'url'        => home_url()
        );

        $response = wp_remote_post(rtrim($this->api_url, '/') . '/api/v1/license/activate', array(
            'timeout'   => 15,
            'sslverify' => false,
            'body'      => $api_params
        ));

        if (is_wp_error($response)) {
            return false;
        }

        $license_data = json_decode(wp_remote_retrieve_body($response));

        if ($license_data->license === 'valid') {
            update_option('baran_inventory_manager_license_key', $license_key);
            update_option('baran_inventory_manager_license_status', $license_data->license);
            return true;
        }

        return false;
    }

    public function deactivate_license() {
        $api_params = array(
            'edd_action' => 'deactivate_license',
            'license'    => $this->license_key,
            'item_id'    => $this->item_id,
            'url'        => home_url()
        );

        $response = wp_remote_post(rtrim($this->api_url, '/') . '/api/v1/license/deactivate', array(
            'timeout'   => 15,
            'sslverify' => false,
            'body'      => $api_params
        ));

        if (is_wp_error($response)) {
            return false;
        }

        $license_data = json_decode(wp_remote_retrieve_body($response));

        if ($license_data->license === 'deactivated') {
            delete_option('baran_inventory_manager_license_key');
            delete_option('baran_inventory_manager_license_status');
            return true;
        }

        return false;
    }

    public function check_license() {
        if (empty($this->license_key)) {
            return;
        }

        $api_params = array(
            'edd_action' => 'check_license',
            'license'    => $this->license_key,
            'item_id'    => $this->item_id,
            'url'        => home_url()
        );

        $response = wp_remote_post(rtrim($this->api_url, '/') . '/api/v1/license/check', array(
            'timeout'   => 15,
            'sslverify' => false,
            'body'      => $api_params
        ));

        if (is_wp_error($response)) {
            return;
        }

        $license_data = json_decode(wp_remote_retrieve_body($response));

        if ($license_data->license !== $this->license_status) {
            update_option('baran_inventory_manager_license_status', $license_data->license);
        }
    }

    public function is_valid() {
        return $this->license_status === 'valid';
    }
} 