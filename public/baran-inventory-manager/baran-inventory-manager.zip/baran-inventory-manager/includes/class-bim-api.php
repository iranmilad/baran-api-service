<?php
if (!defined('ABSPATH')) {
    require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

class BIM_API {
    private static $instance = null;
    private $api_url;
    private $logger;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api_url = BIM_DEFAULT_API_URL;
        $this->logger = BIM_Logger::get_instance();
        
        // هوک برای ارسال مجدد خودکار فاکتورهای ناموفق
        add_action('bim_retry_failed_invoices', array($this, 'retry_failed_invoices'));
        
        // هوک برای همگام‌سازی خودکار محصولات
        add_action('bim_sync_products', array($this, 'sync_products'));
        
        // هوک برای همگام‌سازی سبد خرید
        add_action('woocommerce_add_to_cart', array($this, 'notify_cart_add'), 10, 6);
    }
    
    public function get_api_url() {
        return $this->api_url;
    }
    
    public function request($endpoint, $method = 'GET', $data = array()) {
        try {
            $token = get_option('bim_api_token');
            $token_expires = get_option('bim_token_expires');
            
            // اگر توکن منقضی شده باشد، تلاش برای دریافت توکن جدید
            if (!$token || $token_expires < time()) {
                $license_key = get_option('bim_license_key');
                if (!$license_key) {
                    return array(
                        'success' => false,
                        'message' => 'لایسنس یافت نشد'
                    );
                }
                
                $login_response = $this->login($license_key);
                if (!$login_response['success']) {
                    return $login_response;
                }
                
                $token = get_option('bim_api_token');
            }
            
            // ساخت URL با فرمت صحیح
            $url = rtrim($this->api_url, '/') . '/api/v1/' . ltrim($endpoint, '/');
            $this->logger->add_log('info', 'API: ' . $url);

            $args = array(
                'method' => $method,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json'
                ),
                'timeout' => 30
            );
            
            if (!empty($data)) {
                $args['body'] = json_encode($data);
            }
            
            $response = wp_remote_request($url, $args);
            
            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('خطا در پردازش پاسخ API');
            }

            // بررسی خطای نامعتبر بودن توکن
            if (!$data['success'] && (
                wp_remote_retrieve_response_code($response) === 401 || 
                (isset($data['message']) && (
                    strpos($data['message'], 'token') !== false || 
                    strpos($data['message'], 'توکن') !== false ||
                    strpos($data['message'], 'unauthorized') !== false
                ))
            )) {
                $this->logger->add_log('warning', 'توکن نامعتبر است، تلاش برای لاگین مجدد');
                
                // تلاش برای لاگین مجدد
                $license_key = get_option('bim_license_key');
                if ($license_key) {
                    $login_response = $this->login($license_key);
                    if ($login_response['success']) {
                        // تکرار درخواست با توکن جدید
                        $token = get_option('bim_api_token');
                        $args['headers']['Authorization'] = 'Bearer ' . $token;
                        $response = wp_remote_request($url, $args);
                        
                        if (is_wp_error($response)) {
                            throw new Exception($response->get_error_message());
                        }
                        
                        $body = wp_remote_retrieve_body($response);
                        $data = json_decode($body, true);
                        
                        if (json_last_error() !== JSON_ERROR_NONE) {
                            throw new Exception('خطا در پردازش پاسخ API');
                        }
                    }
                }
            }
            
            return $data;
            
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در ارتباط با API: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    public function login($license_key) {
        try {
            $website_url = get_site_url();
            $url = rtrim($this->api_url, '/') . '/api/v1/login';
            
            $response = wp_remote_post($url, array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json'
                ),
                'body' => json_encode(array(
                    'website_url' => $website_url,
            'license_key' => $license_key
                )),
                'timeout' => 30
            ));

            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('خطا در پردازش پاسخ API');
            }

            if (!$data['success']) {
                return array(
                    'success' => false,
                    'message' => $data['message'] ?? 'خطا در ورود به سیستم'
                );
            }

            // ذخیره توکن و تاریخ انقضا
            update_option('bim_api_token', $data['data']['token']);
            update_option('bim_token_expires', $data['data']['expires_at']);
            update_option('bim_license_key', $license_key);
            update_option('bim_account_type', $data['data']['account_type'] ?? 'basic');

            $this->logger->add_log('info', 'ورود موفقیت‌آمیز به API', array(
                'expires_at' => date('Y-m-d H:i:s', $data['data']['expires_at']),
                'account_type' => $data['data']['account_type'] ?? 'basic'
            ));

            return array(
                'success' => true,
                'message' => 'ورود موفقیت‌آمیز',
                'data' => $data['data']
            );

        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در ورود به API: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    public function verify_license($license_key) {
        try {
            $website_url = get_site_url();
            
            $response = $this->login($license_key);
            
            if (!$response['success']) {
                throw new Exception($response['message'] ?? 'خطا در بررسی لایسنس');
            }
            
            $this->logger->add_log('license_activated', 'لایسنس با موفقیت فعال شد', array(
                'website_url' => $website_url
            ));
            
            return array(
                'success' => true,
                'message' => 'لایسنس با موفقیت فعال شد'
            );
            
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در فعال‌سازی لایسنس: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    public function test_connection() {
        try {
            // تست اتصال به API
            $url = rtrim($this->api_url, '/') . '/test-connection';
            
            $response = wp_remote_get($url, array(
                'timeout' => 30,
                'headers' => array(
                    'Accept' => 'application/json'
                )
            ));

            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('خطا در پردازش پاسخ API');
            }

            if (!$data['success']) {
                throw new Exception($data['message'] ?? 'خطا در اتصال به API');
            }

            // بررسی اعتبار توکن
            $token = get_option('bim_api_token');
            $token_expires = get_option('bim_token_expires');
            $license_key = get_option('bim_license_key');

            if ($token && $token_expires > time()) {
                // تست اعتبار توکن با درخواست به /me
                $me_response = $this->request('me');
                if (!$me_response['success']) {
                    // اگر توکن نامعتبر است، تلاش برای دریافت توکن جدید
                    if ($license_key) {
                        $login_response = $this->login($license_key);
                        if (!$login_response['success']) {
                            throw new Exception('خطا در تمدید توکن: ' . $login_response['message']);
                        }
                    } else {
                        throw new Exception('لایسنس یافت نشد');
                    }
                }
            } elseif ($license_key) {
                // اگر توکن منقضی شده، تلاش برای دریافت توکن جدید
                $login_response = $this->login($license_key);
                if (!$login_response['success']) {
                    throw new Exception('خطا در دریافت توکن جدید: ' . $login_response['message']);
                }
            }

            return array(
                'success' => true,
                'message' => 'اتصال به API برقرار است و توکن معتبر است',
                'timestamp' => $data['timestamp']
            );
            
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در تست اتصال: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * ارسال درخواست به‌روزرسانی محصول به API هنگام اضافه شدن به سبد خرید
     */
    public function notify_cart_add($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data) {
        try {
            $this->logger->add_log('info', 'شروع فرآیند همگام‌سازی سبد خرید', [
                'product_id' => $product_id,
                'variation_id' => $variation_id,
                'quantity' => $quantity
            ]);

            // دریافت تنظیمات کاربر
            $settings = get_option('bim_settings');
            if (!$settings || !isset($settings['enable_cart_sync']) || !$settings['enable_cart_sync']) {
                $this->logger->add_log('info', 'همگام‌سازی سبد خرید غیرفعال است', [
                    'product_id' => $product_id
                ]);
                return;
            }

            // دریافت SKU و کد یکتای محصول
            $barcodes = [];
            global $wpdb;

            if ($variation_id) {
                // اگر محصول متغیر است، اطلاعات متغیر را دریافت کن
                $variation_product = wc_get_product($variation_id);
                if ($variation_product) {
                    $sku = $variation_product->get_sku();
                    if (!empty($sku)) {
                        $barcodes[] = $sku;
                    }

                    // دریافت کد یکتای متغیر
                    $unique_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT unique_id FROM {$wpdb->prefix}bim_unique_products WHERE variation_id = %d",
                        $variation_id
                    ));
                    if (!empty($unique_id)) {
                        $barcodes[] = $unique_id;
                    }
                }
            } else {
                // اگر محصول ساده است، اطلاعات محصول اصلی را دریافت کن
                $product = wc_get_product($product_id);
                if ($product) {
                    $sku = $product->get_sku();
                    if (!empty($sku)) {
                        $barcodes[] = $sku;
                    }

                    // دریافت کد یکتای محصول اصلی
                    $unique_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT unique_id FROM {$wpdb->prefix}bim_unique_products WHERE product_id = %d",
                        $product_id
                    ));
                    if (!empty($unique_id)) {
                        $barcodes[] = $unique_id;
                    }
                }
            }

            if (empty($barcodes)) {
                $this->logger->add_log('error', 'هیچ کد شناسایی (SKU یا کد یکتا) برای محصول یافت نشد', [
                    'product_id' => $product_id,
                    'variation_id' => $variation_id
                ]);
                return;
            }

            $this->logger->add_log('info', 'ارسال درخواست به‌روزرسانی محصول', [
                'barcodes' => $barcodes,
                'product_id' => $product_id,
                'variation_id' => $variation_id
            ]);

            // ارسال درخواست به API
            $response = $this->request('products/bulk-sync', 'POST', [
                'barcodes' => $barcodes
            ]);

            if (!$response['success']) {
                $this->logger->add_log('error', 'خطا در به‌روزرسانی محصول از سبد خرید: ' . ($response['message'] ?? 'خطای نامشخص'), [
                    'barcodes' => $barcodes,
                    'product_id' => $product_id,
                    'variation_id' => $variation_id,
                    'response' => $response
                ]);
            } else {
                $this->logger->add_log('info', 'درخواست به‌روزرسانی محصول از سبد خرید با موفقیت ارسال شد', [
                    'barcodes' => $barcodes,
                    'product_id' => $product_id,
                    'variation_id' => $variation_id,
                    'response' => $response
                ]);
            }

        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در ارسال درخواست به‌روزرسانی محصول از سبد خرید: ' . $e->getMessage(), [
                'product_id' => $product_id,
                'variation_id' => $variation_id,
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    public function get_account_type() {
        return get_option('bim_account_type', 'basic');
    }

    /**
     * دریافت توکن فعلی
     * @return string|null توکن فعلی یا null در صورت عدم وجود
     */
    public function get_token() {
        $token = get_option('bim_api_token');
        $token_expires = get_option('bim_token_expires');
        
        // بررسی اعتبار توکن
        if (!$token || $token_expires < time()) {
            $license_key = get_option('bim_license_key');
            if (!$license_key) {
                $this->logger->add_log('error', 'لایسنس یافت نشد');
                return null;
            }
            
            // تلاش برای دریافت توکن جدید
            $login_response = $this->login($license_key);
            if (!$login_response['success']) {
                $this->logger->add_log('error', 'خطا در دریافت توکن جدید: ' . ($login_response['message'] ?? 'خطای ناشناخته'));
                return null;
            }
            
            $token = get_option('bim_api_token');
        }
        
        return $token;
    }

    /**
     * ارسال مجدد سفارش به وبسرویس
     * @param int $order_id شناسه سفارش
     * @return array نتیجه عملیات
     */
    public function resend_order($order_id) {
        try {
            $this->logger->add_log('info', 'شروع ارسال مجدد سفارش', [
                'order_id' => $order_id
            ]);

            // دریافت اطلاعات سفارش
            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception('سفارش یافت نشد');
            }

            // آماده‌سازی داده‌های سفارش
            $items = array();
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                $variation_id = $item->get_variation_id();
                $unique_id = $item->get_meta('_bim_unique_id');
                
                // دریافت SKU بر اساس نوع محصول
                $sku = '';
                if ($variation_id) {
                    $variation = wc_get_product($variation_id);
                    $sku = $variation ? $variation->get_sku() : '';
                } else {
                    $product = wc_get_product($product_id);
                    $sku = $product ? $product->get_sku() : '';
                }
                
                if (!$unique_id) {
                    $this->logger->add_log('warning', 'کد یکتا برای محصول یافت نشد', [
                        'order_id' => $order_id,
                        'product_id' => $product_id,
                        'variation_id' => $variation_id
                    ]);
                    continue;
                }
                
                $items[] = array(
                    'unique_id' => $unique_id,
                    'sku' => $sku,
                    'quantity' => $item->get_quantity(),
                    'price' => $item->get_total() / $item->get_quantity(),
                    'name' => $item->get_name(),
                    'total' => $item->get_total()
                );
            }

            if (empty($items)) {
                throw new Exception('هیچ محصولی با کد یکتا یافت نشد');
            }

            // آماده‌سازی داده‌های سفارش
            $order_data = array(
                'items' => $items,
                'customer' => array(
                    'first_name' => $order->get_billing_first_name(),
                    'last_name' => $order->get_billing_last_name(),
                    'email' => $order->get_billing_email(),
                    'phone' => $order->get_billing_phone(),
                    'mobile' => $order->get_billing_phone(),
                    'address' => array(
                        'address_1' => $order->get_billing_address_1(),
                        'address_2' => $order->get_billing_address_2(),
                        'city' => $order->get_billing_city(),
                        'state' => $order->get_billing_state(),
                        'postcode' => $order->get_billing_postcode(),
                        'country' => $order->get_billing_country()
                    )
                ),
                'payment_method' => $order->get_payment_method(),
                'total' => $order->get_total(),
                'shipping_total' => $order->get_shipping_total(),
                'discount_total' => $order->get_discount_total(),
                'tax_total' => $order->get_total_tax(),
                'currency' => $order->get_currency(),
                'status' => $order->get_status(),
                'created_at' => $order->get_date_created()->date('Y-m-d H:i:s'),
                'updated_at' => $order->get_date_modified()->date('Y-m-d H:i:s')
            );

            // تنظیم وضعیت در انتظار ارسال
            update_post_meta($order_id, '_bim_web_service_status', '');
            update_post_meta($order_id, '_bim_web_service_message', '');

            // ارسال به وبسرویس
            $response = wp_remote_post($this->api_url . '/api/invoices/webhook', array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $this->get_token()
                ),
                'body' => json_encode(array(
                    'order_id' => $order_id,
                    'customer_mobile' => $order->get_billing_phone(),
                    'order_data' => $order_data
                ))
            ));

            if (is_wp_error($response)) {
                // ثبت وضعیت خطا
                update_post_meta($order_id, '_bim_web_service_status', 'false');
                update_post_meta($order_id, '_bim_web_service_message', $response->get_error_message());
                
                $this->logger->add_log('error', 'خطا در ارسال مجدد فاکتور به وبسرویس', array(
                    'error' => $response->get_error_message(),
                    'order_id' => $order_id,
                    'error_code' => $response->get_error_code()
                ));

                return array(
                    'success' => false,
                    'message' => $response->get_error_message()
                );
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            
            if (!$body['success']) {
                // ثبت وضعیت خطا
                update_post_meta($order_id, '_bim_web_service_status', 'false');
                update_post_meta($order_id, '_bim_web_service_message', $body['message'] ?? 'خطای نامشخص');
                
                $this->logger->add_log('error', 'خطا در پردازش مجدد فاکتور توسط وبسرویس', array(
                    'error' => $body['message'] ?? 'خطای نامشخص',
                    'order_id' => $order_id,
                    'response' => $body
                ));

                return array(
                    'success' => false,
                    'message' => $body['message'] ?? 'خطای نامشخص'
                );
            }

            // ذخیره وضعیت ارسال موفق
            update_post_meta($order_id, '_bim_web_service_status', 'true');
            update_post_meta($order_id, '_bim_web_service_message', $body['message'] ?? '');
            
            $this->logger->add_log('info', 'فاکتور با موفقیت مجدداً ارسال شد', array(
                'order_id' => $order_id,
                'response' => $body,
                'web_service_status' => 'true',
                'web_service_message' => $body['message'] ?? ''
            ));

            return array(
                'success' => true,
                'message' => 'فاکتور با موفقیت مجدداً ارسال شد'
            );

        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در ارسال مجدد سفارش: ' . $e->getMessage(), [
                'order_id' => $order_id,
                'trace' => $e->getTraceAsString()
            ]);

            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
} 