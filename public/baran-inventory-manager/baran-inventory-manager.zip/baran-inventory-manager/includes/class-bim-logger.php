<?php
if (!defined('ABSPATH')) {
    require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

class BIM_Logger {
    private static $instance = null;
    private $table_name;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'bim_logs';
    }

    public function create_logs_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            type varchar(50) NOT NULL,
            message text NOT NULL,
            data longtext,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function add_log($type, $message, $data = array()) {
        global $wpdb;
        
        $wpdb->insert(
            $this->table_name,
            array(
                'type' => $type,
                'message' => $message,
                'data' => !empty($data) ? json_encode($data, JSON_UNESCAPED_UNICODE) : null,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s')
        );
        
        return $wpdb->insert_id;
    }

    public function get_logs($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'type' => '',
            'date' => '',
            'page' => 1,
            'per_page' => 20
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if (!empty($args['type'])) {
            $where[] = 'type = %s';
            $values[] = $args['type'];
        }
        
        if (!empty($args['date'])) {
            $where[] = 'DATE(created_at) = %s';
            $values[] = $args['date'];
        }
        
        $offset = ($args['page'] - 1) * $args['per_page'];
        
        $sql = "SELECT * FROM {$this->table_name} WHERE " . implode(' AND ', $where) . " ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $values[] = $args['per_page'];
        $values[] = $offset;
        
        $sql = $wpdb->prepare($sql, $values);
        
        return $wpdb->get_results($sql);
    }

    public function get_total_logs($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'type' => '',
            'date' => ''
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if (!empty($args['type'])) {
            $where[] = 'type = %s';
            $values[] = $args['type'];
        }
        
        if (!empty($args['date'])) {
            $where[] = 'DATE(created_at) = %s';
            $values[] = $args['date'];
        }
        
        $sql = "SELECT COUNT(*) FROM {$this->table_name} WHERE " . implode(' AND ', $where);
        
        if (!empty($values)) {
            $sql = $wpdb->prepare($sql, $values);
        }
        
        return (int) $wpdb->get_var($sql);
    }

    public function clear_logs() {
        global $wpdb;
        
        try {
            $result = $wpdb->query("TRUNCATE TABLE {$this->table_name}");
            
            if ($result !== false) {
                $this->add_log('info', 'همه لاگ‌ها با موفقیت حذف شدند', [
                    'action' => 'clear_logs',
                    'timestamp' => current_time('mysql')
                ]);
                return true;
            } else {
                $this->add_log('error', 'خطا در حذف لاگ‌ها', [
                    'error' => $wpdb->last_error,
                    'action' => 'clear_logs',
                    'timestamp' => current_time('mysql')
                ]);
                return false;
            }
        } catch (Exception $e) {
            $this->add_log('error', 'خطا در حذف لاگ‌ها', [
                'error' => $e->getMessage(),
                'action' => 'clear_logs',
                'timestamp' => current_time('mysql')
            ]);
            return false;
        }
    }

    public function export_logs($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'type' => '',
            'date' => '',
            'limit' => 1000
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if (!empty($args['type'])) {
            $where[] = 'type = %s';
            $values[] = $args['type'];
        }
        
        if (!empty($args['date'])) {
            $where[] = 'DATE(created_at) = %s';
            $values[] = $args['date'];
        }
        
        $sql = "SELECT * FROM {$this->table_name} WHERE " . implode(' AND ', $where) . " ORDER BY created_at DESC LIMIT %d";
        $values[] = $args['limit'];
        
        $sql = $wpdb->prepare($sql, $values);
        $logs = $wpdb->get_results($sql);
        
        if (empty($logs)) {
            return false;
        }
        
        $filename = 'bim-logs-' . date('Y-m-d') . '.csv';
        $upload_dir = wp_upload_dir();
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        $output = fopen($filepath, 'w');
        
        // اضافه کردن BOM برای پشتیبانی از حروف فارسی
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // هدر فایل CSV
        fputcsv($output, array('شناسه', 'نوع', 'پیام', 'تاریخ', 'جزئیات'));
        
        foreach ($logs as $log) {
            $data = $log->data ? json_encode(json_decode($log->data), JSON_UNESCAPED_UNICODE) : '';
            fputcsv($output, array(
                $log->id,
                $log->type,
                $log->message,
                $log->created_at,
                $data
            ));
        }
        
        fclose($output);
        
        return array(
            'success' => true,
            'file_url' => $upload_dir['url'] . '/' . $filename,
            'filename' => $filename
        );
    }
}