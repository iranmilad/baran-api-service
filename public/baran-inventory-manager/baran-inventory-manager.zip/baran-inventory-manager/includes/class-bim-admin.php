<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Admin {
    private static $instance = null;
    private $settings;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->settings = BIM_Settings::get_instance();
        $this->init_hooks();
    }
        
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_menu_pages'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // اضافه کردن هوک‌های AJAX
        add_action('wp_ajax_bim_data_operations', array($this, 'handle_data_operations'));
        add_action('wp_ajax_bim_clear_logs', array($this, 'handle_clear_logs'));
        add_action('wp_ajax_bim_export_logs', array($this, 'handle_export_logs'));
    }
    
    public function add_menu_pages() {
        add_menu_page(
            'دستیار فروشگاهی باران',
            'دستیار فروشگاهی باران',
            'manage_options',
            'baran-inventory-manager',
            array($this, 'render_main_page'),
            'dashicons-store',
            56
        );
        
        add_submenu_page(
            'baran-inventory-manager',
            'داشبورد',
            'داشبورد',
            'manage_options',
            'baran-inventory-manager',
            array($this, 'render_main_page')
        );
        
        add_submenu_page(
            'baran-inventory-manager',
            'عملیات داده',
            'عملیات داده',
            'manage_options',
            'baran-inventory-manager-data-operations',
            array($this, 'render_data_operations_page')
        );
        
        add_submenu_page(
            'baran-inventory-manager',
            'لایسنس',
            'لایسنس',
            'manage_options',
            'baran-inventory-manager-license',
            array($this, 'render_license_page')
        );
        
        add_submenu_page(
            'baran-inventory-manager',
            'تنظیمات',
            'تنظیمات',
            'manage_options',
            'baran-inventory-manager-settings',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'baran-inventory-manager',
            'گزارش‌ها',
            'گزارش‌ها',
            'manage_options',
            'bim-logs',
            array($this, 'render_logs_page')
        );
    }
    
    public function enqueue_scripts($hook) {
        // فقط در صفحات مربوط به پلاگین اسکریپت‌ها را لود کن
        if (!in_array($hook, array(
            'toplevel_page_baran-inventory-manager',
            'inventory-manager_page_baran-inventory-manager-settings',
            'inventory-manager_page_bim-logs',
            'admin_page_bim-logs'
        ))) {
            return;
        }
        
        wp_enqueue_style(
            'bim-admin',
            BIM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            BIM_VERSION
        );
        
        wp_enqueue_script('jquery');
        
        wp_enqueue_script(
            'bim-admin',
            BIM_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            BIM_VERSION,
            true
        );
        
        // تعریف متغیرهای مورد نیاز برای AJAX
        wp_localize_script('bim-admin', 'bimAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bim_clear_logs'),
            'api_url' => BIM_DEFAULT_API_URL,
            'strings' => array(
                'testing' => 'در حال تست...',
                'connected' => 'متصل',
                'disconnected' => 'غیر متصل',
                'saved' => 'تنظیمات با موفقیت ذخیره شد',
                'error' => 'خطا در ذخیره تنظیمات'
            )
        ));
    }

    public function register_settings() {
        register_setting('bim_settings', 'bim_settings', [
            'sanitize_callback' => array($this, 'sanitize_settings')
        ]);
    }
    
    public function render_main_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->settings->get();
        $license_info = $this->settings->get_license_info();
        $connection_status = BIM_Connection_Tester::get_instance()->get_connection_status();
        
        // تعریف متغیرهای مورد نیاز برای صفحه اصلی
        $license_key = isset($license_info['license_key']) ? $license_info['license_key'] : '';
        $account_type = isset($license_info['account_type']) ? $license_info['account_type'] : '';
        $expiry_date = isset($license_info['expiry_date']) ? $license_info['expiry_date'] : '';
        
        
        include BIM_PLUGIN_DIR . 'admin/views/main-page.php';
    }
    
    private function get_low_stock_products_count() {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_stock',
                    'value' => get_option('woocommerce_notify_low_stock_amount', 2),
                    'compare' => '<=',
                    'type' => 'NUMERIC'
                ),
                array(
                    'key' => '_stock',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'NUMERIC'
                )
            )
        );
        
        $query = new WP_Query($args);
        return $query->found_posts;
    }
    
    private function get_out_of_stock_products_count() {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_stock',
                    'value' => 0,
                    'compare' => '=',
                    'type' => 'NUMERIC'
                )
            )
        );
        
        $query = new WP_Query($args);
        return $query->found_posts;
    }
    
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        include BIM_PLUGIN_DIR . 'admin/views/settings-page.php';
    }
    
    public function render_logs_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // بررسی درخواست خروجی CSV
        if (isset($_POST['bim_export_logs']) && isset($_POST['_wpnonce'])) {
            if (wp_verify_nonce($_POST['_wpnonce'], 'bim_export_logs_action')) {
                $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';
                $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
                
                $logger = BIM_Logger::get_instance();
                $result = $logger->export_logs(array(
                    'type' => $type,
                    'date' => $date
                ));
                
                if (!$result) {
                    add_settings_error(
                        'bim_logs',
                        'export_failed',
                        'هیچ گزارشی برای خروجی گرفتن یافت نشد',
                        'error'
                    );
                }
            } else {
                add_settings_error(
                    'bim_logs',
                    'invalid_nonce',
                    'توکن امنیتی نامعتبر است',
                    'error'
                );
            }
        }

        // بررسی درخواست حذف گزارش‌ها
        if (isset($_POST['bim_clear_logs']) && isset($_POST['_wpnonce'])) {
            if (wp_verify_nonce($_POST['_wpnonce'], 'bim_clear_logs_action')) {
                $logger = BIM_Logger::get_instance();
                $result = $logger->clear_logs();
                
                if ($result) {
                    add_settings_error(
                        'bim_logs',
                        'logs_cleared',
                        'همه گزارش‌ها با موفقیت حذف شدند',
                        'updated'
                    );
                } else {
                    add_settings_error(
                        'bim_logs',
                        'logs_clear_failed',
                        'خطا در حذف گزارش‌ها',
                        'error'
                    );
                }
            } else {
                add_settings_error(
                    'bim_logs',
                    'invalid_nonce',
                    'توکن امنیتی نامعتبر است',
                    'error'
                );
            }
        }

        // لود کردن اسکریپت‌ها
        wp_enqueue_style(
            'bim-admin',
            BIM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            BIM_VERSION
        );
        
        wp_enqueue_script(
            'bim-admin',
            BIM_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            BIM_VERSION,
            true
        );

        $type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
        $date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        
        $logs = BIM_Logger::get_instance()->get_logs(array(
            'type' => $type,
            'date' => $date,
            'page' => $page
        ));
        
        $total_items = BIM_Logger::get_instance()->get_total_logs(array(
            'type' => $type,
            'date' => $date
        ));
        
        $per_page = 20;
        $total_pages = ceil($total_items / $per_page);
        
        include BIM_PLUGIN_DIR . 'admin/views/logs-page.php';
    }

    public function render_license_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $license_key = get_option('bim_license_key');
        $token = get_option('bim_api_token');
        $token_expires = get_option('bim_token_expires');
        $website_url = get_site_url();

        // پردازش فرم
        $message = '';
        $message_type = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bim_license_nonce'])) {
            if (wp_verify_nonce($_POST['bim_license_nonce'], 'bim_verify_license')) {
                if (current_user_can('manage_options')) {
                    $license_key = isset($_POST['license_key']) ? sanitize_text_field($_POST['license_key']) : '';
                    $website_url = isset($_POST['website_url']) ? sanitize_text_field($_POST['website_url']) : '';
                    
                    if (!empty($license_key) && !empty($website_url)) {
                        $api = BIM_API::get_instance();
                        $response = $api->verify_license($license_key);
                        
                        if ($response['success']) {
                            $message = $response['message'];
                            $message_type = 'success';
                        } else {
                            $message = $response['message'];
                            $message_type = 'error';
                        }
                    } else {
                        $message = 'لطفاً تمام فیلدها را پر کنید';
                        $message_type = 'error';
                    }
                } else {
                    $message = 'دسترسی غیرمجاز';
                    $message_type = 'error';
                }
            } else {
                $message = 'توکن امنیتی نامعتبر است';
                $message_type = 'error';
            }
        }
        ?>
        <div class="wrap bim-admin">
            <h1>تنظیمات لایسنس و اعتبار</h1>
            
            <?php if ($message): ?>
            <div class="notice notice-<?php echo $message_type; ?> is-dismissible">
                <p><?php echo esc_html($message); ?></p>
            </div>
            <?php endif; ?>
            
            <form id="bim-license-form" method="post">
                <?php wp_nonce_field('bim_verify_license', 'bim_license_nonce'); ?>
                
                <div class="bim-card">
                    <h3>اطلاعات لایسنس</h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="bim_license_key">کلید لایسنس</label>
                            </th>
                            <td>
                                <input type="text" id="bim_license_key" name="license_key" 
                                       value="<?php echo esc_attr($license_key); ?>" class="regular-text" required>
                                <p class="description">کلید لایسنس خود را وارد کنید</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">آدرس سایت</th>
                            <td>
                                <input type="text" id="bim_website_url" name="website_url" 
                                       value="<?php echo esc_attr($website_url); ?>" class="regular-text" readonly>
                                <p class="description">آدرس سایت شما به صورت خودکار ارسال می‌شود</p>
                            </td>
                        </tr>
                        <?php if ($token): ?>
                        <tr>
                            <th scope="row">وضعیت اعتبار</th>
                            <td>
                                <span class="bim-status <?php echo $token_expires > time() ? 'active' : 'expired'; ?>">
                                    <?php echo $token_expires > time() ? 'فعال' : 'منقضی شده'; ?>
                                </span>
                                <p class="description">
                                    <?php if ($token_expires > time()): ?>
                                        اعتبار تا <?php echo date_i18n('Y/m/d H:i:s', $token_expires); ?> معتبر است
                                    <?php else: ?>
                                        اعتبار شما منقضی شده است. لطفاً لایسنس را مجدداً فعال کنید.
                                    <?php endif; ?>
                                </p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">فعال‌سازی لایسنس</button>
                </p>
            </form>
        </div>

        <style>
        .bim-admin {
            margin: 20px;
        }

        .bim-card {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
            max-width: 600px;
        }

        .bim-card h3 {
            margin-top: 0;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .form-table th {
            width: 200px;
        }

        .form-table td {
            padding: 15px 10px;
        }

        .description {
            color: #666;
            font-style: italic;
            margin: 5px 0 0;
        }

        .submit {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .bim-status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 600;
        }

        .bim-status.active {
            background: #28a745;
            color: #fff;
        }

        .bim-status.expired {
            background: #dc3545;
            color: #fff;
        }

        .notice {
            margin: 15px 0;
            padding: 10px 15px;
            border-radius: 4px;
        }

        .notice-success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }

        .notice-error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        </style>
        <?php
    }

    public function render_data_operations_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // لود کردن اسکریپت‌ها
        wp_enqueue_style(
            'bim-admin',
            BIM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            BIM_VERSION
        );
        
        wp_enqueue_script(
            'bim-admin',
            BIM_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            BIM_VERSION,
            true
        );
        
        wp_localize_script('bim-admin', 'bimAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bim-admin-nonce'),
            'api_url' => BIM_DEFAULT_API_URL,
            'strings' => array(
                'processing' => 'در حال پردازش...',
                'success' => 'عملیات با موفقیت انجام شد',
                'error' => 'خطا در انجام عملیات'
            )
        ));

        include BIM_PLUGIN_DIR . 'admin/views/data-operations-page.php';
    }

    public function handle_data_operations() {
        check_ajax_referer('bim-admin-nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی غیرمجاز');
        }

        $operation = isset($_POST['operation']) ? sanitize_text_field($_POST['operation']) : '';
        $api = BIM_API::get_instance();

        switch ($operation) {
            case 'update_all_products':
                $response = $api->request('/products/bulk-sync','POST');
                break;

            case 'get_categories_attributes':
                $response = $api->request('/products/sync-categories','POST');
                break;

            case 'get_all_products':
                $response = $api->request('/mongo/clear-data', 'POST');
                if ($response['success'] && !empty($response['data'])) {
                    global $wpdb;
                    $synced = 0;
                    $errors = 0;
                    
                    foreach ($response['data'] as $product) {
                        try {
                            // بررسی وجود کد یکتا در جدول
                            $existing = $wpdb->get_var($wpdb->prepare(
                                "SELECT id FROM {$wpdb->prefix}bim_unique_products WHERE unique_id = %s",
                                $product['unique_id']
                            ));
                            
                            if (!$existing) {
                                // جستجوی محصول با SKU
                                $product_id = wc_get_product_id_by_sku($product['sku']);
                                
                                if ($product_id) {
                                    $wc_product = wc_get_product($product_id);
                                    
                                    if ($wc_product) {
                                        $insert_data = [
                                            'unique_id' => $product['unique_id'],
                                            'barcode' => $product['sku'],
                                            'created_at' => current_time('mysql')
                                        ];
                                        
                                        if ($wc_product->is_type('variation')) {
                                            $insert_data['variation_id'] = $product_id;
                                            $insert_data['product_id'] = $wc_product->get_parent_id();
                                        } else {
                                            $insert_data['product_id'] = $product_id;
                                            $insert_data['variation_id'] = null;
                                        }
                                        
                                        $result = $wpdb->insert(
                                            $wpdb->prefix . 'bim_unique_products',
                                            $insert_data
                                        );
                                        
                                        if ($result !== false) {
                                            $synced++;
                                        } else {
                                            throw new Exception($wpdb->last_error);
                                        }
                                    } else {
                                        throw new Exception('محصول ووکامرس یافت نشد');
                                    }
                                } else {
                                    throw new Exception('محصول با این SKU یافت نشد');
                                }
                            }
                        } catch (\Exception $e) {
                            $errors++;
                            error_log(sprintf(
                                'خطا در درج کد یکتا برای محصول %s (SKU: %s): %s',
                                $product['unique_id'],
                                $product['sku'],
                                $e->getMessage()
                            ));
                        }
                    }
                    
                    wp_send_json_success([
                        'message' => sprintf(
                            'عملیات با موفقیت انجام شد. تعداد درج شده: %d، تعداد خطا: %d',
                            $synced,
                            $errors
                        ),
                        'synced' => $synced,
                        'errors' => $errors
                    ]);
                } else {
                    wp_send_json_error($response['message'] ?? 'خطا در دریافت محصولات');
                }
                break;

            case 'sync_unique_ids':
                $this->start_unique_id_sync();
                break;

            case 'check_sync_progress':
                $this->check_sync_progress();
                break;

            default:
                wp_send_json_error('عملیات نامعتبر');
        }

        if ($response['success']) {
            wp_send_json_success($response['data']);
        } else {
            wp_send_json_error($response['message']);
        }
    }

    private function start_unique_id_sync() {
        global $wpdb;
        
        // دریافت محصولات ساده و متغیر
        $args = array(
            'post_type' => array('product', 'product_variation'),
            'posts_per_page' => -1,
            'post_status' => array('publish', 'draft', 'private', 'pending'),
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_sku',
                    'compare' => 'EXISTS'
                ),
                array(
                    'key' => '_sku',
                    'value' => '',
                    'compare' => '!='
                )
            )
        );
        
        $query = new WP_Query($args);
        $products = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product_id = get_the_ID();
                $product = wc_get_product($product_id);
                
                if ($product) {
                    $sku = $product->get_sku();
                    if (!empty($sku)) {
                        $product_data = array(
                            'ID' => $product_id,
                            'post_type' => get_post_type($product_id),
                            'sku' => $sku
                        );
                        
                        // اگر محصول متغیر است، شناسه محصول اصلی را دریافت کن
                        if ($product_data['post_type'] === 'product_variation') {
                            $product_data['post_parent'] = $product->get_parent_id();
                            // اگر شناسه محصول اصلی یافت نشد، این محصول را نادیده بگیر
                            if (empty($product_data['post_parent'])) {
                                error_log(sprintf(
                                    'خطا: شناسه محصول اصلی برای محصول متغیر %s یافت نشد',
                                    $product_id
                                ));
                                continue;
                            }
                        }
                        
                        $products[] = $product_data;
                    }
                }
            }
        }
        wp_reset_postdata();

        // حذف محصولاتی که قبلاً کد یکتا دارند
        $products_with_unique_id = $wpdb->get_results("
            SELECT product_id, variation_id 
            FROM {$wpdb->prefix}bim_unique_products
            WHERE product_id IS NOT NULL OR variation_id IS NOT NULL
        ");
        
        $products = array_filter($products, function($product) use ($products_with_unique_id) {
            foreach ($products_with_unique_id as $existing) {
                if ($product['post_type'] === 'product_variation') {
                    if ($existing->variation_id == $product['ID']) {
                        return false;
                    }
                } else {
                    if ($existing->product_id == $product['ID']) {
                        return false;
                    }
                }
            }
            return true;
        });

        if (empty($products)) {
            wp_send_json_success([
                'total_products' => 0,
                'message' => 'هیچ محصولی برای منطبق‌سازی یافت نشد'
            ]);
            return;
        }

        // ذخیره اطلاعات در ترانزیست
        $sync_data = [
            'total' => count($products),
            'processed' => 0,
            'synced' => 0,
            'errors' => 0,
            'products' => array_values($products)
        ];
        set_transient('bim_unique_id_sync', $sync_data, HOUR_IN_SECONDS);

        wp_send_json_success([
            'total_products' => count($products)
        ]);
    }

    private function check_sync_progress() {
        $sync_data = get_transient('bim_unique_id_sync');
        
        if (!$sync_data) {
            wp_send_json_error('اطلاعات همگام‌سازی یافت نشد');
            return;
        }

        if ($sync_data['processed'] >= $sync_data['total']) {
            delete_transient('bim_unique_id_sync');
            wp_send_json_success([
                'status' => 'completed',
                'total' => $sync_data['total'],
                'processed' => $sync_data['processed'],
                'synced' => $sync_data['synced'],
                'errors' => $sync_data['errors']
            ]);
            return;
        }

        // پردازش 5 محصول در هر درخواست
        $batch_size = 5;
        $api = BIM_API::get_instance();
        
        for ($i = 0; $i < $batch_size && $sync_data['processed'] < $sync_data['total']; $i++) {
            $product = $sync_data['products'][$sync_data['processed']];
            
            try {
                $response = $api->request('/products/unique-by-sku/' . $product['sku'],'GET');
                
                if ($response['success'] && !empty($response['data']['unique_id'])) {
                    global $wpdb;
                    
                    // بررسی وجود رکورد قبلی
                    $existing = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM {$wpdb->prefix}bim_unique_products WHERE " . 
                        ($product['post_type'] === 'product_variation' ? 
                            'variation_id = %d AND product_id = %d' : 
                            'product_id = %d'),
                        $product['post_type'] === 'product_variation' ? 
                            array($product['ID'], $product['post_parent']) : 
                            array($product['ID'])
                    ));
                    
                    if ($existing) {
                        // به‌روزرسانی رکورد موجود
                        $update_data = [
                            'unique_id' => $response['data']['unique_id'],
                            'barcode' => $product['sku'],
                            'updated_at' => current_time('mysql')
                        ];

                        $where = $product['post_type'] === 'product_variation' ? 
                            array(
                                'variation_id' => $product['ID'],
                                'product_id' => $product['post_parent']
                            ) : 
                            array('product_id' => $product['ID']);

                        $result = $wpdb->update(
                            $wpdb->prefix . 'bim_unique_products',
                            $update_data,
                            $where
                        );

                        if ($result === false) {
                            throw new Exception($wpdb->last_error);
                        }
                    } 
                    else {
                        // ایجاد رکورد جدید
                        $insert_data = [
                            'unique_id' => $response['data']['unique_id'],
                            'barcode' => $product['sku'],
                            'created_at' => current_time('mysql')
                        ];

                        if ($product['post_type'] === 'product_variation') {
                            if (empty($product['post_parent'])) {
                                throw new Exception('شناسه محصول اصلی برای محصول متغیر یافت نشد');
                            }
                            $insert_data['variation_id'] = $product['ID'];
                            $insert_data['product_id'] = $product['post_parent'];
                        } else {
                            $insert_data['product_id'] = $product['ID'];
                            $insert_data['variation_id'] = null;
                        }

                        $result = $wpdb->insert(
                            $wpdb->prefix . 'bim_unique_products',
                            $insert_data
                        );

                        if ($result === false) {
                            throw new Exception($wpdb->last_error);
                        }
                    }
                    
                    $sync_data['synced']++;
                }
                else {
                    throw new Exception($response['message'] ?? 'خطای نامشخص');
                }
            } catch (\Exception $e) {
                $sync_data['errors']++;
                error_log(sprintf(
                    'خطا در پردازش محصول %s (SKU: %s): %s',
                    $product['ID'],
                    $product['sku'],
                    $e->getMessage()
                ));
                
                // اگر تعداد خطاها از حد مجاز بیشتر شد، عملیات را متوقف کن
                if ($sync_data['errors'] >= 10) {
                    $sync_data['status'] = 'error';
                    $sync_data['error_message'] = 'تعداد خطاها از حد مجاز بیشتر شد. عملیات متوقف شد.';
                    break;
                }
            }
            
            $sync_data['processed']++;
        }

        set_transient('bim_unique_id_sync', $sync_data, HOUR_IN_SECONDS);

        wp_send_json_success([
            'status' => 'processing',
            'total' => $sync_data['total'],
            'processed' => $sync_data['processed'],
            'synced' => $sync_data['synced'],
            'errors' => $sync_data['errors']
        ]);
    }

    public function handle_clear_logs() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bim_clear_logs')) {
            wp_send_json_error(array('message' => 'توکن امنیتی نامعتبر است'));
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
            return;
        }

        $logger = BIM_Logger::get_instance();
        $result = $logger->clear_logs();

        if ($result) {
            wp_send_json_success(array('message' => 'همه لاگ‌ها با موفقیت حذف شدند'));
        } else {
            wp_send_json_error(array('message' => 'خطا در حذف لاگ‌ها'));
        }
    }

    public function handle_export_logs() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bim_export_logs')) {
            wp_send_json_error(array('message' => 'توکن امنیتی نامعتبر است'));
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
            return;
        }

        $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
        
        $logger = BIM_Logger::get_instance();
        $result = $logger->export_logs(array(
            'type' => $type,
            'date' => $date
        ));

        if ($result && $result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(array('message' => 'هیچ گزارشی برای خروجی گرفتن یافت نشد'));
        }
    }

    public function sanitize_settings($input) {
        $sanitized = array();

        // تنظیمات اصلی
        $sanitized['enable_price_update'] = isset($input['enable_price_update']);
        $sanitized['enable_stock_update'] = isset($input['enable_stock_update']);
        $sanitized['enable_name_update'] = isset($input['enable_name_update']);
        $sanitized['enable_new_product'] = isset($input['enable_new_product']);
        $sanitized['enable_invoice'] = isset($input['enable_invoice']);
        $sanitized['enable_cart_sync'] = isset($input['enable_cart_sync']);

        // تنظیمات واحد قیمت
        $sanitized['rain_sale_price_unit'] = sanitize_text_field($input['rain_sale_price_unit'] ?? 'rial');
        $sanitized['woocommerce_price_unit'] = sanitize_text_field($input['woocommerce_price_unit'] ?? 'toman');

        // تنظیمات فاکتور
        $sanitized['invoice_settings'] = array(
            'cash_on_delivery' => sanitize_text_field($input['invoice_settings']['cash_on_delivery'] ?? 'cash'),
            'credit_payment' => sanitize_text_field($input['invoice_settings']['credit_payment'] ?? 'cash'),
            'invoice_pending_type' => sanitize_text_field($input['invoice_settings']['invoice_pending_type'] ?? 'off'),
            'invoice_on_hold_type' => sanitize_text_field($input['invoice_settings']['invoice_on_hold_type'] ?? 'off'),
            'invoice_processing_type' => sanitize_text_field($input['invoice_settings']['invoice_processing_type'] ?? 'invoice'),
            'invoice_complete_type' => sanitize_text_field($input['invoice_settings']['invoice_complete_type'] ?? 'off'),
            'invoice_cancelled_type' => sanitize_text_field($input['invoice_settings']['invoice_cancelled_type'] ?? 'off'),
            'invoice_refunded_type' => sanitize_text_field($input['invoice_settings']['invoice_refunded_type'] ?? 'off'),
            'invoice_failed_type' => sanitize_text_field($input['invoice_settings']['invoice_failed_type'] ?? 'off')
        );

        return $sanitized;
    }

    public function save_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(__('شما دسترسی لازم برای انجام این عملیات را ندارید.', 'baran-inventory-manager'));
        }

        check_admin_referer('bim_save_settings');

        $settings = array(
            'enable_price_update' => isset($_POST['enable_price_update']),
            'enable_stock_update' => isset($_POST['enable_stock_update']),
            'enable_name_update' => isset($_POST['enable_name_update']),
            'enable_new_product' => isset($_POST['enable_new_product']),
            'enable_invoice' => isset($_POST['enable_invoice']),
            'enable_cart_sync' => isset($_POST['enable_cart_sync']),
            'rain_sale_price_unit' => sanitize_text_field($_POST['rain_sale_price_unit']),
            'woocommerce_price_unit' => sanitize_text_field($_POST['woocommerce_price_unit']),
            'invoice_settings' => array(
                'cash_on_delivery' => sanitize_text_field($_POST['cash_on_delivery']),
                'credit_payment' => sanitize_text_field($_POST['credit_payment']),
                'invoice_pending_type' => sanitize_text_field($_POST['invoice_pending_type']),
                'invoice_on_hold_type' => sanitize_text_field($_POST['invoice_on_hold_type']),
                'invoice_processing_type' => sanitize_text_field($_POST['invoice_processing_type']),
                'invoice_complete_type' => sanitize_text_field($_POST['invoice_complete_type']),
                'invoice_cancelled_type' => sanitize_text_field($_POST['invoice_cancelled_type']),
                'invoice_refunded_type' => sanitize_text_field($_POST['invoice_refunded_type']),
                'invoice_failed_type' => sanitize_text_field($_POST['invoice_failed_type'])
            )
        );

        // استفاده از کلاس BIM_Settings برای ذخیره تنظیمات
        $settings_instance = BIM_Settings::get_instance();
        $result = $settings_instance->update($settings);
        
        if ($result) {
            add_settings_error(
                'bim_settings',
                'settings_updated',
                __('تنظیمات با موفقیت ذخیره شد.', 'baran-inventory-manager'),
                'updated'
            );
        } else {
            add_settings_error(
                'bim_settings',
                'settings_error',
                __('خطا در ذخیره تنظیمات.', 'baran-inventory-manager'),
                'error'
            );
        }
    }
} 