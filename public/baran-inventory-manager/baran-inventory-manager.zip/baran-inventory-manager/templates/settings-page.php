<?php
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('bim_settings', array());
$default_settings = array(
    'enable_price_update' => false,
    'enable_stock_update' => false,
    'enable_name_update' => false,
    'enable_new_product' => false,
    'enable_invoice' => false,
    'enable_cart_sync' => false,
    'invoice_settings' => array(
        'cash_on_delivery' => false,
        'credit_payment' => false
    )
);

$settings = wp_parse_args($settings, $default_settings);
?>

<div class="wrap bim-admin">
    <h1>تنظیمات مدیریت موجودی باران</h1>
    
    <?php settings_errors(); ?>
    
    <!-- فرم تنظیمات -->
    <form id="bim-settings-form" method="post">
        <?php wp_nonce_field('bim_save_settings', 'bim_settings_nonce'); ?>
        
        <div class="bim-cards">
            <!-- تنظیمات همگام‌سازی -->
            <div class="bim-card">
                <h2>تنظیمات همگام‌سازی</h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">به‌روزرسانی قیمت</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="enable_price_update" 
                                       value="1" 
                                       <?php checked($settings['enable_price_update']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">فعال‌سازی به‌روزرسانی خودکار قیمت محصولات</span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">به‌روزرسانی موجودی</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="enable_stock_update" 
                                       value="1" 
                                       <?php checked($settings['enable_stock_update']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">فعال‌سازی به‌روزرسانی خودکار موجودی محصولات</span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">به‌روزرسانی نام</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="enable_name_update" 
                                       value="1" 
                                       <?php checked($settings['enable_name_update']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">فعال‌سازی به‌روزرسانی خودکار نام محصولات</span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">افزودن محصول جدید</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="enable_new_product" 
                                       value="1" 
                                       <?php checked($settings['enable_new_product']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">فعال‌سازی افزودن خودکار محصولات جدید</span>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- تنظیمات فاکتور -->
            <div class="bim-card">
                <h2>تنظیمات فاکتور</h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">فاکتور</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="enable_invoice" 
                                       value="1" 
                                       <?php checked($settings['enable_invoice']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">فعال‌سازی ارسال خودکار فاکتور</span>
                        </td>
                    </tr>
                    
                    <tr class="invoice-settings" style="<?php echo $settings['enable_invoice'] ? '' : 'display: none;'; ?>">
                        <th scope="row">پرداخت در محل</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="invoice_settings[cash_on_delivery]" 
                                       value="1" 
                                       <?php checked($settings['invoice_settings']['cash_on_delivery']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">ارسال فاکتور برای سفارش‌های پرداخت در محل</span>
                        </td>
                    </tr>
                    
                    <tr class="invoice-settings" style="<?php echo $settings['enable_invoice'] ? '' : 'display: none;'; ?>">
                        <th scope="row">پرداخت اعتباری</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="invoice_settings[credit_payment]" 
                                       value="1" 
                                       <?php checked($settings['invoice_settings']['credit_payment']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">ارسال فاکتور برای سفارش‌های پرداخت اعتباری</span>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- تنظیمات سبد خرید -->
            <div class="bim-card">
                <h2>تنظیمات سبد خرید</h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">همگام‌سازی سبد خرید</th>
                        <td>
                            <label class="bim-switch">
                                <input type="checkbox" 
                                       name="enable_cart_sync" 
                                       value="1" 
                                       <?php checked($settings['enable_cart_sync']); ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="description">فعال‌سازی همگام‌سازی خودکار سبد خرید</span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <p class="submit">
            <button type="submit" id="bim-save-settings" class="button button-primary">
                ذخیره تنظیمات
                <span class="spinner"></span>
            </button>
        </p>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    // نمایش/مخفی کردن تنظیمات فاکتور
    $('input[name="enable_invoice"]').on('change', function() {
        $('.invoice-settings').toggle(this.checked);
    });
    
    // ارسال فرم تنظیمات
    $('#bim-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $submit = $('#bim-save-settings');
        var $spinner = $submit.find('.spinner');
        
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_save_settings',
                nonce: $('#bim_settings_nonce').val(),
                settings: $form.serialize()
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('خطا در ذخیره تنظیمات: ' + response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $submit.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
});
</script> 