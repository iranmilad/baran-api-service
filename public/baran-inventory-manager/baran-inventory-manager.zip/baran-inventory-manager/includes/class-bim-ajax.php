<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Ajax {
    private static $instance = null;
    private $api;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('wp_ajax_bim_verify_license', array($this, 'verify_license'));
        add_action('wp_ajax_bim_resend_order', array($this, 'resend_order'));
        add_action('wp_ajax_bim_clear_data', array($this, 'clearData'));
        add_action('wp_ajax_bim_refresh_token', array($this, 'refresh_token'));
    }
    
    public function verify_license() {
        check_ajax_referer('bim_verify_license', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'شما دسترسی لازم را ندارید.'));
        }
        
        $license_key = sanitize_text_field($_POST['license_key']);
        
        if (empty($license_key)) {
            wp_send_json_error(array('message' => 'کد لایسنس نمی‌تواند خالی باشد.'));
        }
        
        $result = $this->api->verify_license($license_key);
        
        if ($result['success']) {
            if (isset($result['data']['token'])) {
                update_option('bim_api_token', $result['data']['token']);
            }
            wp_send_json_success(array('message' => 'لایسنس با موفقیت تایید شد.'));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
    
    public function resend_order() {
        check_ajax_referer('bim_resend_order', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'شما دسترسی لازم را ندارید.'));
        }
        
        $order_id = intval($_POST['order_id']);
        
        if (empty($order_id)) {
            wp_send_json_error(array('message' => 'شناسه سفارش نامعتبر است.'));
        }
        
        $result = $this->api->resend_order($order_id);
        
        if ($result && $result['success']) {
            wp_send_json_success(array('message' => 'سفارش با موفقیت ارسال شد.'));
        } else {
            wp_send_json_error(array('message' => 'خطا در ارسال سفارش.'));
        }
    }
    
    public function clearData() {
        check_ajax_referer('bim_clear_data', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'شما دسترسی لازم را ندارید.'));
        }
        
        $result = $this->api->clearData();
        
        if ($result['success']) {
            wp_send_json_success(array('message' => 'داده‌ها با موفقیت پاک شدند.'));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
    
    public function refresh_token() {
        check_ajax_referer('bim_refresh_token', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'شما دسترسی لازم را ندارید.'));
        }
        
        $license_key = get_option('bim_license_key');
        
        if (empty($license_key)) {
            wp_send_json_error(array('message' => 'لایسنس فعال نشده است.'));
        }
        
        $result = $this->api->verify_license($license_key);
        
        if ($result['success'] && isset($result['data']['token'])) {
            update_option('bim_api_token', $result['data']['token']);
            wp_send_json_success(array('message' => 'توکن با موفقیت بروزرسانی شد.'));
        } else {
            wp_send_json_error(array('message' => $result['message'] ?? 'خطا در بروزرسانی توکن.'));
        }
    }
} 