<?php
if (!defined('ABSPATH')) {
    exit;
}

class Baran_Inventory_Manager {
    private static $instance = null;
    private $logger;
    private $api;
    private $ajax;
    private $order_columns;
    private $settings;
    private $admin;
    private $connection_tester;
    private $product;
    private $invoice;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_components();
        $this->init_hooks();
    }

    private function init_components() {
        $this->logger = BIM_Logger::get_instance();
        $this->api = BIM_API::get_instance();
        $this->ajax = BIM_Ajax::get_instance();
        $this->order_columns = BIM_Order_Columns::get_instance();
        $this->settings = BIM_Settings::get_instance();
        $this->admin = BIM_Admin::get_instance();
        $this->connection_tester = BIM_Connection_Tester::get_instance();
        $this->product = BIM_Product::get_instance();
        $this->invoice = BIM_Invoice::get_instance();
    }

    private function init_hooks() {
        // فعال‌سازی پلاگین
        register_activation_hook(BIM_PLUGIN_DIR . 'baran-inventory-manager.php', array($this, 'activate'));
        
        // غیرفعال‌سازی پلاگین
        register_deactivation_hook(BIM_PLUGIN_DIR . 'baran-inventory-manager.php', array($this, 'deactivate'));
        
        // بارگذاری فایل‌های ترجمه
        add_action('plugins_loaded', array($this, 'load_textdomain'));

        // هوک‌های AJAX
        add_action('wp_ajax_bim_save_settings', array($this, 'ajax_save_settings'));
        add_action('wp_ajax_bim_test_connection', array($this->connection_tester, 'test_connection'));
        add_action('wp_ajax_bim_sync_products', array($this, 'sync_products'));
        add_action('wp_ajax_bim_retry_failed_invoices', array($this, 'retry_failed_invoices'));
        add_action('wp_ajax_bim_export_logs', array($this, 'ajax_export_logs'));
        add_action('wp_ajax_bim_clear_logs', array($this, 'ajax_clear_logs'));

        // هوک‌های به‌روزرسانی از طریق API ووکامرس
        add_action('woocommerce_api_product_updated', array($this, 'update_product_last_sync_time'), 10, 1);
        add_action('woocommerce_api_product_variation_updated', array($this, 'update_variation_last_sync_time'), 10, 1);

        // هوک‌های نمایش وضعیت در پنل ادمین - فقط در صفحات پلاگین
        add_action('admin_notices', array($this, 'maybe_display_admin_notices'));

        // هوک‌های همگام‌سازی خودکار
        add_action('bim_sync_products_cron', array($this, 'sync_products'));
        add_action('bim_retry_failed_invoices_cron', array($this, 'retry_failed_invoices'));

        // هوک‌های سبد خرید
        add_action('woocommerce_add_to_cart', array($this, 'notify_cart_add'), 10, 6);
        add_action('woocommerce_remove_cart_item', array($this, 'notify_cart_remove'), 10, 2);
        add_action('woocommerce_update_cart_action_cart_updated', array($this, 'notify_cart_update'), 10, 1);

        // هوک‌های فاکتور
        add_action('woocommerce_checkout_order_processed', array($this, 'create_invoice'), 10, 1);
        add_action('woocommerce_order_status_changed', array($this, 'update_invoice_status'), 10, 3);
    }

    public function activate() {
        // ایجاد جداول مورد نیاز
        $this->logger->create_log_table();
        
        // تنظیم نسخه پلاگین
        update_option('bim_version', BIM_VERSION);

        // ایجاد نقش‌های مورد نیاز
        $this->create_roles();
        
        // تنظیم مقادیر پیش‌فرض
        $this->set_default_options();

        // تنظیم کرون جاب‌ها
        if (!wp_next_scheduled('bim_sync_products_cron')) {
            wp_schedule_event(time(), 'hourly', 'bim_sync_products_cron');
        }
        if (!wp_next_scheduled('bim_retry_failed_invoices_cron')) {
            wp_schedule_event(time(), 'daily', 'bim_retry_failed_invoices_cron');
        }
    }

    public function deactivate() {
        // حذف کرون جاب‌ها
        wp_clear_scheduled_hook('bim_sync_products_cron');
        wp_clear_scheduled_hook('bim_retry_failed_invoices_cron');
    }

    public function load_textdomain() {
        load_plugin_textdomain(
            'baran-inventory-manager',
            false,
            dirname(plugin_basename(BIM_PLUGIN_DIR)) . '/languages'
        );
    }

    private function create_roles() {
        add_role('bim_manager', 'مدیر موجودی باران', array(
            'read' => true,
            'manage_woocommerce' => true,
            'edit_products' => true,
            'read_products' => true,
            'delete_products' => true,
            'edit_others_products' => true,
            'publish_products' => true,
            'read_private_products' => true,
            'manage_product_terms' => true,
            'edit_product_terms' => true,
            'delete_product_terms' => true,
            'assign_product_terms' => true
        ));
    }

    private function set_default_options() {
        // تنظیمات API
        add_option('bim_api_url', BIM_DEFAULT_API_URL, '', 'no');
        add_option('bim_license_key', '', '', 'no');
        add_option('bim_api_token', '', '', 'no');
        add_option('bim_expiry_date', '', '', 'no');
        add_option('bim_last_sync_id', '', '', 'no');
        add_option('bim_account_type', 'basic', '', 'no');

        // تنظیمات پیش‌فرض
        $default_settings = array(
            'enable_price_update' => false,
            'enable_stock_update' => false,
            'enable_name_update' => false,
            'enable_new_product' => false,
            'enable_invoice' => false,
            'enable_cart_sync' => false,
            'rain_sale_price_unit' => 'rial',
            'woocommerce_price_unit' => 'toman',
            'invoice_settings' => array(
                'cash_on_delivery' => 'cash',
                'credit_payment' => 'cash',
                'invoice_pending_type' => 'off',
                'invoice_on_hold_type' => 'off',
                'invoice_processing_type' => 'invoice',
                'invoice_complete_type' => 'off',
                'invoice_cancelled_type' => 'off',
                'invoice_refunded_type' => 'off',
                'invoice_failed_type' => 'off'
            )
        );
        add_option('bim_settings', $default_settings, '', 'no');
    }

    public function get_account_type() {
        return $this->api->get_account_type();
    }

    public function update_account_type($account_type) {
        update_option('bim_account_type', $account_type);
    }

    public function update_product_last_sync_time($product_id) {
        $this->api->update_product_last_sync_time($product_id);
    }

    public function update_variation_last_sync_time($variation_id) {
        $this->api->update_variation_last_sync_time($variation_id);
    }

    public function maybe_display_admin_notices() {
        // چک کردن اینکه آیا در صفحه پلاگین یا پیشخوان هستیم
        $current_screen = get_current_screen();
        if (!$current_screen) {
            return;
        }

        // لیست صفحات مجاز برای نمایش نوتیفیکیشن
        $allowed_screens = array(
            'toplevel_page_baran-inventory-manager',
            'inventory-manager_page_baran-inventory-manager-settings',
            'inventory-manager_page_bim-logs',
            'admin_page_bim-logs',
            'dashboard' // اضافه کردن پیشخوان وردپرس
        );

        if (!in_array($current_screen->id, $allowed_screens)) {
            return;
        }

        // نمایش نوتیفیکیشن‌ها در صفحات مجاز
        $this->display_connection_status();
        $this->display_license_status();
    }

    public function display_connection_status() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $connection_status = $this->connection_tester->get_connection_status();
        if (!$connection_status['connected']) {
            ?>
            <div class="notice notice-error">
                <p>
                    <strong>مدیریت موجودی باران:</strong>
                    اتصال به وب‌سرویس برقرار نیست. لطفاً تنظیمات را بررسی کنید.
                    <a href="<?php echo admin_url('admin.php?page=baran-inventory-manager'); ?>">رفتن به تنظیمات</a>
                </p>
            </div>
            <?php
        }
    }

    public function display_license_status() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $license_key = get_option('bim_license_key');
        $expiry_date = get_option('bim_expiry_date');
        $account_type = $this->get_account_type();

        if (!$license_key) {
            ?>
            <div class="notice notice-warning">
                <p>
                    <strong>مدیریت موجودی باران:</strong>
                    لایسنس فعال نشده است. لطفاً لایسنس خود را وارد کنید.
                    <a href="<?php echo admin_url('admin.php?page=baran-inventory-manager'); ?>">فعال‌سازی لایسنس</a>
                </p>
            </div>
            <?php
        } elseif ($expiry_date && strtotime($expiry_date) < time()) {
            ?>
            <div class="notice notice-error">
                <p>
                    <strong>مدیریت موجودی باران:</strong>
                    اعتبار لایسنس شما به پایان رسیده است. لطفاً لایسنس خود را تمدید کنید.
                    <a href="<?php echo admin_url('admin.php?page=baran-inventory-manager'); ?>">تمدید لایسنس</a>
                </p>
            </div>
            <?php
        } else {
            $account_type_labels = array(
                'basic' => 'پایه',
                'standard' => 'استاندارد',
                'premium' => 'حرفه‌ای',
                'enterprise' => 'سازمانی',
                'ultimate' => 'نهایی'
            );
            $account_type_label = isset($account_type_labels[$account_type]) ? $account_type_labels[$account_type] : $account_type;
            ?>
            <div class="notice notice-success">
                <p style="margin: 0;">
                    <strong>مدیریت موجودی باران:</strong>
                    <span style="display: inline-block; margin-right: 5px;">لایسنس فعال است</span>
                </p>
                <p style="margin: 5px 0 0 0;">
                    <span style="display: inline-block; padding: 3px 8px; background-color: #2271b1; color: white; border-radius: 3px;">
                        نوع اکانت: <?php echo esc_html($account_type_label); ?>
                    </span>
                    <?php if ($expiry_date): ?>
                        <span style="display: inline-block; margin-right: 10px; font-size: 12px;">
                            اعتبار تا: <?php echo date_i18n('Y-m-d', strtotime($expiry_date)); ?>
                        </span>
                    <?php endif; ?>
                </p>
            </div>
            <?php
        }
    }

    public function sync_products() {
        try {
            $settings = $this->settings->get();
            
            if (!$settings['enable_price_update'] && !$settings['enable_stock_update'] && !$settings['enable_name_update']) {
                return;
            }
            
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'meta_query' => array(
                    array(
                        'key' => '_isbn',
                        'compare' => 'EXISTS'
                    )
                )
            );
            
            $products = get_posts($args);
            
            foreach ($products as $product) {
                $isbn = get_post_meta($product->ID, '_isbn', true);
                
                $response = $this->product->get_product_info($isbn);
                
                if (!$response['success']) {
                    continue;
                }
                
                $this->product->update_product($product->ID);
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('product_sync_failed', 'خطا در همگام‌سازی محصولات', array(
                'error' => $e->getMessage()
            ));
        }
    }

    public function retry_failed_invoices() {
        try {
            $failed_invoices = get_option('bim_failed_invoices', array());
            
            if (empty($failed_invoices)) {
                return;
            }
            
            foreach ($failed_invoices as $key => $invoice) {
                $response = $this->invoice->create_invoice($invoice['order_id']);
                
                if ($response['success']) {
                    unset($failed_invoices[$key]);
                }
            }
            
            update_option('bim_failed_invoices', $failed_invoices);
            
        } catch (Exception $e) {
            $this->logger->add_log('invoice_retry_failed', 'خطا در ارسال مجدد فاکتورها', array(
                'error' => $e->getMessage()
            ));
        }
    }

    public function notify_cart_add($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data) {
        try {
            $settings = $this->settings->get();
            
            if (!$settings['enable_cart_sync']) {
                return;
            }
            
            $isbn = get_post_meta($product_id, '_isbn', true);
            
            if (!$isbn) {
                return;
            }
            
            $response = $this->api->request('cart/add', 'POST', array(
                'isbn' => $isbn,
                'quantity' => $quantity
            ));
            
            if ($response['success']) {
                $this->logger->add_log('cart_synced', 'سبد خرید با موفقیت همگام‌سازی شد', array(
                    'product_id' => $product_id,
                    'isbn' => $isbn,
                    'quantity' => $quantity
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('cart_sync_failed', 'خطا در همگام‌سازی سبد خرید', array(
                'error' => $e->getMessage(),
                'product_id' => $product_id,
                'quantity' => $quantity
            ));
        }
    }

    public function notify_cart_remove($cart_item_key, $cart) {
        try {
            $settings = $this->settings->get();
            
            if (!$settings['enable_cart_sync']) {
                return;
            }
            
            $cart_item = $cart->get_cart_item($cart_item_key);
            $product_id = $cart_item['product_id'];
            $isbn = get_post_meta($product_id, '_isbn', true);
            
            if (!$isbn) {
                return;
            }
            
            $response = $this->api->request('cart/remove', 'POST', array(
                'isbn' => $isbn
            ));
            
            if ($response['success']) {
                $this->logger->add_log('cart_synced', 'محصول از سبد خرید حذف شد', array(
                    'product_id' => $product_id,
                    'isbn' => $isbn
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('cart_sync_failed', 'خطا در حذف محصول از سبد خرید', array(
                'error' => $e->getMessage(),
                'product_id' => $product_id
            ));
        }
    }

    public function notify_cart_update($cart_updated) {
        try {
            $settings = $this->settings->get();
            
            if (!$settings['enable_cart_sync'] || !$cart_updated) {
                return;
            }
            
            $cart = WC()->cart;
            $items = array();
            
            foreach ($cart->get_cart() as $cart_item) {
                $product_id = $cart_item['product_id'];
                $isbn = get_post_meta($product_id, '_isbn', true);
                
                if ($isbn) {
                    $items[] = array(
                        'isbn' => $isbn,
                        'quantity' => $cart_item['quantity']
                    );
                }
            }
            
            $response = $this->api->request('cart/update', 'POST', array(
                'items' => $items
            ));
            
            if ($response['success']) {
                $this->logger->add_log('cart_synced', 'سبد خرید با موفقیت به‌روزرسانی شد', array(
                    'items' => $items
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('cart_sync_failed', 'خطا در به‌روزرسانی سبد خرید', array(
                'error' => $e->getMessage()
            ));
        }
    }

    public function create_invoice($order_id) {
        try {
            $settings = $this->settings->get();
            
            if (!$settings['enable_invoice']) {
                return;
            }
            
            $order = wc_get_order($order_id);
            $payment_method = $order->get_payment_method();
            
            if ($payment_method === 'cod' && !$settings['invoice_settings']['cash_on_delivery']) {
                return;
            }
            
            if ($payment_method === 'credit' && !$settings['invoice_settings']['credit_payment']) {
                return;
            }
            
            $response = $this->invoice->create_invoice($order_id);
            
            if (!$response['success']) {
                $failed_invoices = get_option('bim_failed_invoices', array());
                $failed_invoices[] = array(
                    'order_id' => $order_id,
                    'data' => $response['data']
                );
                update_option('bim_failed_invoices', $failed_invoices);
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('invoice_creation_failed', 'خطا در ایجاد فاکتور', array(
                'error' => $e->getMessage(),
                'order_id' => $order_id
            ));
        }
    }

    public function update_invoice_status($order_id, $old_status, $new_status) {
        try {
            $settings = $this->settings->get();
            
            if (!$settings['enable_invoice']) {
                return;
            }
            
            $invoice_id = get_post_meta($order_id, '_bim_invoice_id', true);
            
            if (!$invoice_id) {
                return;
            }
            
            $response = $this->invoice->get_invoice($invoice_id);
            
            if ($response['success']) {
                $this->api->request('invoices/' . $invoice_id . '/status', 'PUT', array(
                    'status' => $new_status
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->add_log('invoice_status_update_failed', 'خطا در به‌روزرسانی وضعیت فاکتور', array(
                'error' => $e->getMessage(),
                'order_id' => $order_id,
                'invoice_id' => $invoice_id,
                'new_status' => $new_status
            ));
        }
    }

    public function ajax_save_settings() {
        check_ajax_referer('bim-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'شما دسترسی لازم را ندارید'));
        }
        
        parse_str($_POST['settings'], $settings);
        
        $sanitized = $this->sanitize_settings($settings);
        
        if ($this->settings->update($sanitized)) {
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'خطا در ذخیره تنظیمات'));
        }
    }

    public function sanitize_settings($input) {
        $sanitized = [];

        $sanitized['enable_price_update'] = isset($input['enable_price_update']);
        $sanitized['enable_stock_update'] = isset($input['enable_stock_update']);
        $sanitized['enable_name_update'] = isset($input['enable_name_update']);
        $sanitized['enable_new_product'] = isset($input['enable_new_product']);
        $sanitized['enable_invoice'] = isset($input['enable_invoice']);
        $sanitized['enable_cart_sync'] = isset($input['enable_cart_sync']);

        $sanitized['invoice_settings'] = [
            'cash_on_delivery' => isset($input['invoice_settings']['cash_on_delivery']),
            'credit_payment' => isset($input['invoice_settings']['credit_payment'])
        ];

        $sanitized['payment_gateways'] = $this->settings->get('payment_gateways', []);

        return $sanitized;
    }

    public function ajax_export_logs() {
        check_ajax_referer('bim-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('شما دسترسی لازم را ندارید');
        }
        
        $type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
        $date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
        
        $this->logger->export_logs(array(
            'type' => $type,
            'date' => $date
        ));
    }

    public function ajax_clear_logs() {
        check_ajax_referer('bim-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'شما دسترسی لازم را ندارید'));
        }
        
        if ($this->logger->clear_logs()) {
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'خطا در پاک کردن گزارش‌ها'));
        }
    }
} 