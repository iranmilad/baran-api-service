<?php
if (!defined('ABSPATH')) {
    require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

class BIM_Notifications {
    private static $instance = null;
    private $api;
    private $logger;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->logger = BIM_Logger::get_instance();
        
        add_action('admin_notices', array($this, 'display_notifications'));
        add_action('wp_ajax_bim_dismiss_notification', array($this, 'dismiss_notification'));
    }

    private function get_notifications() {
        try {
            $response = $this->api->request('notifications');
            
            if (!$response['success']) {
                $this->logger->add_log('error', 'خطا در دریافت اعلان‌ها: ' . ($response['message'] ?? 'خطای ناشناخته'));
                return array();
            }

            return $response['data']['notifications'] ?? array();
        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در دریافت اعلان‌ها: ' . $e->getMessage());
            return array();
        }
    }

    public function display_notifications() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $notifications = $this->get_notifications();
        $dismissed = get_option('bim_dismissed_notifications', array());

        if (empty($notifications)) {
            return;
        }

        foreach ($notifications as $notification) {
            if (in_array($notification['id'], $dismissed)) {
                continue;
            }

            $type = $notification['type'] ?? 'info';
            $message = $notification['message'] ?? '';
            $title = $notification['title'] ?? 'اطلاعیه مدیریت موجودی باران';
            $expiry_date = $notification['expiry_date'] ?? null;

            if ($expiry_date && strtotime($expiry_date) < time()) {
                continue;
            }

            if (empty($message)) {
                continue;
            }

            ?>
            <div class="notice notice-<?php echo esc_attr($type); ?> is-dismissible bim-notification" 
                 data-notification-id="<?php echo esc_attr($notification['id']); ?>">
                <p>
                    <strong><?php echo esc_html($title); ?></strong>
                    <br>
                    <?php echo wp_kses_post($message); ?>
                </p>
            </div>
            <?php
        }
    }

    public function dismiss_notification() {
        try {
            check_ajax_referer('bim_dismiss_notification', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
                return;
            }

            $notification_id = isset($_POST['notification_id']) ? sanitize_text_field($_POST['notification_id']) : '';
            $license_key = get_option('bim_license_key');
            
            if (empty($notification_id)) {
                wp_send_json_error(array('message' => 'شناسه اطلاعیه الزامی است'));
                return;
            }

            if (empty($license_key)) {
                wp_send_json_error(array('message' => 'لایسنس یافت نشد'));
                return;
            }

            // ارسال درخواست به API
            $response = $this->api->request('notifications/dismiss', 'POST', array(
                'notification_id' => $notification_id,
                'license_key' => $license_key
            ));

            if (!$response['success']) {
                $this->logger->add_log('error', 'خطا در بستن اطلاعیه: ' . ($response['message'] ?? 'خطای ناشناخته'));
                wp_send_json_error(array('message' => $response['message'] ?? 'خطا در بستن اطلاعیه'));
                return;
            }

            // ذخیره در دیتابیس وردپرس
            $dismissed = get_option('bim_dismissed_notifications', array());
            if (!in_array($notification_id, $dismissed)) {
                $dismissed[] = $notification_id;
                update_option('bim_dismissed_notifications', array_unique($dismissed));
            }

            $this->logger->add_log('notification_dismissed', 'اطلاعیه با موفقیت بسته شد', array(
                'notification_id' => $notification_id
            ));

            wp_send_json_success(array('message' => 'اطلاعیه با موفقیت بسته شد'));

        } catch (Exception $e) {
            $this->logger->add_log('error', 'خطا در بستن اطلاعیه: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'خطا در بستن اطلاعیه: ' . $e->getMessage()));
        }
    }
}