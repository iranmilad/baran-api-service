<?php
/**
 * کلاس مدیریت به‌روزرسانی پلاگین
 *
 * @package Baran_Inventory_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

class Baran_Inventory_Manager_Updater {
    private $plugin_file;
    private $update_url;

    public function __construct($plugin_file, $update_url) {
        $this->plugin_file = $plugin_file;
        $this->update_url = $update_url;

        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_update'));
        add_filter('plugins_api', array($this, 'plugins_api'), 10, 3);
    }

    public function check_for_update($transient) {
        if (empty($transient->checked)) return $transient;

        $remote = wp_remote_get($this->update_url, array('timeout' => 10));
        if (is_wp_error($remote) || wp_remote_retrieve_response_code($remote) != 200) {
            // اگر سرور بروزرسانی در دسترس نبود، هیچ اقدامی انجام نشود
            return $transient;
        }

        $data = json_decode(wp_remote_retrieve_body($remote));
        if (!isset($data->version) || !isset($data->download_url)) {
            // اگر داده معتبر نبود، هیچ اقدامی انجام نشود
            return $transient;
        }
        if (version_compare(BIM_VERSION, $data->version, '<')) {
            $plugin_slug = plugin_basename($this->plugin_file);
            $transient->response[$plugin_slug] = (object) array(
                'slug' => dirname($plugin_slug),
                'plugin' => $plugin_slug,
                'new_version' => $data->version,
                'url' => 'https://samtatech.org',
                'package' => $data->download_url,
                'tested' => '6.4',
                'requires' => '5.8'
            );
        }
        return $transient;
    }

    public function plugins_api($result, $action, $args) {
        if ($action !== 'plugin_information' || $args->slug !== dirname(plugin_basename($this->plugin_file))) {
            return $result;
        }
        $remote = wp_remote_get($this->update_url, array('timeout' => 10));
        if (is_wp_error($remote) || wp_remote_retrieve_response_code($remote) != 200) {
            // اگر سرور بروزرسانی در دسترس نبود، اطلاعات پیش‌فرض بازگردانده شود
            return $result;
        }
        $data = json_decode(wp_remote_retrieve_body($remote));
        if (!isset($data->version) || !isset($data->download_url)) {
            // اگر داده معتبر نبود، اطلاعات پیش‌فرض بازگردانده شود
            return $result;
        }
        $result = (object) array(
            'name' => 'دستیار فروشگاهی سمتاتک',
            'slug' => dirname(plugin_basename($this->plugin_file)),
            'version' => $data->version,
            'author' => '<a href="https://samtatech.org">Samtatech Group</a>',
            'homepage' => 'https://samtatech.org',
            'download_link' => $data->download_url,
            'sections' => array(
                'description' => 'دستیار فروشگاهی سمتاتک',
                'changelog' => isset($data->changelog) ? $data->changelog : ''
            )
        );
        return $result;
    }
} 