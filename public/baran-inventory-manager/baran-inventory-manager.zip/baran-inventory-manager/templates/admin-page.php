<?php
if (!defined('ABSPATH')) {
    exit;
}

$license_key = get_option('bim_license_key');
$api_token = get_option('bim_api_token');
$expiry_date = get_option('bim_expiry_date');
$account_type = get_option('bim_account_type', 'free');
?>

<div class="wrap bim-admin">
    <h1>مدیریت موجودی باران</h1>
    
    <?php settings_errors(); ?>
    
    <div class="bim-cards">
        <!-- کارت وضعیت لایسنس -->
        <div class="bim-card">
            <h2>وضعیت لایسنس</h2>
            <div class="bim-license-status">
                <?php if ($api_token): ?>
                    <div class="bim-status connected">
                        <span class="dashicons dashicons-yes"></span>
                        <span>فعال</span>
                    </div>
                    <div class="bim-license-info">
                        <p>
                            <strong>نوع حساب:</strong>
                            <?php echo esc_html($account_type); ?>
                        </p>
                        <p>
                            <strong>تاریخ اعتبار:</strong>
                            <?php echo esc_html($expiry_date); ?>
                        </p>
                    </div>
                <?php else: ?>
                    <div class="bim-status disconnected">
                        <span class="dashicons dashicons-no"></span>
                        <span>غیرفعال</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- کارت وضعیت اتصال -->
        <div class="bim-card">
            <h2>وضعیت اتصال</h2>
            <div class="bim-connection-status">
                <div id="bim-connection-status">
                    <span class="spinner is-active"></span>
                    <span>در حال بررسی...</span>
                </div>
                <button type="button" id="bim-test-connection" class="button">
                    تست اتصال
                    <span class="spinner"></span>
                </button>
            </div>
        </div>
    </div>
    
    <!-- فرم تنظیمات لایسنس -->
    <form method="post" action="options.php" id="bim-license-form">
        <?php settings_fields('bim_settings'); ?>
        
        <div class="bim-card">
            <h2>تنظیمات لایسنس</h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="bim_license_key">کد لایسنس</label>
                    </th>
                    <td>
                        <input type="text" 
                               id="bim_license_key" 
                               name="bim_license_key" 
                               value="<?php echo esc_attr($license_key); ?>" 
                               class="regular-text"
                               <?php echo $api_token ? 'disabled' : ''; ?>>
                        <p class="description">کد لایسنس خود را وارد کنید</p>
                    </td>
                </tr>
            </table>
            
            <?php if (!$api_token): ?>
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        فعال‌سازی لایسنس
                        <span class="spinner"></span>
                    </button>
                </p>
            <?php endif; ?>
        </div>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    // بررسی وضعیت اتصال
    function checkConnection() {
        $('#bim-connection-status').html('<span class="spinner is-active"></span><span>در حال بررسی...</span>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_test_connection',
                nonce: '<?php echo wp_create_nonce("bim_test_connection"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#bim-connection-status').html(
                        '<span class="dashicons dashicons-yes" style="color: green;"></span>' +
                        '<span>متصل</span>'
                    );
                } else {
                    $('#bim-connection-status').html(
                        '<span class="dashicons dashicons-no" style="color: red;"></span>' +
                        '<span>غیر متصل</span>'
                    );
                }
            },
            error: function() {
                $('#bim-connection-status').html(
                    '<span class="dashicons dashicons-no" style="color: red;"></span>' +
                    '<span>خطا در بررسی اتصال</span>'
                );
            }
        });
    }
    
    // بررسی اولیه اتصال
    checkConnection();
    
    // تست اتصال
    $('#bim-test-connection').on('click', function() {
        $(this).find('.spinner').addClass('is-active');
        checkConnection();
        $(this).find('.spinner').removeClass('is-active');
    });
    
    // ارسال فرم لایسنس
    $('#bim-license-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $submit = $form.find('button[type="submit"]');
        var $spinner = $submit.find('.spinner');
        
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_verify_license',
                license_key: $('#bim_license_key').val(),
                nonce: '<?php echo wp_create_nonce("bim_verify_license"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('خطا در تایید لایسنس: ' + response.data.message);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور');
            },
            complete: function() {
                $submit.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
});
</script> 