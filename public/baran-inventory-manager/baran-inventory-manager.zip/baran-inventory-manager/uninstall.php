<?php
// اگر وردپرس این فایل را مستقیماً فراخوانی نکند، اجرا نشود
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// حذف تنظیمات
delete_option('bim_settings');
delete_option('bim_api_url');
delete_option('bim_license_key');
delete_option('bim_api_token');
delete_option('bim_expiry_date');
delete_option('bim_last_sync_id');
delete_option('bim_account_type');

// حذف نقش‌ها و قابلیت‌ها
remove_role('bim_manager');

// حذف رویدادهای زمانبندی شده
wp_clear_scheduled_hook('bim_sync_products');
wp_clear_scheduled_hook('bim_retry_failed_invoices');

// حذف جداول دیتابیس
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bim_sync_logs");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bim_failed_invoices");

// پاک کردن تنظیمات
delete_option('bim_version');
delete_option('bim_dismissed_notifications');

// پاک کردن کش‌ها
delete_transient('bim_notifications');

// پاک کردن فایل‌های موقت
$upload_dir = wp_upload_dir();
$log_files = glob($upload_dir['path'] . '/bim-logs-*.csv');

if ($log_files) {
    foreach ($log_files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }
} 