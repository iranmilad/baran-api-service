<?php
/**
 * Plugin Name: دستیار فروشگاهی سمتاتک
 * Plugin URI: https://samtatech.org
 * Description: دستیار فروشگاهی سمتاتک
 * Version: 1.1.2
 * Author: Samtatech Group
 * Author URI: https://samtatech.org
 * Text Domain: samtatech
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// تعریف ثابت‌های افزونه
global $wpdb;
define('BIM_VERSION', '1.1.2');
define('BIM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BIM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BIM_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('BIM_DEFAULT_API_URL', 'https://server.samtatech.org');
define('BIM_UNIQUE_PRODUCTS_TABLE', $wpdb->prefix . 'bim_unique_products');
define('BIM_DEFAULT_SETTINGS', array(
    'enable_price_update' => true,
    'enable_stock_update' => true,
    'enable_name_update' => false,
    'enable_new_product' => false,
    'enable_invoice' => true,
    'enable_cart_sync' => true,
    'rain_sale_price_unit' => 'rial',
    'woocommerce_price_unit' => 'toman',
    'invoice_settings' => array(
        'cash_on_delivery' => 'cash',
        'credit_payment' => 'cash',
        'invoice_pending_type' => 'off',
        'invoice_on_hold_type' => 'off',
        'invoice_processing_type' => 'invoice',
        'invoice_complete_type' => 'off',
        'invoice_cancelled_type' => 'off',
        'invoice_refunded_type' => 'off',
        'invoice_failed_type' => 'off'
    )
));

// بارگذاری فایل‌های مورد نیاز
require_once BIM_PLUGIN_DIR . 'includes/class-bim-logger.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-api.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-ajax.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-order-columns.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-settings.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-connection-tester.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-product.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-invoice.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-unique-product.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-api-routes.php';
require_once BIM_PLUGIN_DIR . 'includes/class-baran-inventory-manager.php';
require_once BIM_PLUGIN_DIR . 'includes/class-bim-admin.php';
require_once BIM_PLUGIN_DIR . 'includes/class-baran-inventory-manager-updater.php';
new Baran_Inventory_Manager_Updater(__FILE__, 'https://server.samtatech.org/baran-inventory-manager/update.json');

// تابع فعال‌سازی افزونه
function bim_activate() {
    global $wpdb;
    
    // ایجاد جدول لاگ‌ها
    $logger = BIM_Logger::get_instance();
    $logger->create_logs_table();
    
    // بررسی وجود جدول محصولات یکتا
    $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
    
    if (!$table_exists) {
        // ایجاد جدول محصولات یکتا
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            unique_id varchar(100) NOT NULL,
            product_id bigint(20) NOT NULL,
            variation_id bigint(20) DEFAULT NULL,
            barcode varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY unique_id (unique_id),
            KEY product_id (product_id),
            KEY variation_id (variation_id),
            KEY barcode (barcode)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // لاگ کردن ایجاد جدول
        $logger->add_log('info', 'جدول محصولات یکتا با موفقیت ایجاد شد');
    }
    
    // ایجاد نقش‌های کاربری
    $role = get_role('administrator');
    if ($role) {
        $role->add_cap('manage_bim_settings');
        $role->add_cap('view_bim_logs');
    }
}
register_activation_hook(__FILE__, 'bim_activate');

// تابع غیرفعال‌سازی افزونه
function bim_deactivate() {
    // حذف نقش‌های کاربری
    $role = get_role('administrator');
    if ($role) {
        $role->remove_cap('manage_bim_settings');
        $role->remove_cap('view_bim_logs');
    }
}
register_deactivation_hook(__FILE__, 'bim_deactivate');

// تابع راه‌اندازی افزونه
function bim_init() {
    // بررسی فعال بودن ووکامرس
    if (!class_exists('WooCommerce')) {
        return;
    }

    // مقداردهی اولیه کلاس‌های اصلی
    BIM_Settings::get_instance();
    BIM_Unique_Product::get_instance();
    BIM_API_Routes::get_instance();
    BIM_Admin::get_instance();
    BIM_Order_Columns::get_instance();
    
    // اطمینان از بارگذاری کلاس‌ها قبل از ثبت هوک‌ها
    if (class_exists('BIM_Invoice')) {
        BIM_Invoice::get_instance();
    }
}
add_action('plugins_loaded', 'bim_init', 20); // اولویت 20 برای اطمینان از بارگذاری ووکامرس