<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_API_Routes {
    private static $instance = null;
    private $unique_product;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->unique_product = BIM_Unique_Product::get_instance();
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route('wc/v3', '/products/unique/(?P<unique_id>[a-zA-Z0-9-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product_by_unique_id'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'unique_id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field'
                )
            )
        ));

        register_rest_route('wc/v3', '/products/unique', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_all_unique_ids'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'page' => array(
                    'default' => 1,
                    'sanitize_callback' => 'absint'
                ),
                'per_page' => array(
                    'default' => 100,
                    'sanitize_callback' => 'absint'
                )
            )
        ));

        register_rest_route('wc/v3', '/products/unique/batch', array(
            'methods' => 'POST',
            'callback' => array($this, 'batch_create_products'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'products' => array(
                    'required' => true,
                    'type' => 'array',
                    'items' => array(
                        'type' => 'object',
                        'properties' => array(
                            'unique_id' => array(
                                'type' => 'string',
                                'required' => true
                            ),
                            'name' => array(
                                'type' => 'string',
                                'required' => true
                            ),
                            'type' => array(
                                'type' => 'string',
                                'default' => 'simple'
                            ),
                            'regular_price' => array(
                                'type' => 'string',
                                'required' => true
                            ),
                            'sale_price' => array(
                                'type' => 'string'
                            ),
                            'manage_stock' => array(
                                'type' => 'boolean',
                                'default' => true
                            ),
                            'stock_quantity' => array(
                                'type' => 'integer'
                            ),
                            'stock_status' => array(
                                'type' => 'string',
                                'enum' => ['instock', 'outofstock']
                            ),
                            'description' => array(
                                'type' => 'string'
                            ),
                            'short_description' => array(
                                'type' => 'string'
                            ),
                            'categories' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object',
                                    'properties' => array(
                                        'id' => array(
                                            'type' => 'integer'
                                        ),
                                        'name' => array(
                                            'type' => 'string'
                                        )
                                    )
                                )
                            ),
                            'images' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object',
                                    'properties' => array(
                                        'src' => array(
                                            'type' => 'string'
                                        )
                                    )
                                )
                            ),
                            'attributes' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object'
                                )
                            ),
                            'meta_data' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object'
                                )
                            )
                        )
                    )
                )
            )
        ));

        register_rest_route('wc/v3', '/products/unique/batch/update', array(
            'methods' => 'PUT',
            'callback' => array($this, 'batch_update_products'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'products' => array(
                    'required' => true,
                    'type' => 'array',
                    'items' => array(
                        'type' => 'object',
                        'properties' => array(
                            'unique_id' => array(
                                'type' => 'string',
                                'required' => true
                            ),
                            'name' => array(
                                'type' => 'string'
                            ),
                            'regular_price' => array(
                                'type' => 'string'
                            ),
                            'sale_price' => array(
                                'type' => 'string'
                            ),
                            'manage_stock' => array(
                                'type' => 'boolean'
                            ),
                            'stock_quantity' => array(
                                'type' => 'integer'
                            ),
                            'stock_status' => array(
                                'type' => 'string',
                                'enum' => ['instock', 'outofstock']
                            ),
                            'description' => array(
                                'type' => 'string'
                            ),
                            'short_description' => array(
                                'type' => 'string'
                            ),
                            'categories' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object'
                                )
                            ),
                            'images' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object'
                                )
                            ),
                            'attributes' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object'
                                )
                            ),
                            'meta_data' => array(
                                'type' => 'array',
                                'items' => array(
                                    'type' => 'object'
                                )
                            )
                        )
                    )
                )
            )
        ));
    }

    public function check_permission() {
        return current_user_can('manage_woocommerce');
    }

    public function get_product_by_unique_id($request) {
        $unique_id = $request['unique_id'];
        $product_data = $this->unique_product->get_product_by_unique_id($unique_id);

        if (!$product_data) {
            return new WP_Error('not_found', 'محصول با این شناسه یکتا یافت نشد', array('status' => 404));
        }

        return rest_ensure_response($product_data);
    }

    public function get_all_unique_ids($request) {
        global $wpdb;
        
        $table_name = BIM_UNIQUE_PRODUCTS_TABLE;
        $query = "SELECT unique_id, barcode, product_id, variation_id FROM $table_name";
        
        $results = $wpdb->get_results($query);
        
        if (!$results) {
            return new WP_Error('not_found', 'هیچ شناسه یکتایی یافت نشد', array('status' => 404));
        }
        
        $response = array(
            'success' => true,
            'data' => array_map(function($item) {
                return array(
                    'unique_id' => $item->unique_id,
                    'barcode' => $item->barcode,
                    'product_id' => $item->product_id,
                    'variation_id' => $item->variation_id
                );
            }, $results)
        );
        
        return rest_ensure_response($response);
    }

    /**
     * درج دسته‌ای محصولات
     */
    public function batch_create_products($request) {
        $products = $request['products'];
        $results = array(
            'success' => array(),
            'failed' => array()
        );

        foreach ($products as $product_data) {
            try {
                // بررسی وجود محصول با این کد یکتا
                $existing_product = $this->unique_product->get_product_by_unique_id($product_data['unique_id']);
                if ($existing_product) {
                    throw new Exception('محصول با این کد یکتا قبلاً ثبت شده است');
                }

                // تعیین نوع محصول
                $product_type = isset($product_data['type']) ? $product_data['type'] : 'simple';
                
                if ($product_type === 'variable') {
                    // ایجاد محصول متغیر
                    $product = new WC_Product_Variable();
                    
                    // تنظیم اطلاعات پایه محصول متغیر
                    $product->set_name($product_data['name']);
                    
                    // تنظیم قیمت فروش
                    if (isset($product_data['sale_price'])) {
                        $product->set_sale_price($product_data['sale_price']);
                    }
                    
                    // تنظیم موجودی
                    if (isset($product_data['manage_stock'])) {
                        $product->set_manage_stock($product_data['manage_stock']);
                    }
                    
                    if (isset($product_data['stock_quantity'])) {
                        $product->set_stock_quantity($product_data['stock_quantity']);
                    }
                    
                    if (isset($product_data['stock_status'])) {
                        $product->set_stock_status($product_data['stock_status']);
                    }
                    
                    // تنظیم SKU
                    if (isset($product_data['sku'])) {
                        $product->set_sku($product_data['sku']);
                    }
                    
                    if (isset($product_data['description'])) {
                        $product->set_description($product_data['description']);
                    }
                    
                    if (isset($product_data['short_description'])) {
                        $product->set_short_description($product_data['short_description']);
                    }

                    // ذخیره محصول متغیر
                    $product_id = $product->save();

                    if (!$product_id) {
                        throw new Exception('خطا در ایجاد محصول متغیر');
                    }

                    // ایجاد متغیرها
                    if (!empty($product_data['variations'])) {
                        foreach ($product_data['variations'] as $variation_data) {
                            $variation = new WC_Product_Variation();
                            $variation->set_parent_id($product_id);
                            
                            // تنظیم قیمت متغیر
                            if (isset($variation_data['regular_price'])) {
                                $variation->set_regular_price($variation_data['regular_price']);
                            }
                            
                            // تنظیم ویژگی‌های متغیر
                            if (!empty($variation_data['attributes'])) {
                                $variation->set_attributes($variation_data['attributes']);
                            }
                            
                            // ذخیره متغیر
                            $variation_id = $variation->save();
                            
                            if ($variation_id) {
                                // ذخیره کد یکتا برای متغیر
                                $this->unique_product->update_product_unique_id($product_id, $variation_id, $variation_data['unique_id']);
                            }
                        }
                    }
                } else {
                    // ایجاد محصول ساده
                    $product = new WC_Product_Simple();
                    
                    // تنظیم اطلاعات پایه
                    $product->set_name($product_data['name']);
                    $product->set_regular_price($product_data['regular_price']);
                    
                    // تنظیم قیمت فروش
                    if (isset($product_data['sale_price'])) {
                        $product->set_sale_price($product_data['sale_price']);
                    }
                    
                    // تنظیم موجودی
                    if (isset($product_data['manage_stock'])) {
                        $product->set_manage_stock($product_data['manage_stock']);
                    }
                    
                    if (isset($product_data['stock_quantity'])) {
                        $product->set_stock_quantity($product_data['stock_quantity']);
                    }
                    
                    if (isset($product_data['stock_status'])) {
                        $product->set_stock_status($product_data['stock_status']);
                    }
                    
                    // تنظیم SKU
                    if (isset($product_data['sku'])) {
                        $product->set_sku($product_data['sku']);
                    }
                    
                    if (isset($product_data['description'])) {
                        $product->set_description($product_data['description']);
                    }
                    
                    if (isset($product_data['short_description'])) {
                        $product->set_short_description($product_data['short_description']);
                    }

                    // ذخیره محصول
                    $product_id = $product->save();

                    if (!$product_id) {
                        throw new Exception('خطا در ایجاد محصول');
                    }

                    // ذخیره کد یکتا
                    $this->unique_product->update_product_unique_id($product_id, null, $product_data['unique_id']);
                }

                // تنظیم دسته‌بندی‌ها
                if (!empty($product_data['categories'])) {
                    $category_ids = array();
                    foreach ($product_data['categories'] as $category) {
                        if (isset($category['id'])) {
                            $category_ids[] = $category['id'];
                        }
                    }
                    if (!empty($category_ids)) {
                        wp_set_object_terms($product_id, $category_ids, 'product_cat');
                    }
                }

                // تنظیم تصاویر
                if (!empty($product_data['images'])) {
                    $image_ids = array();
                    foreach ($product_data['images'] as $image) {
                        if (isset($image['src'])) {
                            $image_id = $this->upload_image_from_url($image['src']);
                            if ($image_id) {
                                $image_ids[] = $image_id;
                            }
                        }
                    }
                    if (!empty($image_ids)) {
                        $product->set_image_id($image_ids[0]);
                        if (count($image_ids) > 1) {
                            $product->set_gallery_image_ids(array_slice($image_ids, 1));
                        }
                    }
                }

                // تنظیم متادیتا
                if (!empty($product_data['meta_data'])) {
                    foreach ($product_data['meta_data'] as $meta) {
                        if (isset($meta['key']) && isset($meta['value'])) {
                            update_post_meta($product_id, $meta['key'], $meta['value']);
                        }
                    }
                }

                $results['success'][] = array(
                    'unique_id' => $product_data['unique_id'],
                    'product_id' => $product_id
                );

            } catch (Exception $e) {
                $results['failed'][] = array(
                    'unique_id' => $product_data['unique_id'],
                    'error' => $e->getMessage()
                );
            }
        }

        return rest_ensure_response($results);
    }

    /**
     * به‌روزرسانی دسته‌ای محصولات
     */
    public function batch_update_products($request) {
        $products = $request['products'];
        $results = array(
            'success' => array(),
            'failed' => array()
        );

        foreach ($products as $product_data) {
            try {
                // دریافت محصول با کد یکتا
                $product_info = $this->unique_product->get_product_by_unique_id($product_data['unique_id']);
                if (!$product_info) {
                    throw new Exception('محصول با این کد یکتا یافت نشد');
                }

                // بررسی وجود variation_id
                if ($product_info->variation_id) {
                    // به‌روزرسانی متغیر محصول
                    $variation = wc_get_product($product_info->variation_id);
                    if (!$variation) {
                        throw new Exception('متغیر محصول در ووکامرس یافت نشد');
                    }

                    // به‌روزرسانی قیمت متغیر
                    if (isset($product_data['regular_price'])) {
                        $variation->set_regular_price($product_data['regular_price']);
                    }

                    if (isset($product_data['sale_price'])) {
                        $variation->set_sale_price($product_data['sale_price']);
                    }

                    // به‌روزرسانی موجودی متغیر
                    if (isset($product_data['manage_stock'])) {
                        $variation->set_manage_stock($product_data['manage_stock']);
                    }

                    if (isset($product_data['stock_quantity'])) {
                        $variation->set_stock_quantity($product_data['stock_quantity']);
                    }

                    if (isset($product_data['stock_status'])) {
                        $variation->set_stock_status($product_data['stock_status']);
                    }

                    // ذخیره تغییرات متغیر
                    $variation->save();

                    $results['success'][] = array(
                        'unique_id' => $product_data['unique_id'],
                        'product_id' => $product_info->product_id,
                        'variation_id' => $product_info->variation_id
                    );
                } 
                else {
                    // به‌روزرسانی محصول ساده
                    $product = wc_get_product($product_info->product_id);
                    if (!$product) {
                        throw new Exception('محصول در ووکامرس یافت نشد');
                    }

                    // به‌روزرسانی اطلاعات پایه
                    if (isset($product_data['name'])) {
                        $product->set_name($product_data['name']);
                    }

                    if (isset($product_data['regular_price'])) {
                        $product->set_regular_price($product_data['regular_price']);
                    }

                    if (isset($product_data['sale_price'])) {
                        $product->set_sale_price($product_data['sale_price']);
                    }

                    if (isset($product_data['manage_stock'])) {
                        $product->set_manage_stock($product_data['manage_stock']);
                    }

                    if (isset($product_data['stock_quantity'])) {
                        $product->set_stock_quantity($product_data['stock_quantity']);
                    }

                    if (isset($product_data['stock_status'])) {
                        $product->set_stock_status($product_data['stock_status']);
                    }

                    if (isset($product_data['sku'])) {
                        $product->set_sku($product_data['sku']);
                    }

                    // ذخیره تغییرات
                    $product->save();

                    $results['success'][] = array(
                        'unique_id' => $product_data['unique_id'],
                        'product_id' => $product->get_id()
                    );
                }

            } catch (Exception $e) {
                $results['failed'][] = array(
                    'unique_id' => $product_data['unique_id'],
                    'error' => $e->getMessage()
                );
            }
        }

        return rest_ensure_response($results);
    }

    /**
     * آپلود تصویر از URL
     */
    private function upload_image_from_url($url) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $temp_file = download_url($url);
        if (is_wp_error($temp_file)) {
            return false;
        }

        $file_array = array(
            'name' => basename($url),
            'tmp_name' => $temp_file
        );

        $id = media_handle_sideload($file_array, 0);
        if (is_wp_error($id)) {
            @unlink($temp_file);
            return false;
        }

        return $id;
    }
} 