<?php
if (!defined('ABSPATH')) {
    exit;
}

class BIM_Connection_Tester {
    private static $instance = null;
    private $api;
    private $logger;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api = BIM_API::get_instance();
        $this->logger = BIM_Logger::get_instance();
    }
    
    public function test_connection() {
        check_ajax_referer('bim-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی غیرمجاز');
        }
        
        try {
            $response = wp_remote_get(rtrim($this->api->get_api_url(), '/') . '/api/v1/test-connection', array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . get_option('bim_api_token')
                ),
                'timeout' => 15
            ));
            
            if (is_wp_error($response)) {
                $this->logger->add_log('connection_test_failed', 'خطا در تست اتصال', array(
                    'error' => $response->get_error_message()
                ));
                throw new Exception('خطا در ارتباط با سرور: ' . $response->get_error_message());
            }
            
            $status_code = wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            
            if ($status_code !== 200) {
                $this->logger->add_log('connection_test_failed', 'تست اتصال ناموفق بود', array(
                    'response' => $body
                ));
                throw new Exception('خطا در تست اتصال: ' . ($body['message'] ?? 'خطای ناشناخته'));
            }
            
            $this->logger->add_log('connection_test_success', 'تست اتصال با موفقیت انجام شد');
            
            wp_send_json_success(array(
                'message' => 'اتصال به وب‌سرویس برقرار است',
                'details' => $body
            ));
            
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }
    
    public function get_connection_status() {
        try {
            $response = wp_remote_get(rtrim($this->api->get_api_url(), '/') . '/api/v1/test-connection', array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . get_option('bim_api_token')
                ),
                'timeout' => 5
            ));
            
            if (is_wp_error($response)) {
                return array(
                    'connected' => false,
                    'error' => $response->get_error_message()
                );
            }
            
            $status_code = wp_remote_retrieve_response_code($response);
            
            return array(
                'connected' => ($status_code === 200),
                'status_code' => $status_code
            );
            
        } catch (Exception $e) {
            return array(
                'connected' => false,
                'error' => $e->getMessage()
            );
        }
    }
} 