<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap bim-admin">
    <h1>عملیات داده</h1>
    
    <div class="bim-card">
        <h2>عملیات‌های دسته‌ای</h2>
        
        <div class="bim-actions">
            <div class="bim-action-item">
                <h3>به‌روزرسانی همه کالاها</h3>
                <p>این عملیات تمام کالاهای موجود در فروشگاه را با اطلاعات سرور به‌روزرسانی می‌کند.</p>
                <button type="button" class="button button-primary" id="update-all-products">
                    شروع به‌روزرسانی
                </button>
                <div class="bim-action-status"></div>
            </div>

            <div class="bim-action-item">
                <h3>دریافت دسته‌بندی و ویژگی‌ها</h3>
                <p>این عملیات لیست دسته‌بندی‌ها و ویژگی‌های موجود در سرور را دریافت می‌کند.</p>
                <button type="button" class="button button-primary" id="get-categories-attributes">
                    دریافت اطلاعات
                </button>
                <div class="bim-action-status"></div>
            </div>

            <div class="bim-action-item">
                <h3>دریافت همه کالاها</h3>
                <p>این عملیات لیست تمام کالاهای موجود در سرور را دریافت می‌کند.</p>
                <button type="button" class="button button-primary" id="get-all-products">
                    دریافت کالاها
                </button>
                <div class="bim-action-status"></div>
            </div>
        </div>
    </div>

    <div class="bim-card">
        <h2>منطبق‌سازی کد یکتا</h2>
        
        <div class="bim-sync-form">
            <div class="form-field">
                <p>این عملیات محصولاتی که دارای کد یکتا نیستند را با اطلاعات سرور منطبق می‌کند.</p>
                <button type="button" class="button button-primary" id="sync-unique-ids">
                    شروع منطبق‌سازی
                </button>
            </div>
            <div class="bim-sync-status">
                <div class="bim-sync-progress">
                    <div class="bim-progress-bar">
                        <div class="bim-progress-fill"></div>
                    </div>
                    <div class="bim-progress-text">0%</div>
                </div>
                <div class="bim-sync-details">
                    <p>تعداد کل محصولات: <span class="total-products">0</span></p>
                    <p>تعداد محصولات پردازش شده: <span class="processed-products">0</span></p>
                    <p>تعداد محصولات منطبق شده: <span class="synced-products">0</span></p>
                    <p>تعداد خطاها: <span class="error-count">0</span></p>
                </div>
                <div class="bim-sync-message"></div>
            </div>
        </div>
    </div>
</div>

<style>
.bim-admin {
    margin: 20px;
}

.bim-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.bim-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.bim-action-item {
    background: #f8f9fa;
    border: 1px solid #e2e4e7;
    border-radius: 4px;
    padding: 15px;
}

.bim-action-item h3 {
    margin-top: 0;
    margin-bottom: 10px;
}

.bim-action-item p {
    margin-bottom: 15px;
    color: #666;
}

.bim-action-status {
    margin-top: 10px;
    padding: 10px;
    border-radius: 4px;
    display: none;
}

.bim-action-status.success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
    display: block;
}

.bim-action-status.error {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
    display: block;
}

.bim-sync-form {
    margin-top: 20px;
}

.bim-sync-status {
    margin-top: 20px;
    display: none;
}

.bim-sync-progress {
    margin-bottom: 15px;
}

.bim-progress-bar {
    height: 20px;
    background: #f0f0f1;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 5px;
}

.bim-progress-fill {
    height: 100%;
    background: #2271b1;
    width: 0;
    transition: width 0.3s ease;
}

.bim-progress-text {
    text-align: center;
    font-weight: bold;
}

.bim-sync-details {
    background: #f8f9fa;
    border: 1px solid #e2e4e7;
    border-radius: 4px;
    padding: 15px;
    margin-bottom: 15px;
}

.bim-sync-details p {
    margin: 5px 0;
}

.bim-sync-message {
    padding: 10px;
    border-radius: 4px;
    display: none;
}

.bim-sync-message.success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
    display: block;
}

.bim-sync-message.error {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
    display: block;
}

.bim-sync-message.warning {
    background: #fff3cd;
    border: 1px solid #ffeeba;
    color: #856404;
    display: block;
}
</style>

<script>
jQuery(document).ready(function($) {
    // به‌روزرسانی همه کالاها
    $('#update-all-products').on('click', function() {
        var $button = $(this);
        var $status = $button.siblings('.bim-action-status');
        
        $button.prop('disabled', true);
        $status.removeClass('success error').hide();
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_data_operations',
                operation: 'update_all_products',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.addClass('success').text(bimAdmin.strings.success).show();
                } else {
                    $status.addClass('error').text(response.data).show();
                }
            },
            error: function() {
                $status.addClass('error').text(bimAdmin.strings.error).show();
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // دریافت دسته‌بندی و ویژگی‌ها
    $('#get-categories-attributes').on('click', function() {
        var $button = $(this);
        var $status = $button.siblings('.bim-action-status');
        
        $button.prop('disabled', true);
        $status.removeClass('success error').hide();
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_data_operations',
                operation: 'get_categories_attributes',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.addClass('success').text(bimAdmin.strings.success).show();
                } else {
                    $status.addClass('error').text(response.data).show();
                }
            },
            error: function() {
                $status.addClass('error').text(bimAdmin.strings.error).show();
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // دریافت همه کالاها
    $('#get-all-products').on('click', function() {
        var $button = $(this);
        var $status = $button.siblings('.bim-action-status');
        
        $button.prop('disabled', true);
        $status.removeClass('success error').hide();
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_data_operations',
                operation: 'get_all_products',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.addClass('success').text(bimAdmin.strings.success).show();
                } else {
                    $status.addClass('error').text(response.data).show();
                }
            },
            error: function() {
                $status.addClass('error').text(bimAdmin.strings.error).show();
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // منطبق‌سازی کد یکتا
    $('#sync-unique-ids').on('click', function() {
        var $button = $(this);
        var $status = $('.bim-sync-status');
        var $progressBar = $('.bim-progress-fill');
        var $progressText = $('.bim-progress-text');
        var $message = $('.bim-sync-message');
        var $totalProducts = $('.total-products');
        var $processedProducts = $('.processed-products');
        var $syncedProducts = $('.synced-products');
        var $errorCount = $('.error-count');
        
        $button.prop('disabled', true);
        $status.show();
        $message.removeClass('success error').hide();
        
        // ریست کردن نمایشگر پیشرفت
        $progressBar.css('width', '0%');
        $progressText.text('0%');
        $totalProducts.text('0');
        $processedProducts.text('0');
        $syncedProducts.text('0');
        $errorCount.text('0');
        
        $.ajax({
            url: bimAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'bim_data_operations',
                operation: 'sync_unique_ids',
                nonce: bimAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    if (response.data.total_products === 0) {
                        $message.addClass('success').text(response.data.message).show();
                        $button.prop('disabled', false);
                    } else {
                        startSyncProgress(response.data);
                    }
                } else {
                    $message.addClass('error').text(response.data).show();
                    $button.prop('disabled', false);
                }
            },
            error: function() {
                $message.addClass('error').text(bimAdmin.strings.error).show();
                $button.prop('disabled', false);
            }
        });
    });

    function startSyncProgress(data) {
        var $progressBar = $('.bim-progress-fill');
        var $progressText = $('.bim-progress-text');
        var $message = $('.bim-sync-message');
        var $totalProducts = $('.total-products');
        var $processedProducts = $('.processed-products');
        var $syncedProducts = $('.synced-products');
        var $errorCount = $('.error-count');
        var $button = $('#sync-unique-ids');
        var retryCount = 0;
        var maxRetries = 3;
        
        $totalProducts.text(data.total_products);
        
        function checkProgress() {
            $.ajax({
                url: bimAdmin.ajaxurl,
                type: 'POST',
                data: {
                    action: 'bim_data_operations',
                    operation: 'check_sync_progress',
                    nonce: bimAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        retryCount = 0; // ریست کردن شمارنده تلاش مجدد در صورت موفقیت
                        var progress = response.data;
                        var percentage = Math.round((progress.processed / progress.total) * 100);
                        
                        $progressBar.css('width', percentage + '%');
                        $progressText.text(percentage + '%');
                        $processedProducts.text(progress.processed);
                        $syncedProducts.text(progress.synced);
                        $errorCount.text(progress.errors);
                        
                        if (progress.status === 'completed') {
                            var message = 'عملیات با موفقیت انجام شد. ';
                            message += 'تعداد کل: ' + progress.total + '، ';
                            message += 'منطبق شده: ' + progress.synced + '، ';
                            message += 'خطا: ' + progress.errors;
                            
                            $message.removeClass('warning error').addClass('success').text(message).show();
                            $button.prop('disabled', false);
                        } else {
                            setTimeout(checkProgress, 2000);
                        }
                    } else {
                        handleError(response.data);
                    }
                },
                error: function(xhr, status, error) {
                    handleError(error || 'خطا در ارتباط با سرور');
                }
            });
        }
        
        function handleError(error) {
            if (retryCount < maxRetries) {
                retryCount++;
                var message = 'خطا در ارتباط با سرور. ';
                message += 'تلاش مجدد... (تلاش ' + retryCount + ' از ' + maxRetries + ')';
                message += '<br>خطا: ' + error;
                
                $message.removeClass('success error').addClass('warning').html(message).show();
                setTimeout(checkProgress, 3000); // انتظار 3 ثانیه قبل از تلاش مجدد
            } else {
                var message = 'خطا در ارتباط با سرور. ';
                message += 'لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.';
                message += '<br>خطا: ' + error;
                
                $message.removeClass('warning success').addClass('error').html(message).show();
                $button.prop('disabled', false);
            }
        }
        
        checkProgress();
    }
});
</script> 